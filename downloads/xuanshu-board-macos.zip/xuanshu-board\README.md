# 玄枢号看板 · 便携版

本地任务看板与插图审阅工作台。零第三方依赖，只需要 Node.js；数据全部保存在本目录，不联网。

## 环境要求

- Node.js **18 或以上**（Windows / macOS 均可）：https://nodejs.org/

## 启动

**Windows**：双击 `start-windows.bat`。首次运行若被 SmartScreen 拦截，点「更多信息 → 仍要运行」。
启动后自动打开 http://127.0.0.1:7790/board.html

**macOS**：打开「终端」，进入本目录后执行：

```bash
bash start-macos.sh
```

若提示没有执行权限，先执行 `chmod +x start-macos.sh`。
启动后自动打开 http://127.0.0.1:7790/board.html

## 停止

- Windows：任务管理器里结束 `node.exe`，或在命令行执行 `taskkill /IM node.exe /F`（会关掉所有 node 进程，谨慎）
- macOS：`pkill -f "live.mjs --port 7790"`

## 页面

| 文件 | 用途 |
|---|---|
| board.html | 主看板：任务卡片、小说工作流、队列与审核 |
| gallery.html | 插图审阅：大图对比、通过/不通过 |
| index.html | 任务进度列表 |
| app.html | 工作台入口 |

## 数据放在哪

- `tasks/`：任务卡片，一个 `.md` 一个任务；看板启动时读取
- `projects/`：各项目的产物（小说插图、队列、场景表等）
- `live.log`：服务日志，排查启动问题先看这里

把自己的任务 `.md` 放进 `tasks/`，或把项目目录放进 `projects/`，刷新页面即可看到。

## 端口

默认 7790，避免和本机其他看板冲突。改端口：编辑启动脚本里的 `PORT`，或手动执行 `node live.mjs --port 7800`。

## 常见问题

- **双击后没反应**：确认 `node -v` 能输出版本号；再看 `live.log` 最后几行。
- **页面空白**：地址要用 `http://127.0.0.1:7790/board.html`，不要用 `file://` 直接打开 html。
- **端口被占用**：换一个 `PORT` 再启动。
