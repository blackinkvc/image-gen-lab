// 扫描插图相关目录，产出页面用的索引。只读，不改任何图片或批次文件。
// 四个来源：
//   batch   25_插图批量_20261117（新出的批次图）
//   site    20_站点_React/public + data/crews.json（舰员立绘、主图、系列图）
//   portrait 02_人物立绘（历史立绘原图档案）
//   lib     站点素材（生成批次、参考图、设计稿、事件插图）
import fs from 'node:fs';
import path from 'node:path';

export const SCAN_ROOTS = {
  batch: 'D:/玄枢号项目/25_插图批量_20261117',
  site: 'D:/玄枢号项目/20_站点_React/public',
  portrait: 'D:/玄枢号项目/02_人物立绘',
  lib: 'D:/玄枢号项目/20_站点_React/public/assets'
};
// 兼容旧引用
export const GALLERY_ROOT = SCAN_ROOTS.batch;

const IMAGE_EXT = /\.(png|jpe?g|webp)$/i;
const CREWS_FILE = 'D:/玄枢号项目/20_站点_React/data/crews.json';
const GEN_TASKS_FILE = 'D:/玄枢号项目/20_站点_React/data/gen-tasks.json';

// 一句话摘要：去空白、取第一句、按长度截断
function brief(text, n) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  if (!s) return '';
  const first = s.split(/[。；;！!？?]/)[0] || s;
  return first.length > n ? first.slice(0, n) + '…' : first;
}
// 批次名里带的分类关键词
function batchCategory(name) {
  const m = String(name || '').match(/图鉴|物品|房间|参考图|立绘|场景|模板/);
  return m ? m[0] : '';
}
const GEN_TEMPLATES_FILE = 'D:/玄枢号项目/20_站点_React/data/gen-templates.json';
// 站点事件图的原始生成参数（ComfyUI 落盘记录），按 slug 索引，用于回填 prompt
const EVT_RECORDS_FILE = 'D:/玄枢号项目/20_站点_React/public/data/evt_records.json';
const ENGINE_DIR = 'D:/玄枢号项目/21_舰务模拟';
const SITE_DATA_DIR = 'D:/玄枢号项目/20_站点_React/src/data';

function readJson(p) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; }
}
function readText(p) {
  try { return fs.readFileSync(p, 'utf8').trim(); } catch { return ''; }
}
// slug → 原始生成记录（prompt / model / steps / seed 等）
let evtRecCache = null;
function evtRecords() {
  if (evtRecCache) return evtRecCache;
  const m = new Map();
  const list = readJson(EVT_RECORDS_FILE);
  (Array.isArray(list) ? list : []).forEach(r => {
    if (r && r.slug && r.prompt) m.set(String(r.slug).toLowerCase(), r);
  });
  evtRecCache = m;
  return m;
}
function bytesOf(p) {
  try { return fs.statSync(p).size; } catch { return 0; }
}
function statInfo(p) {
  try {
    const s = fs.statSync(p);
    return { bytes: s.size, mtime: s.mtime.toISOString() };
  } catch { return { bytes: 0, mtime: '' }; }
}
// 单张图的实际文件时间（近期/搁置视图按这个算，不用登记时间）
function mtimeOf(p) {
  try { return fs.statSync(p).mtime.toISOString(); } catch { return ''; }
}
function toDir(p) {
  return p.replace(/\//g, '\\');
}
function slug(s, fallback = 'x') {
  const t = String(s == null ? '' : s)
    .replace(/[^\w\u4e00-\u9fa5-]+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '');
  return t || fallback;
}
function imageFiles(dir) {
  try {
    return fs.readdirSync(dir, { withFileTypes: true })
      .filter(d => d.isFile() && IMAGE_EXT.test(d.name) && !d.name.startsWith('_.'))
      .map(d => d.name)
      .sort();
  } catch { return []; }
}
function subDirs(dir) {
  try {
    return fs.readdirSync(dir, { withFileTypes: true })
      .filter(d => d.isDirectory() && !d.name.startsWith('.'))
      .map(d => d.name)
      .sort();
  } catch { return []; }
}
function countImages(dir) {
  let n = 0;
  const walk = d => {
    let list;
    try { list = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const x of list) {
      if (x.isDirectory()) walk(path.join(d, x.name));
      else if (IMAGE_EXT.test(x.name)) n++;
    }
  };
  walk(dir);
  return n;
}

// ---------- 站点「生成任务」数据（data/gen-tasks.json） ----------
// 字段：id / kind / crew / title / status / createdAt / prompt / negative / note /
//       outputs[] / placeholder / target / model / engine / mode / size / steps / cfg / sampler / scheduler / shift / denoise / seed
function readGenTasks(missing) {
  if (!fs.existsSync(GEN_TASKS_FILE)) {
    missing.push({ source: 'gen', label: 'gen-tasks.json', detail: '文件不存在：' + GEN_TASKS_FILE });
    return [];
  }
  const j = readJson(GEN_TASKS_FILE);
  const list = j && Array.isArray(j.tasks) ? j.tasks : null;
  if (!list) {
    missing.push({ source: 'gen', label: 'gen-tasks.json', detail: '解析失败或没有 tasks 数组' });
    return [];
  }
  return list.filter(t => t && typeof t === 'object');
}
function genTaskInfo(t) {
  return {
    id: String(t.id || ''),
    kind: String(t.kind || ''),
    title: String(t.title || ''),
    status: String(t.status || ''),
    createdAt: String(t.createdAt || ''),
    prompt: String(t.prompt || ''),
    negative: String(t.negative || ''),
    note: String(t.note || ''),
    outputs: (Array.isArray(t.outputs) ? t.outputs : []).map(x => String(x).replace(/^\.?\//, '')),
    placeholder: String(t.placeholder || '').replace(/^\.?\//, ''),
    target: String(t.target || '').replace(/^\.?\//, ''),
    params: {
      model: t.model, engine: t.engine, mode: t.mode, size: t.size, steps: t.steps,
      cfg: t.cfg, sampler: t.sampler, scheduler: t.scheduler, shift: t.shift,
      denoise: t.denoise, seed: t.seed
    }
  };
}
function genOutRel(t) {
  return (Array.isArray(t.outputs) ? t.outputs : [])
    .map(x => String(x).replace(/^\.?\//, ''))
    .filter(Boolean);
}

// 生成任务页顶部的 5 张模板卡片（不重复展示示例图，只做引用与断链检查）
function readGenTemplates(missing) {
  if (!fs.existsSync(GEN_TEMPLATES_FILE)) return null;
  const j = readJson(GEN_TEMPLATES_FILE);
  if (!j || !Array.isArray(j.templates)) {
    missing.push({ source: 'tpl', label: 'gen-templates.json', detail: '解析失败或没有 templates 数组' });
    return null;
  }
  const root = SCAN_ROOTS.site;
  const templates = j.templates.map(t => {
    const examples = (Array.isArray(t.examples) ? t.examples : [])
      .filter(e => e && e.src)
      .map(e => {
        const rel = String(e.src).replace(/^\.?\//, '');
        const exists = fs.existsSync(path.join(root, rel));
        if (!exists) missing.push({ source: 'tpl', label: String(t.id || ''), detail: '模板示例图不存在：' + rel });
        return { crew: String(e.crew || ''), name: String(e.name || ''), rel, exists };
      });
    return {
      id: String(t.id || ''), name: String(t.name || ''), purpose: String(t.purpose || ''),
      purposeLabel: String(t.purposeLabel || ''), status: String(t.status || ''),
      engine: t.engine, mode: t.mode, model: t.model, size: t.size, steps: t.steps,
      cfg: t.cfg, sampler: t.sampler, scheduler: t.scheduler, shift: t.shift, denoise: t.denoise,
      prompt: String(t.prompt || ''), promptNote: String(t.promptNote || ''),
      negative: String(t.negative || ''), seedStrategy: String(t.seedStrategy || ''),
      appliesTo: Array.isArray(t.appliesTo) ? t.appliesTo.map(String) : [],
      conform: t.conform || null, acceptance: t.acceptance || null,
      revisedAt: String(t.revisedAt || ''), note: String(t.note || ''),
      examples
    };
  });
  return { updatedAt: String(j.updatedAt || ''), fieldLabels: j.fieldLabels || {}, templates };
}


// ---------- 来源一：插图批量 ----------
// 批次码：取目录名的 ASCII 前缀（B1/B2…），同名基础的第 n 个加 -n，避免多轮重跑撞号。
function makeBatchCodes(names) {
  const seen = {};
  const codes = {};
  for (const n of [...names].sort()) {
    const m = n.match(/^([A-Za-z]+\d+)/);
    const base = m ? m[1].toUpperCase() : (n.replace(/[^A-Za-z0-9]+/g, '').toUpperCase() || 'B');
    seen[base] = (seen[base] || 0) + 1;
    codes[n] = seen[base] === 1 ? base : base + '-' + seen[base];
  }
  return codes;
}
function stripBatchPrefix(name) {
  return name.replace(/^[A-Za-z]+\d+R?\d*_/, '').replace(/^[A-Za-z]+\d+_/, '').toLowerCase();
}
function listPromptFiles() {
  const dir = path.join(SCAN_ROOTS.batch, '_批次清单');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(f => f.toLowerCase().endsWith('.json'))
    .map(f => {
      const list = readJson(path.join(dir, f));
      return { name: f.replace(/\.json$/i, ''), list: Array.isArray(list) ? list : [] };
    });
}
function roundOf(name) {
  const m = name.match(/^[A-Za-z]+\d+R(\d+)/);
  return m ? Number(m[1]) : 0;
}
// 选与该批次最贴合的清单：先比清洗后的名字，再比能覆盖多少个组 id，同分取轮次大的。
function pickPromptFile(batchName, promptFiles, groupIds) {
  const clean = stripBatchPrefix(batchName);
  const exact = promptFiles.filter(p => stripBatchPrefix(p.name) === clean);
  const pool = exact.length ? exact : promptFiles;
  let best = null;
  let bestScore = 0;
  for (const p of pool) {
    const ids = new Set(p.list.map(x => x && x.id));
    const score = groupIds.filter(g => ids.has(g)).length;
    if (score > bestScore || (score === bestScore && best && roundOf(p.name) > roundOf(best.name))) {
      best = p;
      bestScore = score;
    }
  }
  return bestScore > 0 ? best : null;
}
function promptFromRaw(groupDir, groupName) {
  const rawDir = path.join(groupDir, '..', '_raw');
  if (!fs.existsSync(rawDir)) return '';
  const hit = fs.readdirSync(rawDir)
    .filter(f => f.startsWith(groupName + '__') && f.endsWith('.json'))
    .sort()[0];
  if (!hit) return '';
  const j = readJson(path.join(rawDir, hit));
  const p = j && j.prompt;
  if (typeof p === 'string') return p;
  if (p && typeof p === 'object') return p.positive || p.text || '';
  return '';
}
function promptFromMd(groupDir) {
  for (const f of ['prompt.md', '说明.md', 'README.md']) {
    const p = path.join(groupDir, f);
    if (fs.existsSync(p)) {
      const t = readText(p);
      if (t) return t;
    }
  }
  return '';
}

function scanBatches(missing) {
  const root = SCAN_ROOTS.batch;
  if (!fs.existsSync(root)) {
    missing.push({ source: 'batch', label: root, detail: '目录不存在' });
    return null;
  }
  const batchNames = fs.readdirSync(root, { withFileTypes: true })
    .filter(d => d.isDirectory() && !d.name.startsWith('_'))
    .map(d => d.name)
    .sort();
  const codes = makeBatchCodes(batchNames);
  const promptFiles = listPromptFiles();
  const groupsOut = [];

  for (const bn of batchNames) {
    const bdir = path.join(root, bn);
    const manifest = readJson(path.join(bdir, 'manifest.json')) || {};
    const groupNames = fs.readdirSync(bdir, { withFileTypes: true })
      .filter(d => d.isDirectory() && !d.name.startsWith('_'))
      .map(d => d.name)
      .sort();
    const pf = pickPromptFile(bn, promptFiles, groupNames);
    const byId = new Map();
    if (pf) for (const item of pf.list) if (item && item.id) byId.set(item.id, item);

    const groups = [];
    for (const gn of groupNames) {
      const gdir = path.join(bdir, gn);
      const files = imageFiles(gdir);
      if (!files.length) continue;

      const entry = byId.get(gn) || null;
      let prompt = entry && typeof entry.prompt === 'string' ? entry.prompt : '';
      let promptSource = prompt ? pf.name + '.json' : '';
      if (!prompt) {
        const fromMd = promptFromMd(gdir);
        if (fromMd) { prompt = fromMd; promptSource = '组内说明文件'; }
      }
      if (!prompt) {
        const fromRaw = promptFromRaw(gdir, gn);
        if (fromRaw) { prompt = fromRaw; promptSource = '_raw 元数据'; }
      }

      const title = (manifest[gn] && manifest[gn].title) || (entry && entry.title) || gn;
      let mtime = '';
      // 派生/重做版本文件名 = <原图>-dN / <原图>-rN；这类文件不参与序号编号，避免把后面的图号顶掉
      const basePrefix = codes[bn] + '-' + gn + '-';
      const stemOf = f => path.basename(f, path.extname(f));
      const isDerivedFile = f => /-d\d+$/.test(stemOf(f)) && stemOf(f).startsWith(basePrefix);
      const isRedoFile = f => /-r\d+$/i.test(stemOf(f));
      const derivedFiles = files.filter(isDerivedFile);
      const redoFiles = files.filter(f => !isDerivedFile(f) && isRedoFile(f));
      const accessory = new Set([].concat(derivedFiles, redoFiles));
      const plainFiles = accessory.size ? files.filter(f => !accessory.has(f)) : files;
      // 稳定 id 用文件名（含批次码），序号只做展示；legacyId 保留旧「批次码-组名-序号」供老账本解析
      const stableSeen = {};
      const images = plainFiles.map((f, i) => {
        const st = statInfo(path.join(gdir, f));
        if (st.mtime > mtime) mtime = st.mtime;
        let sid = codes[bn] + '-' + stemOf(f);
        if (stableSeen[sid]) sid = codes[bn] + '-' + gn + '-' + stemOf(f);
        stableSeen[sid] = 1;
        const rel = bn + '/' + gn + '/' + f;
        return {
          n: i + 1,
          file: f,
          id: sid,
          legacyId: codes[bn] + '-' + gn + '-' + (i + 1),
          key: rel,
          rel,
          bytes: st.bytes,
          mtime: st.mtime
        };
      });
      // 派生/重做文件同样用批次码 + 文件名做 id，避免跨批次同名文件撞 id
      const accessoryId = f => {
        let sid = codes[bn] + '-' + stemOf(f);
        if (stableSeen[sid]) sid = codes[bn] + '-' + gn + '-' + stemOf(f);
        stableSeen[sid] = 1;
        return sid;
      };
      derivedFiles.forEach(f => {
        const st = statInfo(path.join(gdir, f));
        if (st.mtime > mtime) mtime = st.mtime;
        const rel = bn + '/' + gn + '/' + f;
        images.push({
          n: 0,
          file: f,
          id: accessoryId(f),
          key: rel,
          rel,
          bytes: st.bytes,
          mtime: st.mtime,
          derived: true
        });
      });
      redoFiles.forEach(f => {
        const st = statInfo(path.join(gdir, f));
        if (st.mtime > mtime) mtime = st.mtime;
        const rel = bn + '/' + gn + '/' + f;
        images.push({
          n: 0,
          file: f,
          id: accessoryId(f),
          key: rel,
          rel,
          bytes: st.bytes,
          mtime: st.mtime,
          redo: true
        });
      });
      groups.push({
        id: gn,
        title,
        topic: String(title).split('·')[0].trim() || bn,
        prompt,
        promptSource,
        promptFound: !!prompt,
        needsPrompt: true,
        dir: toDir(gdir),
        time: mtime,
        images
      });
    }
    if (!groups.length) continue;
    groupsOut.push({ name: bn, code: codes[bn], source: 'batch', rootKey: 'batch', groups });
  }

  return {
    batches: groupsOut,
    source: { key: 'batch', name: '插图批量 20261117' }
  };
}

// ---------- 来源二：站点舰员立绘（crews.json 引用） ----------
function scanCrews(missing, genTasks) {
  if (!fs.existsSync(CREWS_FILE)) {
    missing.push({ source: 'site', label: 'crews.json', detail: '文件不存在：' + CREWS_FILE });
    return null;
  }
  const crews = readJson(CREWS_FILE);
  if (!Array.isArray(crews)) {
    missing.push({ source: 'site', label: 'crews.json', detail: '解析失败或不是数组' });
    return null;
  }
  const root = SCAN_ROOTS.site;
  const groups = [];
  const mergedTaskIds = new Set();
  // 生成任务按 crew 归组；产出图路径用于和已扫描的图去重
  const byCrew = new Map();
  for (const t of genTasks) {
    const cid = String(t.crew || '').trim();
    if (!cid) continue;
    if (!byCrew.has(cid)) byCrew.set(cid, []);
    byCrew.get(cid).push(t);
  }

  for (const c of crews) {
    const gid = String(c.id || ('CREW-' + slug(c.name)));
    const num = gid.replace(/^CREW[-\s]*/i, '') || slug(c.name);
    const imgs = [];
    let dir = '';
    const addImg = (src, thumb, title, suffix) => {
      if (!src) return;
      const rel = String(src).replace(/\\/g, '/');
      // 同一文件在同一组里只出现一次（main 与 series 常指向同一张）
      if (imgs.some(i => i.rel === rel)) return;
      const full = path.join(root, src);
      if (!fs.existsSync(full)) {
        missing.push({
          source: 'site',
          label: (c.name || gid) + ' · ' + (title || suffix),
          detail: '引用断链：' + src
        });
        return;
      }
      if (!dir) dir = path.dirname(full);
      const n = imgs.length + 1;
      imgs.push({
        n,
        file: path.basename(src),
        id: 'CREW-' + num + '-' + suffix,
        rel,
        thumbRel: thumb ? String(thumb).replace(/\\/g, '/') : '',
        bytes: bytesOf(full),
        mtime: mtimeOf(full)
      });
    };
    if (c.main) addImg(c.main.src, c.main.thumb, c.main.title || '主图', 'main');
    for (const s of c.series || []) {
      for (const it of s.items || []) {
        addImg(it.src, it.thumb, (s.id || '') + ' ' + (it.title || ''), slug(s.id || 'S') + '-' + slug(it.no || imgs.length + 1));
      }
    }
    // 头像等未写进 crews.json 的同目录图（crew-XXX-avatar.png 之类），一并收进来
    if (dir) {
      const extras = imageFiles(dir).filter(f => /avatar|bust|head/i.test(f) && !/-s\.(png|jpe?g|webp)$/i.test(f));
      for (const f of extras) {
        const rel = path.relative(root, path.join(dir, f)).replace(/\\/g, '/');
        if (imgs.some(i => i.rel === rel)) continue;
        const stem = path.basename(f, path.extname(f));
        const prefix = gid + '-';
        const tail = stem.toLowerCase().startsWith(prefix.toLowerCase()) ? stem.slice(prefix.length) : stem;
        imgs.push({
          n: imgs.length + 1,
          file: f,
          id: 'CREW-' + num + '-' + slug(tail),
          rel,
          thumbRel: '',
          bytes: bytesOf(path.join(dir, f)),
          mtime: mtimeOf(path.join(dir, f))
        });
      }
    }
    // 头像：可能放在主图目录，也可能固定在 assets/c/<crew>（站点就是这么放的）
    const avDirs = [];
    if (dir) avDirs.push(dir);
    avDirs.push(path.join(root, 'assets', 'c', gid.toLowerCase()));
    let avatarRel = '';
    for (const d of avDirs) {
      if (!fs.existsSync(d)) continue;
      const files = imageFiles(d);
      const pick = files.find(f => /avatar\.(png|jpe?g|webp)$/i.test(f)) ||
        files.find(f => /avatar|bust|head/i.test(f) && !/-s\.(png|jpe?g|webp)$/i.test(f)) ||
        // 只有 *-avatar-s.webp 的（比如 CREW-050）也收，小图当头像够用
        files.find(f => /avatar/i.test(f) && /\.(png|jpe?g|webp)$/i.test(f));
      if (pick) {
        avatarRel = path.relative(root, path.join(d, pick)).replace(/\\/g, '/');
        break;
      }
    }
    if (avatarRel) {
      const exist = imgs.find(i => i.rel === avatarRel);
      if (exist) {
        exist.id = 'CREW-' + num + '-avatar';
        exist.avatar = true;
      } else {
        imgs.push({
          n: imgs.length + 1,
          file: path.basename(avatarRel),
          id: 'CREW-' + num + '-avatar',
          rel: avatarRel,
          thumbRel: '',
          bytes: bytesOf(path.join(root, avatarRel)),
          mtime: mtimeOf(path.join(root, avatarRel)),
          avatar: true
        });
      }
    }
    // 生成任务的产出图：与 crews.json 已收的图按 rel 去重；同一张图只出现一次
    const tasks = byCrew.get(gid) || [];
    for (const t of tasks) {
      const outs = genOutRel(t).slice().sort((a, b) =>
        (/-(s)\.(png|jpe?g|webp)$/i.test(a) ? 1 : 0) - (/-(s)\.(png|jpe?g|webp)$/i.test(b) ? 1 : 0));
      let alive = 0;
      for (const rel of outs) {
        const full = path.join(root, rel);
        if (!fs.existsSync(full)) {
          missing.push({ source: 'gen', label: gid + ' · ' + (t.id || ''), detail: '产出图不存在：' + rel });
          continue;
        }
        alive++;
        if (imgs.some(i => i.rel === rel)) continue;
        if (avatarRel && rel === avatarRel) continue;
        // 有全尺寸版（任意扩展名）就不重复收 -s 小图
        const small = rel.match(/^(.*)-s\.(png|jpe?g|webp)$/i);
        if (small && ['png', 'jpg', 'jpeg', 'webp'].some(ext => fs.existsSync(path.join(root, small[1] + '.' + ext)))) continue;
        if (!dir) dir = path.dirname(full);
        imgs.push({
          n: imgs.length + 1,
          file: path.basename(rel),
          id: 'CREW-' + num + '-' + slug('gen-' + t.id),
          rel,
          thumbRel: '',
          bytes: bytesOf(full),
          mtime: mtimeOf(full),
          genTask: String(t.id || '')
        });
      }
      if (alive) mergedTaskIds.add(t.id);
    }
    const gen = tasks.map(genTaskInfo);
    if (!imgs.length && !gen.length) {
      missing.push({ source: 'site', label: gid + ' ' + (c.name || ''), detail: 'crews.json 里有条目，但没有任何可用图片' });
      continue;
    }
    const anchor = c.profile && c.profile['外观锚点'];
    const prompt = [anchor, c.tagline].filter(Boolean).join('\n');
    groups.push({
      id: gid,
      title: (c.name || gid) + (c.code ? ' · ' + c.code : ''),
      topic: '舰员立绘',
      prompt,
      promptSource: prompt ? 'crews.json · 外观锚点 / 一句话' : '',
      promptFound: !!prompt,
      needsPrompt: false,
      dir: toDir(dir),
      avatar: avatarRel ? { rel: avatarRel, thumbRel: '' } : undefined,
      time: gen.length ? gen.map(t => t.createdAt).filter(Boolean).sort().pop() || '' : '',
      images: imgs,
      noImages: !imgs.length,
      gen: gen.length ? gen : undefined
    });
  }

  return {
    batch: {
      name: '站点 · 舰员立绘（crews.json）',
      code: 'CREW',
      source: 'site',
      rootKey: 'site',
      groups
    },
    source: { key: 'site', name: '站点舰员立绘' },
    mergedTaskIds
  };
}

// ---------- 来源五：生成任务里还没出图 / 没挂到舰员组的部分 ----------
// 只收没有并进任何舰员组的任务，保证同一张图不会在两处出现。
function scanGenPending(genTasks, mergedTaskIds, missing) {
  const root = SCAN_ROOTS.site;
  const groups = [];
  for (const t of genTasks) {
    if (mergedTaskIds.has(t.id)) continue;
    const info = genTaskInfo(t);
    const relPath = info.target || info.placeholder || '';
    const dir = relPath ? path.dirname(path.join(root, relPath)) : root;
    if (!fs.existsSync(dir)) {
      missing.push({ source: 'gen', label: info.id, detail: '出图目录不存在：' + toDir(dir) });
    }
    groups.push({
      id: info.id,
      title: info.title || info.id,
      topic: '待出新图',
      prompt: info.prompt,
      promptSource: '站点 data/gen-tasks.json',
      promptFound: !!info.prompt,
      needsPrompt: false,
      dir: toDir(dir),
      time: info.createdAt,
      images: [],
      noImages: true,
      gen: [info]
    });
  }
  if (!groups.length) return null;
  return {
    name: '站点 · 生成任务（未出图）',
    code: 'GEN',
    source: 'gen',
    rootKey: 'site',
    groups
  };
}

// ---------- 来源三：本地立绘档案 ----------
function scanPortraits(missing) {
  const root = SCAN_ROOTS.portrait;
  if (!fs.existsSync(root)) {
    missing.push({ source: 'portrait', label: root, detail: '目录不存在' });
    return null;
  }
  const groups = [];
  for (const ch of subDirs(root)) {
    const chDir = path.join(root, ch);
    const numMatch = ch.match(/^(\d+)/);
    const num = numMatch ? numMatch[1] : slug(ch);

    // 逐层走，图片在哪个子目录就按哪个目录成组，避免漏掉更深的归档目录
    const walk = dirAbs => {
      const files = imageFiles(dirAbs);
      if (files.length) {
        const subLabel = path.relative(chDir, dirAbs).replace(/\\/g, '/');
        const images = files.map((f, i) => ({
          n: i + 1,
          file: f,
          id: 'POR-' + num + '-' + slug(subLabel || 'root') + '-' + slug(path.basename(f, path.extname(f))),
          rel: path.relative(root, path.join(dirAbs, f)).replace(/\\/g, '/'),
          bytes: bytesOf(path.join(dirAbs, f)),
          mtime: mtimeOf(path.join(dirAbs, f))
        }));
        groups.push({
          id: ch + (subLabel ? '/' + subLabel : ''),
          title: ch + (subLabel ? ' · ' + subLabel : ''),
          topic: '本地立绘档案',
          prompt: '',
          promptSource: '本地档案（无 prompt 记录）',
          promptFound: false,
          needsPrompt: false,
          dir: toDir(dirAbs),
          images
        });
      }
      for (const sub of subDirs(dirAbs)) walk(path.join(dirAbs, sub));
    };
    walk(chDir);
  }
  if (!groups.length) {
    missing.push({ source: 'portrait', label: root, detail: '目录里没有找到图片' });
    return null;
  }
  return {
    batch: { name: '本地 · 人物立绘档案', code: 'POR', source: 'portrait', rootKey: 'portrait', groups },
    source: { key: 'portrait', name: '本地立绘档案' }
  };
}

// ---------- 来源四：站点素材 ----------
const LIB_SPECS = [
  { sub: '_gen_batch_20261109', code: 'GEN', name: '站点素材 · 生成批次 1109', bySub: true },
  { sub: 'refs', code: 'REF', name: '站点素材 · 参考图 refs', bySub: true },
  { sub: 'proj', code: 'PROJ', name: '站点素材 · 设计稿 proj', flat: true },
  { sub: 'evt', code: 'EVT', name: '站点素材 · 事件插图 evt', flat: true, skip: /_thumb/i }
];

function scanLib(missing) {
  const root = SCAN_ROOTS.lib;
  if (!fs.existsSync(root)) {
    missing.push({ source: 'lib', label: root, detail: '目录不存在' });
    return [];
  }
  const out = [];
  for (const spec of LIB_SPECS) {
    const base = path.join(root, spec.sub);
    if (!fs.existsSync(base)) {
      missing.push({ source: 'lib', label: spec.name, detail: '目录不存在：' + base });
      continue;
    }
    const groups = [];
    const makeGroup = (dirAbs, label, files) => {
      const stemOfFile = f => path.basename(f, path.extname(f));
      const isVersion = f => /-[dr]\d+$/i.test(stemOfFile(f));
      const imgOf = (f, n, extra) => {
        const stem = stemOfFile(f).toLowerCase();
        const rec = spec.sub === 'evt' ? (evtRecords().get(stem) || evtRecords().get(stem.replace(/-[dr]\d+$/i, '')) || null) : null;
        return Object.assign({
          n,
          file: f,
          id: 'LIB-' + spec.code + '-' + slug(label) + '-' + slug(stemOfFile(f)),
          rel: path.relative(root, path.join(dirAbs, f)).replace(/\\/g, '/'),
          bytes: bytesOf(path.join(dirAbs, f)),
          mtime: mtimeOf(path.join(dirAbs, f)),
          prompt: rec ? String(rec.prompt) : '',
          promptZh: rec ? String(rec.prompt_zh || '') : '',
          promptSource: rec ? 'evt_records.json' : '',
          gen: rec ? {
            model: rec.model || '', steps: rec.steps, cfg: rec.cfg, seed: rec.seed,
            sampler: rec.sampler || '', scheduler: rec.scheduler || '',
            size: rec.size || '', generatedAt: rec.generated_at || ''
          } : null
        }, extra || {});
      };
      // 派生/重做版本不进序号，避免把后面的图号顶掉
      const images = files.filter(f => !isVersion(f)).map((f, i) => imgOf(f, i + 1));
      files.filter(isVersion).forEach(f => images.push(imgOf(f, 0, {
        derived: /-d\d+$/i.test(stemOfFile(f)),
        redo: /-r\d+$/i.test(stemOfFile(f))
      })));
      groups.push({
        id: spec.sub + '/' + label,
        title: label,
        topic: '站点素材',
        prompt: '',
        promptSource: '站点素材目录（无 prompt 记录）',
        promptFound: false,
        needsPrompt: false,
        dir: toDir(dirAbs),
        images
      });
    };

    if (spec.bySub) {
      for (const sub of subDirs(base)) {
        const sd = path.join(base, sub);
        const files = imageFiles(sd).filter(f => !(spec.skip && spec.skip.test(f)));
        if (files.length) makeGroup(sd, sub, files);
      }
    } else {
      const files = imageFiles(base).filter(f => !f.startsWith('_') && !(spec.skip && spec.skip.test(f)));
      if (files.length) makeGroup(base, spec.sub, files);
    }

    if (groups.length) {
      out.push({ name: spec.name, code: 'LIB-' + spec.code, source: 'lib', rootKey: 'lib', groups });
    }
  }
  return out;
}

// ---------- 迭代留档：把同一「占位」在不同批次里的每一轮串成一条线 ----------
// 改动说明优先取 批次汇总.md 里对应轮次的小节 + 该组的表格行；取不到就用 prompt 长度变化兜底。
const ROUND_SECTION_RULES = [
  [/第六轮/, /2\.5|第五轮/],
  [/第五轮/, /2\.4|第四轮/],
  [/太空最终/, /2\.3|第三轮/],
  [/太空修正/, /2\.2|第二轮/],
  [/修正/, /2\.1|返工/]
];
function parseRoundDoc() {
  const p = path.join(SCAN_ROOTS.batch, '批次汇总.md');
  if (!fs.existsSync(p)) return [];
  const lines = readText(p).split(/\r?\n/);
  const secs = [];
  let cur = null;
  for (const line of lines) {
    const h = line.match(/^##\s+(.+)$/);
    if (h) { cur = { title: h[1].trim(), rows: [] }; secs.push(cur); continue; }
    if (!cur) continue;
    if (/^\|/.test(line) && !/^\|\s*:?-{2,}/.test(line)) {
      cur.rows.push(line.split('|').slice(1, -1).map(s => s.trim()));
    }
  }
  return secs;
}
function shortTitle(title) {
  return title.replace(/^\d+(\.\d+)*\s*/, '').replace(/（[^）]*\d{4}[^）]*）/g, '').trim();
}
function sectionForBatch(name, secs) {
  for (const rule of ROUND_SECTION_RULES) {
    if (!rule[0].test(name)) continue;
    const hit = secs.find(s => rule[1].test(s.title));
    if (hit) return hit;
  }
  return null;
}
function rowNoteFor(sec, gid) {
  for (const r of sec.rows) {
    if (!r[0]) continue;
    const cells = r[0].split(/\s*[\/、,，]\s*/);
    if (cells.some(c => c === gid || c.startsWith(gid))) {
      return r.slice(1)
        .filter(Boolean)
        .filter(c => !/^\d+$/.test(c) && !/^`.*`$/.test(c) && !/[\\]/.test(c))
        .join(' · ');
    }
  }
  return '';
}
function promptDelta(prev, next) {
  if (!prev) return '初版 prompt';
  if (prev === next) return 'prompt 未改';
  const d = next.length - prev.length;
  return 'prompt 调整（' + (d >= 0 ? '+' : '') + d + ' 字）';
}
function buildLineage(batchBatches) {
  const secs = parseRoundDoc();
  const byGroup = new Map();
  for (const b of batchBatches) {
    const sec = sectionForBatch(b.name, secs);
    for (const g of b.groups) {
      if (!byGroup.has(g.id)) byGroup.set(g.id, []);
      let change = '';
      if (sec) {
        const note = rowNoteFor(sec, g.id);
        change = shortTitle(sec.title) + (note ? '：' + note : '');
      }
      byGroup.get(g.id).push({ b, g, sec, change });
    }
  }
  for (const arr of byGroup.values()) {
    if (arr.length < 2) continue;
    arr.sort((a, b2) => String(a.g.time || '').localeCompare(String(b2.g.time || '')) || a.b.code.localeCompare(b2.b.code));
    const lineage = arr.map((r, i) => {
      let change = r.change;
      if (!change) {
        change = i === 0 ? promptDelta('', r.g.prompt) : promptDelta(arr[i - 1].g.prompt, r.g.prompt);
        if (i > 0 && arr[i - 1].g.images.length !== r.g.images.length) {
          change += ' · 张数 ' + arr[i - 1].g.images.length + '→' + r.g.images.length;
        }
      }
      return {
        round: i + 1,
        code: r.b.code,
        batch: r.b.name,
        time: r.g.time || '',
        change,
        count: r.g.images.length,
        imageIds: r.g.images.map(img => img.id)
      };
    });
    arr.forEach(r => { r.g.lineage = lineage; });
  }
}

// ---------- 中间栏信息：位置 / 内容 / 人物设定 / 分类 ----------
// 只取现有字段，取不到就写「未标注」，不猜。
function buildMeta(batches) {
  const crews = readJson(CREWS_FILE) || [];
  const byCrew = new Map(crews.map(c => [c.id, c]));
  const byName = new Map(crews.filter(c => c.name).map(c => [c.name, c]));
  for (const batch of batches) {
    const bn = batch.name || '';
    const cat = batchCategory(bn);
    for (const g of batch.groups) {
      if (g.meta) continue;
      const c = byCrew.get(g.id) || byName.get(String(g.title || '').split(' · ')[0]);
      const isAvatar = !!g.avatar;
      const where = [];
      let what = '';
      let setting = '未标注';
      let category = '';
      let from = '';
      if (batch.source === 'site' && c) {
        if (isAvatar) {
          where.push('站点首页 · 舰员头像墙（.ov-avatars）', '/crew/ 舰员列表 · 头像位', '舰员详情页页头');
        } else {
          where.push('/crew/' + String(g.id).toLowerCase() + ' 舰员详情页 · 主视觉');
        }
        const t0 = (g.gen || [])[0];
        if (t0 && t0.target) where.push('生成任务 target：' + t0.target);
        what = brief((c.name || g.id) + (isAvatar ? ' 头像' : ' 立绘') + ' · ' + (c.tagline || c.role || ''), 72);
        const prof = c.profile || {};
        setting = [
          c.name ? '姓名 ' + c.name : '',
          c.role ? '职务 ' + c.role : '',
          prof['性格'] ? '性格 ' + brief(prof['性格'], 46) : '',
          prof['出身'] ? '出身 ' + brief(prof['出身'], 36) : ''
        ].filter(Boolean).join('；') || '未标注';
        category = '角色 · ' + (isAvatar ? '头像' : '立绘');
        from = '站点数据（crews.json / gen-tasks.json）';
      } else {
        where.push('未标注');
        what = brief(g.prompt || g.title, 72) || '未标注';
        if (c) {
          const prof = c.profile || {};
          setting = [
            c.name ? '姓名 ' + c.name : '',
            c.role ? '职务 ' + c.role : '',
            prof['性格'] ? '性格 ' + brief(prof['性格'], 40) : ''
          ].filter(Boolean).join('；') || '未标注';
          category = (cat ? cat + ' · ' : '') + '人物';
          from = '批次清单（' + bn + '）+ crews.json';
        } else {
          category = cat || '未标注';
          from = batch.source === 'gen' ? '站点数据（gen-tasks.json）' : '批次清单（' + bn + '）';
        }
        if (batch.source === 'gen') {
          const t0 = (g.gen || [])[0];
          if (t0 && t0.target) where[0] = '生成任务 target：' + t0.target;
        }
      }
      g.meta = {
        imageRole: isAvatar ? '头像' : (c ? '立绘' : ''),
        where: where.join(' · '),
        what,
        setting,
        category,
        categoryFrom: from
      };
    }
  }
}

// ---------- 汇总 ----------
export function scanGallery() {
  const missing = [];
  const batches = [];

  const genTasks = readGenTasks(missing);
  const genTemplates = readGenTemplates(missing);
  const b = scanBatches(missing);
  if (b) batches.push(...b.batches);
  const crew = scanCrews(missing, genTasks);
  if (crew) batches.push(crew.batch);
  const genExtra = scanGenPending(genTasks, crew ? crew.mergedTaskIds : new Set(), missing);
  if (genExtra) batches.push(genExtra);
  const por = scanPortraits(missing);
  if (por) batches.push(por.batch);
  batches.push(...scanLib(missing));

  // 目录扫过但没有图可收的情况，单独列出来，不静默略过
  if (fs.existsSync(ENGINE_DIR)) {
    const n = countImages(ENGINE_DIR);
    missing.push({
      source: 'engine',
      label: '21_舰务模拟',
      detail: n ? '发现 ' + n + ' 张图（本次未纳入，目录以脚本为主）' : '目录内 0 张图片，没有可收录的图源'
    });
  }
  if (fs.existsSync(SITE_DATA_DIR)) {
    missing.push({
      source: 'site',
      label: '20_站点_React/src/data',
      detail: '只有 hull / ortho / decks 三份 JSON；ortho.json 引用的 assets/proj/xuanshu-ortho.png 已并入「设计稿 proj」'
    });
  }

  const stats = { batches: batches.length, groups: 0, images: 0, promptMissing: 0, bySource: {} };
  buildLineage(batches.filter(x => x.source === 'batch'));
  buildMeta(batches);
  // 编号必须唯一指到一个文件：重名时补 -2、-3，不静默合并
  const usedIds = new Set();
  for (const batch of batches) {
    for (const g of batch.groups) {
      for (const img of g.images) {
        let id = img.id;
        let k = 2;
        while (usedIds.has(id)) id = img.id + '-' + k++;
        img.id = id;
        usedIds.add(id);
      }
    }
  }
  for (const batch of batches) {
    const s = batch.source;
    if (!stats.bySource[s]) stats.bySource[s] = { batches: 0, groups: 0, images: 0 };
    stats.bySource[s].batches++;
    stats.bySource[s].groups += batch.groups.length;
    const n = batch.groups.reduce((a, g) => a + g.images.length, 0);
    stats.bySource[s].images += n;
    stats.groups += batch.groups.length;
    stats.images += n;
    if (s === 'batch') stats.promptMissing += batch.groups.filter(g => !g.promptFound).length;
  }

  return {
    scannedAt: new Date().toISOString(),
    roots: SCAN_ROOTS,
    sources: [
      { key: 'batch', name: '插图批量 20261117' },
      { key: 'site', name: '站点舰员立绘' },
      { key: 'portrait', name: '本地立绘档案' },
      { key: 'lib', name: '站点素材' },
      { key: 'gen', name: '生成任务（未出图）' }
    ],
    batches,
    stats,
    gen: {
      total: genTasks.length,
      withOutputs: genTasks.filter(t => genOutRel(t).length).length,
      noOutputs: genTasks.filter(t => !genOutRel(t).length).length,
      merged: crew ? crew.mergedTaskIds.size : 0,
      pendingGroups: genExtra ? genExtra.groups.length : 0
    },
    genTemplates,
    missing
  };
}
