// 读取 tasks/*.md，生成 tasks.js（window.TASKS）。零依赖。
// 用法：node gen.mjs [任务目录] [输出文件]
// 所有算法在生成端：步骤加权、父子归集、剩余时间、停滞、排序、汇总；页面只渲染。
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { ROOT, commandDir, memoryDir, readBoardConfig, loadJson } from './runtime.mjs';
import { buildCommits, writeCommits } from './commits.mjs';

const DIR = path.resolve(ROOT, process.argv[2] || 'tasks');
const OUT = path.resolve(ROOT, process.argv[3] || 'tasks.js');
// 可调参数：只从 board-config.json 读，缺项用默认值（停摆阈值 / 归档天数 / 默认权重）
const boardCfg = readBoardConfig();
const STALL_MS = Math.max(0.1, Number(boardCfg.stallHours) || 1) * 60 * 60 * 1000;
const ACTIVITY_STALL_MS = STALL_MS;            // 有 paths 时按机器活动判停滞，阈值同停滞阈值
const ARCHIVE_MS = Math.max(1, Number(boardCfg.archiveDays) || 7) * 24 * 60 * 60 * 1000;
const DEFAULT_W = Math.max(0.1, Number(boardCfg.defaultWeight) || 1);
// 自动补证来源（本机 Trae 的记录；没装 / 换机器 / 路径不存在就自动关闭，不报错）
const CMD_DIR = commandDir(boardCfg);
const MEM_DIR = memoryDir(boardCfg);
// 发起渠道：取值与显示名全部来自 channels.json；没配或任务没写 → 未记录
const CH_CFG = path.join(ROOT, 'channels.json');
let channelCfg = { values: [], unknown: '未记录' };
try {
  if (fs.existsSync(CH_CFG)) {
    const j = loadJson(CH_CFG, {});
    channelCfg = {
      values: Array.isArray(j.values) ? j.values : [],
      unknown: j.unknown || '未记录'
    };
  }
} catch (e) { console.error('channels.json 读取失败：' + e.message); }
const channelLabel = id => {
  if (!id) return channelCfg.unknown;
  const hit = channelCfg.values.find(v => v.id === id || v.label === id);
  return hit ? hit.label : channelCfg.unknown;
};
const ORDER = { blocked: 0, confirm: 1, running: 2, todo: 3, done: 4 };
const STATE = { todo: 0, doing: 0.5, done: 1 }; // 进行中按半计入
const STATE_ALIAS = { 未开始: 'todo', 进行中: 'doing', 完成: 'done' };
const pad = n => String(n).padStart(2, '0');
const stamp = d => `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;

function parseStep(line) {
  const parts = line.replace(/^-\s*/, '').split('|').map(s => s.trim());
  const step = { name: parts[0] || '未命名步骤', weight: DEFAULT_W, state: 'todo' };
  for (const seg of parts.slice(1)) {
    const m = seg.match(/^([^:=]+)[:=](.+)$/);
    if (!m) continue;
    const key = m[1].trim().toLowerCase();
    const val = m[2].trim();
    if (key === 'w' || key === 'weight') step.weight = Math.max(0.1, Number(val) || DEFAULT_W);
    if (key === 'st' || key === 'state') step.state = STATE_ALIAS[val] || (STATE[val] ? val : 'todo');
    if (key === 'start') step.start = Date.parse(val);
    if (key === 'end') step.end = Date.parse(val);
  }
  return step;
}

// 待办：挂在卡片下的事项清单，与卡片同源（tasks/*.md 的 todos: 段）
const TODO_STATE = { todo: 'todo', doing: 'todo', done: 'done', 待做: 'todo', 未完成: 'todo', 进行中: 'todo', 已完成: 'done' };
function parseTodo(line) {
  const parts = line.replace(/^-\s*/, '').split('|').map(s => s.trim());
  const item = { text: parts[0] || '未命名待办', status: 'todo', source: '', note: '', at: '', done_at: '' };
  for (const seg of parts.slice(1)) {
    const m = seg.match(/^([^:=]+)[:=](.+)$/);
    if (!m) continue;
    const key = m[1].trim().toLowerCase();
    const val = m[2].trim();
    if (key === 'st' || key === 'status') item.status = TODO_STATE[val] || TODO_STATE[val.toLowerCase()] || 'todo';
    if (key === 'src' || key === 'source') item.source = val;
    if (key === 'note') item.note = val;
    if (key === 'at') item.at = val;
    if (key === 'done' || key === 'done_at') item.done_at = val;
  }
  return item;
}

const INS_STATE = { todo: 'todo', doing: 'doing', done: 'done', blocked: 'blocked', 待做: 'todo', 进行中: 'doing', 已完成: 'done', 阻塞: 'blocked' };
// 只从确定状态推：待做=0、已完成=100；进行中/阻塞说不清就不填
const INS_PROGRESS = { todo: 0, done: 100 };

// 指令：卡片内的最小执行单元。进度可显式写“未记录”，不按状态猜。
function parseInstruction(line) {
  const parts = line.replace(/^-\s*/, '').split('|').map(s => s.trim());
  const ins = { text: parts[0] || '未命名指令', weight: DEFAULT_W, status: 'todo', progress: null, at: '', evidence: '', channel: '' };
  for (const seg of parts.slice(1)) {
    const m = seg.match(/^([^:=]+)[:=](.+)$/);
    if (!m) continue;
    const key = m[1].trim().toLowerCase();
    const val = m[2].trim();
    if (key === 'w' || key === 'weight') ins.weight = Math.max(0.1, Number(val) || DEFAULT_W);
    if (key === 'st' || key === 'status') ins.status = INS_STATE[val] || INS_STATE[val.toLowerCase()] || 'todo';
    if (key === 'p' || key === 'progress') {
      if (/未记录|未知|-$/.test(val)) ins.progress = null;
      else {
        const n = Number(val);
        ins.progress = Number.isFinite(n) ? Math.max(0, Math.min(100, n)) : null;
      }
    }
    if (key === 'at' || key === 'time') ins.at = /未记录|未知/.test(val) ? '' : val;
    if (key === 'ev' || key === 'evidence') ins.evidence = /未记录|未知/.test(val) ? '' : val;
    if (key === 'ch' || key === 'channel') ins.channel = /未记录|未知/.test(val) ? '' : val;
  }
  if (ins.progress == null && !parts.slice(1).some(s => /^(p|progress)\s*[:=]/i.test(s))) {
    ins.progress = INS_PROGRESS[ins.status] == null ? null : INS_PROGRESS[ins.status];
  }
  return ins;
}

function parse(file) {
  const row = { id: path.basename(file, path.extname(file)), steps: [], instructions: [], todos: [] };
  let section = '';
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    if (/^steps\s*:$/i.test(line)) { section = 'steps'; continue; }
    if (/^instructions\s*:$/i.test(line)) { section = 'instructions'; continue; }
    if (/^todos\s*:$/i.test(line)) { section = 'todos'; continue; }
    if (section === 'steps' && line.startsWith('-')) { row.steps.push(parseStep(line)); continue; }
    if (section === 'instructions' && line.startsWith('-')) { row.instructions.push(parseInstruction(line)); continue; }
    if (section === 'todos' && line.startsWith('-')) { row.todos.push(parseTodo(line)); continue; }
    const i = line.indexOf(':');
    if (i < 0) continue;
    const key = line.slice(0, i).trim().toLowerCase();
    const val = line.slice(i + 1).trim();
    if (key && val) row[key] = val;
    if (key) section = '';
  }
  return row;
}

function fmtDur(ms) {
  const min = Math.round(ms / 60000);
  if (min < 1) return '<1m';
  if (min >= 1440) return `${Math.floor(min / 1440)}d${Math.floor((min % 1440) / 60)}h`;
  if (min >= 60) return `${Math.floor(min / 60)}h${min % 60 ? min % 60 + 'm' : ''}`;
  return `${min}m`;
}
const shortName = n => {
  const s = n.split('·').pop().replace(/\s*\/.*$/, '').trim();
  return s.length > 12 ? s.slice(0, 12) + '…' : s;
};
const bannerName = n => n.replace(/^玄枢号\s*·\s*/, '');

// ---- 自动补证：只读旁证，不碰会话正文 ----
const normPath = p => p.replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase();
const ago = ms => {
  const m = Math.floor(ms / 60000);
  if (m < 1) return '刚刚';
  if (m < 60) return `${m}m 前`;
  if (m < 1440) return `${Math.floor(m / 60)}h 前`;
  return `${Math.floor(m / 1440)}d 前`;
};

// 命令执行记录：cwd + 结束时间（只读 execution.json）
function loadActivity() {
  const out = [];
  if (!CMD_DIR || !fs.existsSync(CMD_DIR)) return out;
  for (const d of fs.readdirSync(CMD_DIR)) {
    const f = path.join(CMD_DIR, d, 'execution.json');
    if (!fs.existsSync(f)) continue;
    try {
      const j = JSON.parse(fs.readFileSync(f, 'utf8'));
      const at = Number(j.finishedAtMs || j.startedAtMs);
      if (j.cwd && at) out.push({ cwd: normPath(j.cwd), at });
    } catch { /* 坏记录跳过 */ }
  }
  return out;
}

const gitCache = new Map();
function readGit(row) {
  const repo = String(row.repo || '').trim();
  if (!repo || !fs.existsSync(repo)) return null;
  const paths = String(row.git_paths || '').split(';').map(s => s.trim()).filter(Boolean);
  const key = repo + '||' + paths.join(';');
  if (gitCache.has(key)) return gitCache.get(key);
  let res = null;
  try {
    const args = ['-C', repo, 'log', '-1', '--format=%h|%cI'];
    if (paths.length) args.push('--', ...paths);
    const s = execFileSync('git', args, { encoding: 'utf8', timeout: 5000, stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    const [hash, iso] = s.split('|');
    const t = Date.parse(iso || '');
    if (hash) res = { hash, at: Number.isNaN(t) ? 0 : t };
  } catch { /* 不是仓库 / 没装 git → 留空 */ }
  gitCache.set(key, res);
  return res;
}

// 记忆摘要：只取今天的 outcome，拼一句「今天推进了什么」
function readToday() {
  if (!MEM_DIR || !fs.existsSync(MEM_DIR)) return null;
  const d = new Date(now);
  const ymd = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
  let best = null;
  for (const proj of fs.readdirSync(MEM_DIR)) {
    const dir = path.join(MEM_DIR, proj, ymd);
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir)) {
      if (!f.endsWith('.jsonl')) continue;
      let text;
      try { text = fs.readFileSync(path.join(dir, f), 'utf8'); } catch { continue; }
      for (const line of text.split(/\r?\n/)) {
        if (!line.trim()) continue;
        let j;
        try { j = JSON.parse(line); } catch { continue; }
        const t = Date.parse(j.message_summary_time || '');
        if (Number.isNaN(t) || typeof j.outcome !== 'string' || !j.outcome.trim()) continue;
        if (!best || t > best.at) best = { at: t, text: j.outcome };
      }
    }
  }
  if (!best) return null;
  return { at: best.at, text: best.text.length > 96 ? best.text.slice(0, 96) + '…' : best.text };
}


// ---- 提交号：sources.json 描述的三类只读来源（git log / 变更日志 / 部署报告）----
// 每次生成都重新采集并写 commits.json 缓存；无配置 / 无 git / 路径不存在 → 空表，卡片安静留空。
const CM = boardCfg.commitMatch;
let commitFeed = { commits: [], stats: {}, skipped: [] };
try {
  commitFeed = buildCommits();
  writeCommits(commitFeed);
} catch (e) { console.error('提交号来源读取失败：' + e.message); }
const COMMITS = Array.isArray(commitFeed.commits) ? commitFeed.commits : [];

const cmNorm = p => String(p || '').replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase();
const CM_STOP = new Set(['更新', '新增', '修复', '页面', '数据', '版本', '提交', '实现', '内容', '说明',
  '实测', '全部', '完成', '调整', '记录', '显示', '接入', '检查', '上线', '文件', '项目', '站点', '任务', '用户']);
function cmTokens(s) {
  const out = new Set();
  const t = String(s || '').replace(/[\s\p{P}\p{S}]/gu, '');
  for (let i = 0; i + 1 < t.length; i++) {
    const c = t.slice(i, i + 2);
    if (/^[\u4e00-\u9fa5]{2}$/.test(c) && !CM_STOP.has(c)) out.add(c);
  }
  return out;
}
const versionsIn = s => new Set([...String(s || '').matchAll(/v\d+\.\d+/gi)].map(m => m[0].toLowerCase()));
// 术语：连续 4 个汉字原样出现在变更说明里（如「算法引擎」「玩家标签」），比二元重叠更能锁定同一件事
function cmTerms(s) {
  const t = String(s || '').replace(/[^\u4e00-\u9fa5]/g, '');
  const out = new Set();
  for (let i = 0; i + 4 <= t.length; i++) out.add(t.slice(i, i + 4));
  return out;
}
function commitPathOk(entry, bases) {
  const w = cmNorm(entry.workspace);
  if (!w || !bases.length) return false;
  return bases.some(b => w === b || w.startsWith(b + '/') || b.startsWith(w + '/'));
}
// 在卡片的路径 + 时间窗内挑一条提交：版本号精确命中优先，其次字符重叠打分
function pickCommit(query, bases, from, to, minScore) {
  if (!COMMITS.length || !bases.length || !(to >= from)) return null;
  const pool = COMMITS.filter(e => e.at >= from && e.at <= to && commitPathOk(e, bases));
  if (!pool.length) return null;
  const vs = versionsIn(query);
  for (const e of pool) {
    if (e.version && vs.has(String(e.version).toLowerCase())) {
      return { entry: e, score: 1, basis: '版本 ' + e.version, type: 'version' };
    }
  }
  const q = cmTokens(query);
  if (!q.size) return null;
  let best = null;
  for (const e of pool) {
    const t = cmTokens(e.note + ' ' + (e.version || ''));
    let hit = 0;
    for (const c of q) if (t.has(c)) hit++;
    const score = hit / q.size;
    if (hit < 2) continue;
    if (!best || score > best.score) best = { entry: e, score, basis: `文本 ${hit}/${q.size}`, type: 'text' };
  }
  // 术语命中：命中术语更多的优先，同分取较新的提交
  const qt = cmTerms(query);
  let term = null;
  if (qt.size) {
    for (const e of pool) {
      const nt = cmTerms(e.note);
      let n = 0;
      for (const t of qt) if (nt.has(t)) n++;
      if (!n) continue;
      if (!term || n > term.n || (n === term.n && e.at > term.entry.at)) {
        term = { entry: e, score: Math.min(0.99, 0.5 + 0.1 * n), basis: `术语 ${n}`, type: 'term', term: n };
      }
    }
  }
  const floor = minScore == null ? CM.minScore : minScore;
  if (term && term.score >= floor) return term;
  if (best && best.score >= floor) return best;
  return null;
}
const commitText = e => e ? `${e.short} · ${stamp(new Date(e.at))}` : '';


const now = Date.now();
const activity = loadActivity();
const today = readToday();
const rows = fs.readdirSync(DIR)
  .filter(f => /\.(md|txt)$/i.test(f))
  .map(f => parse(path.join(DIR, f)))
  .filter(r => r.name);

const byId = new Map(rows.map(r => [r.id, r]));
rows.forEach(r => {
  r.parent = r.parent && byId.has(r.parent) && r.parent !== r.id ? r.parent : '';
  const w = Number(r.pw);
  r.pw = Number.isFinite(w) ? Math.max(0, w) : 1;
});
// 进度查询卡只用于追踪问询频次，不参与父卡进度归集
const isQuery = r => String(r.kind || '').toLowerCase() === 'query';
const childrenOf = id => rows.filter(r => r.parent === id && !isQuery(r));

// 递归归集：返回进度比例、剩余权重、剩余时间（ms）
const memo = new Map();
function aggregate(row, stack = new Set()) {
  if (memo.has(row.id)) return memo.get(row.id);
  stack.add(row.id);

  // 有指令时以指令为最小单元；进度未知的指令只计“未知”，不参与加权
  const hasIns = row.instructions.length > 0;
  let ownTotal = 0, ownEarned = 0, ownUnknown = 0;
  if (hasIns) {
    for (const ins of row.instructions) {
      if (ins.progress == null) { ownUnknown++; continue; }
      ownTotal += ins.weight;
      ownEarned += ins.weight * (ins.progress / 100);
    }
  } else {
    ownTotal = row.steps.reduce((s, x) => s + x.weight, 0);
    ownEarned = row.steps.reduce((s, x) => s + x.weight * STATE[x.state], 0);
  }
  let doneMs = 0, doneW = 0;
  row.steps.forEach(s => {
    if (s.state === 'done' && s.start && s.end && s.end > s.start) {
      doneMs += s.end - s.start;
      doneW += s.weight;
    }
  });

  const kids = childrenOf(row.id).filter(k => !stack.has(k.id));
  let kidW = 0, kidEarned = 0;
  const kidEtas = [];
  kids.forEach(k => {
    const a = aggregate(k, stack);
    if (a.frac == null) return;       // 子卡进度未知：不计入，也不拉低父卡
    kidW += k.pw;
    kidEarned += k.pw * a.frac;
    if (a.remainW > 0) kidEtas.push(a.etaMs);
  });

  const totalW = ownTotal + kidW;
  const earnedW = ownEarned + kidEarned;
  let frac = null;
  if (totalW > 0) frac = earnedW / totalW;
  else if (!hasIns) frac = Math.max(0, Math.min(1, (Number(row.progress) || 0) / 100));

  const ownRemain = ownTotal - ownEarned;
  const ownEta = ownRemain <= 0 ? 0 : (doneW > 0 ? ownRemain * (doneMs / doneW) : null);
  let etaMs;
  if (row.status === 'done') etaMs = 0;
  else if (totalW === 0) etaMs = null;
  else {
    const parts = [ownEta, ...kidEtas];
    etaMs = parts.some(p => p === null) ? null : Math.max(0, ...parts);
  }

  const res = { frac, remainW: totalW - earnedW, etaMs, unknownIns: ownUnknown };
  stack.delete(row.id);
  memo.set(row.id, res);
  return res;
}

const tasks = rows.map(row => {
  const status = ORDER[row.status] === undefined ? 'running' : row.status;
  const agg = aggregate(row);
  const kids = childrenOf(row.id).filter(k => k.id !== row.id);
  const kidSegs = kids.filter(k => aggregate(k).frac != null).map(k => k.pw);
  const totalW = row.instructions.length
    ? row.instructions.filter(i => i.progress != null).reduce((s, i) => s + i.weight, 0) + kidSegs.reduce((s, w) => s + w, 0)
    : row.steps.reduce((s, x) => s + x.weight, 0) + kidSegs.reduce((s, w) => s + w, 0);
  const progress = agg.frac == null ? null : Math.round(agg.frac * 100);
  const insDone = row.instructions.filter(i => i.status === 'done' || i.progress === 100).length;

  // 进度条上的权重边界刻度
  const ticks = [];
  if (totalW > 0) {
    let cum = 0;
    const segs = row.instructions.length
      ? [...row.instructions.filter(i => i.progress != null).map(i => i.weight), ...kidSegs]
      : [...row.steps.map(s => s.weight), ...kidSegs];
    segs.forEach((w, i) => {
      cum += w;
      if (i < segs.length - 1) ticks.push(Math.round((cum / totalW) * 100));
    });
  }

  const ts = Date.parse(row.updated_at || '');
  const valid = !Number.isNaN(ts);
  const startTs = Date.parse(row.started_at || '');
  const finishTs = Date.parse(row.finished_at || '');
  const hasStart = !Number.isNaN(startTs);
  const hasFinish = !Number.isNaN(finishTs);
  const forced = String(row.history || '').toLowerCase();
  const archived = forced === 'true' || forced === 'yes'
    ? true
    : forced === 'false' || forced === 'no'
      ? false
      : status === 'done' || (valid && now - ts > ARCHIVE_MS);

  // 最后活动：只认 tasks 里声明的 paths 命中的命令记录，不做猜测
  const bases = String(row.paths || '').split(';').map(s => s.trim()).filter(Boolean).map(normPath);
  let actAt = 0;
  if (bases.length) {
    for (const rec of activity) {
      if (rec.at <= actAt) continue;
      if (bases.some(b => rec.cwd === b || rec.cwd.startsWith(b + '/'))) actAt = rec.at;
    }
  }
  // 提交号：先按 sources.json 的来源匹配（版本号 / 术语 / 文本重叠），都取不到再看任务自己的 repo
  // 注意：不用 row.note 参与匹配——note 里的「v6.27 只记录了…」是在说明缺证，不是本卡的提交
  const cmQuery = [row.name, ...row.instructions.map(i => `${i.text} ${i.evidence}`)].filter(Boolean).join(' ');
  const cmRef = hasFinish ? finishTs : (hasStart ? startTs : ts);
  const cmReady = !Number.isNaN(cmRef) && cmRef;
  const cmFrom = cmReady ? (hasStart ? startTs : cmRef - CM.windowDays * 86400000) : 0;
  const cmTo = cmReady ? (hasFinish ? Math.max(finishTs, cmRef) : cmRef + 86400000) : 0;
  const pickFor = (q, min) => (cmReady ? pickCommit(q, bases, cmFrom, cmTo, min) : null);
  const insCommits = row.instructions.map(i => {
    const hit = pickFor(`${i.text} ${i.evidence || ''}`, CM.insMinScore);
    if (!hit) return null;
    // 指令级比卡级更保守：版本号可精确命中；术语要 2 个以上；纯文本要过半重叠
    if ((i.evidence || '').includes(hit.entry.short)) return null;  // 依据里已写过的提交不重复展示
    if (hit.type === 'version') return hit;
    if (hit.type === 'term' && hit.term >= 2) return hit;
    if (hit.type === 'text' && hit.score >= CM.insMinScore) return hit;
    return null;
  });
  let cardCommit = pickFor(cmQuery);
  let topIns = null;
  for (const h of insCommits) {
    if (!h) continue;
    if (!topIns || h.score > topIns.score || (h.score === topIns.score && h.entry.at > topIns.entry.at)) topIns = h;
  }
  if (topIns && (!cardCommit || cardCommit.score < topIns.score)) cardCommit = topIns;
  const git = readGit(row);
  const commitInfo = cardCommit
    ? {
        commit_text: commitText(cardCommit.entry),
        commit_hash: cardCommit.entry.hash,
        commit_source: `${cardCommit.entry.source} · ${cardCommit.basis}`
      }
    : {
        commit_text: git ? git.hash + (git.at ? ' · ' + stamp(new Date(git.at)).slice(0, 5) : '') : '',
        commit_hash: git ? git.hash : '',
        commit_source: git ? '任务 repo 的 git log' : ''
      };
  const insCommit = ins => {
    const idx = row.instructions.indexOf(ins);
    const hit = idx >= 0 ? insCommits[idx] : null;
    return hit ? { commit_text: commitText(hit.entry), commit_hash: hit.entry.hash, commit_source: `${hit.entry.source} · ${hit.basis}` } : null;
  };

  let stalled = false;
  let stallSource = '';
  if (!archived && status !== 'done' && status !== 'todo' && status !== 'confirm') {
    if (actAt) {
      stalled = now - actAt > ACTIVITY_STALL_MS;
      if (stalled) stallSource = 'activity';
    } else {
      stalled = !valid || now - ts > STALL_MS;
      if (stalled) stallSource = 'updated_at';
    }
  }
  const stateCount = k => row.steps.filter(s => s.state === k).length;

  const kidText = kids.length
    ? `子任务 ${kids.length} · ` + kids.map(k => {
        const f = aggregate(k).frac;
        return `${shortName(k.name)} ${f == null ? '未记录' : Math.round(f * 100) + '%'}`;
      }).join(' · ')
    : '';
  const stepText = row.instructions.length
    ? `指令 ${row.instructions.length} 条 · 已完成 ${insDone}`
    : kids.length
    ? `子任务 ${kids.length}` + (row.steps.length ? ` · 直接步骤 ${stateCount('done')}/${row.steps.length}` : '')
    : row.steps.length
      ? (stateCount('done') === row.steps.length
          ? `步骤 ${row.steps.length}/${row.steps.length} · 全部完成`
          : `步骤 ${stateCount('done')}/${row.steps.length}` + (stateCount('doing') ? ` · 进行中 ${stateCount('doing')}` : ''))
      : '手动进度（无步骤）';

  // 历史区补一个历时（优先任务级起止，其次步骤起止 → 最后更新）
  let elapsedText = '';
  if (hasStart && hasFinish && finishTs > startTs) elapsedText = fmtDur(finishTs - startTs);
  else {
    const starts = row.steps.map(s => s.start).filter(Boolean);
    const startMin = starts.length ? Math.min(...starts) : NaN;
    const endRef = hasFinish ? finishTs : ts;
    if (valid && !Number.isNaN(startMin) && endRef > startMin) elapsedText = fmtDur(endRef - startMin);
  }

function projectOf(row) {
  if (row.project) return String(row.project).trim();
  const hay = [row.name, row.phase, row.id, String(row.paths || '')].join(' ');
  for (const p of boardCfg.projects) {
    if (Array.isArray(p.ids) && p.ids.includes(row.id)) return p.id;
    if (!p.pattern) continue;
    try { if (new RegExp(p.pattern, 'i').test(hay)) return p.id; } catch { /* 配置写错就跳过 */ }
  }
  const last = boardCfg.projects[boardCfg.projects.length - 1] || {};
  return last.id || 'misc';
}

  let etaText;
  if (status === 'done') etaText = '已完成';
  else if (archived) etaText = '已归档';
  else if (agg.etaMs === null) etaText = '待估';
  else if (agg.etaMs === 0) etaText = '无剩余';
  else etaText = `余 ${fmtDur(agg.etaMs)}`;
  const etaFinish = status !== 'done' && !archived && agg.etaMs > 0
    ? stamp(new Date(now + agg.etaMs)) : '';

  return {
    id: row.id,
    name: row.name,
    project: projectOf(row),
    phase: row.phase || '未标注',
    status,
    progress,
    progress_source: row.instructions.length ? 'instructions' : (totalW > 0 ? 'steps' : 'manual'),
    parent_id: row.parent || '',
    is_parent: kids.length > 0,
    children: kids.map(k => {
      const f = aggregate(k).frac;
      return {
        id: k.id,
        name: k.name,
        progress: f == null ? null : Math.round(f * 100),
        status: k.status || 'running',
        weight: k.pw
      };
    }),
    kids_text: kidText,
    instructions: row.instructions.map(i => {
      const c = insCommit(i);
      return {
        text: i.text,
        status: i.status,
        progress: i.progress,
        weight: i.weight,
        at: i.at,
        at_text: i.at && !Number.isNaN(Date.parse(i.at)) ? stamp(new Date(Date.parse(i.at))) : '',
        evidence: i.evidence,
        channel: i.channel,
        channel_label: channelLabel(i.channel),
        commit_text: c ? c.commit_text : '',
        commit_hash: c ? c.commit_hash : '',
        commit_source: c ? c.commit_source : ''
      };
    }),
    instruction_stats: {
      total: row.instructions.length,
      done: insDone,
      doing: row.instructions.filter(i => i.status === 'doing').length,
      blocked: row.instructions.filter(i => i.status === 'blocked').length,
      unknown: row.instructions.filter(i => i.progress == null).length
    },
    steps: row.steps.map(s => ({ name: s.name, weight: s.weight, state: s.state })),
    step_stats: { total: row.steps.length, done: stateCount('done'), doing: stateCount('doing'), todo: stateCount('todo') },
    step_text: stepText,
    ticks,
    eta_text: etaText,
    eta_finish_text: etaFinish,
    elapsed_text: elapsedText,
    archived,
    updated_at: row.updated_at || '',
    updated_text: valid ? stamp(new Date(ts)) : '时间未知',
    started_at: hasStart ? new Date(startTs).toISOString() : '',
    started_text: hasStart ? stamp(new Date(startTs)) : '',
    finished_at: hasFinish ? new Date(finishTs).toISOString() : '',
    finished_text: hasFinish ? stamp(new Date(finishTs)) : '',
    finished_week: hasFinish && now - finishTs <= ARCHIVE_MS,
    time_source: row.time_source || '',
    source: row.source || 'manual',
    weights_est: String(row.weights || '').toLowerCase() === 'est',
    evidence: row.evidence || '',
    activity_at: actAt ? new Date(actAt).toISOString() : '',
    activity_text: actAt ? ago(now - actAt) : '',
    activity_abs: actAt ? stamp(new Date(actAt)) : '',
    commit_text: commitInfo.commit_text,
    commit_hash: commitInfo.commit_hash,
    commit_source: commitInfo.commit_source,
    _ts: valid ? ts : 0,
    _fin: hasFinish ? finishTs : 0,
    stalled,
    stall_source: stallSource,
    note: row.note || '',
    paths: bases,
    kind: String(row.kind || '').toLowerCase(),
    channel: row.channel || '',
    channel_label: channelLabel(row.channel),
    ask: row.ask || '',
    reply: row.reply || '',
    reply_full: row.reply_full || '',
    merged: Number(row.merged) || 0,
    installed: /^(true|yes|1|是)$/i.test(String(row.installed || '')),
    pushed: /^(true|yes|1|是)$/i.test(String(row.pushed || '')),
    token_in: row.token_in || '',
    token_out: row.token_out || '',
    token_platform: row.token_platform || '',
    duration_text: hasStart && hasFinish && finishTs > startTs ? fmtDur(finishTs - startTs) : (row.duration_text || ''),
    eta_note: row.eta_note || ''
  };
});

tasks.sort((a, b) =>
  a.archived !== b.archived ? (a.archived ? 1 : -1)
    : a.archived
      // 归档区：按完成时间倒序；没有完成时间的排在后面，再按更新时间
      ? (b._fin - a._fin) || (b._ts - a._ts)
      : ORDER[a.status] - ORDER[b.status] || b._ts - a._ts || (b.is_parent ? 1 : 0) - (a.is_parent ? 1 : 0));

if (!tasks.length) {
  console.error(`未在 ${DIR} 找到任务文件（*.md）`);
  process.exit(1);
}

// ---- 待办：把每张卡的 todos: 段摊平成全局清单，同时回挂到卡上 ----
// 发起时间：有完整时分就显示到分钟，只有日期就只显示日期；不补造时间
const stampDate = s => {
  const t = Date.parse(s || '');
  if (Number.isNaN(t)) return s || '';
  const d = new Date(t);
  const date = `${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  return /T\d{2}:\d{2}/.test(String(s)) ? `${date} ${pad(d.getHours())}:${pad(d.getMinutes())}` : date;
};
const todoList = [];
tasks.forEach(t => {
  const row = byId.get(t.id);
  const views = (row && row.todos ? row.todos : []).map((td, i) => {
    // at 是实际发起时间；历史条目只有日期就按日期排序
    const rawAt = String(td.at || '').trim();
    const realTs = rawAt ? Date.parse(rawAt) : NaN;
    let sortTs = realTs;
    let atSource = 'at';
    let fallbackText = '';
    // 没有真实发起时间时，用卡片已有的 updated_at 兜底，并标注来源，不按生成时间编造
    if (Number.isNaN(sortTs)) {
      atSource = 'none';
      const fbRaw = String(t.updated_at || '').trim();
      const fbTs = fbRaw ? Date.parse(fbRaw) : NaN;
      if (!Number.isNaN(fbTs)) {
        sortTs = fbTs;
        atSource = 'card_updated_at';
        fallbackText = stampDate(fbRaw);
      }
    }
    return {
      id: `${t.id}::${i + 1}`,
      key: `${t.id}-t${i + 1}`,
      text: td.text,
      status: td.status === 'done' ? 'done' : 'todo',
      source: td.source || '',
      note: td.note || '',
      at: rawAt,
      at_ts: Number.isNaN(sortTs) ? null : sortTs,
      at_text: Number.isNaN(realTs) ? '' : stampDate(rawAt),
      at_source: atSource,
      at_fallback_text: fallbackText,
      done_text: td.done_at ? stampDate(td.done_at) : '',
      task_id: t.id,
      task_name: t.name,
      task_phase: t.phase,
      project: t.project,
      card_status: t.status,
      card_progress: t.progress,
      card_archived: t.archived
    };
  });
  t.todos = views;
  t.todo_stats = {
    total: views.length,
    open: views.filter(v => v.status !== 'done').length,
    done: views.filter(v => v.status === 'done').length
  };
  views.forEach(v => todoList.push(v));
});
const projRank = id => {
  const i = boardCfg.projects.findIndex(p => p.id === id);
  return i < 0 ? 99 : i;
};
todoList.sort((a, b) =>
  (a.status === 'done' ? 1 : 0) - (b.status === 'done' ? 1 : 0)
  || projRank(a.project) - projRank(b.project));

const active = tasks.filter(t => !t.archived);
const history = tasks.filter(t => t.archived);
const stalledTasks = active.filter(t => t.stalled);
const count = s => tasks.filter(t => t.status === s).length;
const data = {
  generated_at: new Date(now).toISOString(),
  generated_text: (d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`)(new Date(now)),
  today_text: today ? today.text : '',
  today_at: today ? new Date(today.at).toISOString() : '',
  summary: {
    total: tasks.length,
    running: count('running'),
    todo: count('todo'),
    confirm: count('confirm'),
    done: tasks.filter(t => t.status === 'done').length,
    blocked: count('blocked'),
    stalled: stalledTasks.length,
    history: history.length,
    history_done: history.filter(t => t.status === 'done').length,
    history_idle: history.filter(t => t.status !== 'done').length,
    week_done: tasks.filter(t => t.status === 'done' && t.finished_week).length,
    timed: tasks.filter(t => t.started_at && t.finished_at).length,
    timed_certain: tasks.filter(t => t.started_at && t.finished_at && /确/.test(t.time_source)).length,
    stalled_text: stalledTasks.length
      ? `${stalledTasks.length} 条任务超过 ${boardCfg.stallHours} 小时没动 · ` + stalledTasks.map(t => bannerName(t.name)).join(' / ')
      : '',
    todo_total: todoList.length,
    todo_open: todoList.filter(t => t.status !== 'done').length,
    todo_done: todoList.filter(t => t.status === 'done').length,
    todo_cards: new Set(todoList.map(t => t.task_id)).size
  },
  channels: { values: channelCfg.values, unknown: channelCfg.unknown },
  // 页面用的运行参数：端口、项目分组都由配置生成，index.html 不再写死
  live_port: Number(boardCfg.livePort) || 7788,
  live_url: 'http://127.0.0.1:' + (Number(boardCfg.livePort) || 7788),
  stall_hours: boardCfg.stallHours,
  projects: boardCfg.projects.map(p => ({ id: p.id, label: p.label })),
  commit_stats: commitFeed.stats || {},
  todos: todoList,
  tasks: tasks.map(({ _ts, _fin, ...t }) => t)
};

const tmp = OUT + '.tmp';
fs.writeFileSync(tmp, 'window.TASKS = ' + JSON.stringify(data, null, 2) + ';\n', 'utf8');
fs.renameSync(tmp, OUT);

const s = data.summary;
console.log(`已生成 ${path.basename(OUT)}：${s.total} 条（活跃 ${active.length} / 归档 ${s.history} / 运行 ${s.running} / 阻塞 ${s.blocked} / 待确认 ${s.confirm} / 停滞 ${s.stalled} / 有确切起止 ${s.timed}）· 待办 ${s.todo_total}（未完成 ${s.todo_open} / 已完成 ${s.todo_done} / 关联卡片 ${s.todo_cards}）`);
