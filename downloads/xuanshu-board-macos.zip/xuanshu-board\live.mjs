// 本地实时进度服务：单进程、零依赖、只读。
// 职责：静态托管看板 + 监听 tasks/*.md / 命令执行记录 / git 提交，只在变动时增量重算，
//       用 SSE 把发生变化的百分比推给页面。空闲时不轮询、不跑定时任务。
// 用法：node live.mjs [--port 7788] [--root <看板目录>] [--tasks <任务目录>] [--cmd-dir <命令记录目录>]
import fs from 'node:fs';
import http from 'node:http';
import net from 'node:net';
import crypto from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import { execFileSync, execFile, spawn } from 'node:child_process';
import { AsyncLocalStorage } from 'node:async_hooks';
import { fileURLToPath } from 'node:url';
import { commandDir, openUrl, readBoardConfig, expandPath } from './runtime.mjs';
import { scanGallery, SCAN_ROOTS } from './gallery-scan.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const arg = (name, fallback) => {
  const i = argv.indexOf('--' + name);
  return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : fallback;
};
const CFG = readBoardConfig();

const ROOT = path.resolve(arg('root', HERE));
const TASKS_DIR = path.resolve(arg('tasks', path.join(ROOT, 'tasks')));
const PORT = Number(arg('port', process.env.TASKBOARD_PORT || CFG.livePort || 7788));
const HOST = '127.0.0.1';
const CMD_DIR = (() => { const p = arg('cmd-dir', commandDir(CFG)); return p ? expandPath(p) : ''; })();

// ---- 本机 ai 通道（OpenClaw / FlowyAIPC）：页面只探测 Gateway，派活复用同一套消息通道 ----
const AI_ROOT = process.env.TASKBOARD_AI_ROOT || 'C:\\Program Files\\GMKtec Claw\\resources';
const AI_PORT = Number(process.env.TASKBOARD_AI_PORT || 18789);
const AI_ENTRY = path.join(AI_ROOT, 'openclaw', 'openclaw.mjs');
function aiNode() {
  const direct = path.join(AI_ROOT, 'cli', 'node.exe');
  return fs.existsSync(direct) ? direct : path.join(AI_ROOT, 'bin', 'win32-x64', 'node.exe');
}
let aiCache = { at: 0, online: false };
function probeAi() {
  return new Promise(resolve => {
    const sock = net.connect({ host: HOST, port: AI_PORT });
    let done = false;
    const fin = v => { if (done) return; done = true; try { sock.destroy(); } catch { /* ignore */ } resolve(v); };
    sock.setTimeout(400, () => fin(false));
    sock.once('connect', () => fin(true));
    sock.once('error', () => fin(false));
  });
}
async function aiOnline() {
  if (Date.now() - aiCache.at < 5000) return aiCache.online;
  let online = false;
  if (fs.existsSync(AI_ENTRY) && fs.existsSync(aiNode())) online = await probeAi();
  aiCache = { at: Date.now(), online };
  return online;
}

// ---- 推进口径（与 gen.mjs 的静态算法同一套权重，只多一层实时证据信用）----
const DOING_BASE = 0.5;        // 进行中步骤的基础系数，和 gen.mjs 一致
const EVIDENCE_GAIN = 0.05;    // 每条新证据给该步 +5% 步权
const EVIDENCE_MAX = 4;        // 最多 4 条 → 进行中步骤最高 0.7，勾完成才到 1.0
const STATE_ALIAS = { 未开始: 'todo', 进行中: 'doing', 完成: 'done' };
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.md': 'text/plain; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2'
};

const LOG_FILE = path.join(ROOT, 'live.log');
try {
  if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 2 * 1024 * 1024) {
    fs.renameSync(LOG_FILE, LOG_FILE + '.1');
  }
} catch { /* 轮转失败就算了 */ }
function logLine(line) {
  try { fs.appendFileSync(LOG_FILE, line + '\n', 'utf8'); } catch { /* 日志写不了也不影响服务 */ }
}
const log = (...a) => {
  const s = '[live] ' + a.join(' ');
  console.log(s);
  logLine(new Date().toISOString() + ' ' + s);
};
const normPath = p => p.replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase();

// ---- 任务解析（字段口径与 gen.mjs 保持一致）----
function parseStep(line) {
  const parts = line.replace(/^-\s*/, '').split('|').map(s => s.trim());
  const step = { name: parts[0] || '未命名步骤', weight: 1, state: 'todo' };
  for (const seg of parts.slice(1)) {
    const m = seg.match(/^([^:=]+)[:=](.+)$/);
    if (!m) continue;
    const key = m[1].trim().toLowerCase();
    const val = m[2].trim();
    if (key === 'w' || key === 'weight') step.weight = Math.max(0.1, Number(val) || 1);
    if (key === 'st' || key === 'state') step.state = STATE_ALIAS[val] || (['todo', 'doing', 'done'].includes(val) ? val : 'todo');
    if (key === 'start') step.start = Date.parse(val);
  }
  return step;
}

// 指令：卡内最小单元，进度允许“未记录”（null），不按状态猜
const INS_STATE = { todo: 'todo', doing: 'doing', done: 'done', blocked: 'blocked', 待做: 'todo', 进行中: 'doing', 已完成: 'done', 阻塞: 'blocked' };
const INS_PROGRESS = { todo: 0, done: 100 };
function parseInstruction(line) {
  const parts = line.replace(/^-\s*/, '').split('|').map(s => s.trim());
  const ins = { text: parts[0] || '未命名指令', weight: 1, status: 'todo', progress: null };
  let explicit = false;
  for (const seg of parts.slice(1)) {
    const m = seg.match(/^([^:=]+)[:=](.+)$/);
    if (!m) continue;
    const key = m[1].trim().toLowerCase();
    const val = m[2].trim();
    if (key === 'w' || key === 'weight') ins.weight = Math.max(0.1, Number(val) || 1);
    if (key === 'st' || key === 'status') ins.status = INS_STATE[val] || INS_STATE[val.toLowerCase()] || 'todo';
    if (key === 'p' || key === 'progress') {
      explicit = true;
      if (/未记录|未知|-$/.test(val)) ins.progress = null;
      else { const n = Number(val); ins.progress = Number.isFinite(n) ? Math.max(0, Math.min(100, n)) : null; }
    }
  }
  if (!explicit) ins.progress = INS_PROGRESS[ins.status] == null ? null : INS_PROGRESS[ins.status];
  return ins;
}

function parseTask(file) {
  const row = { id: path.basename(file, path.extname(file)), steps: [], instructions: [] };
  let section = '';
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    if (/^steps\s*:$/i.test(line)) { section = 'steps'; continue; }
    if (/^instructions\s*:$/i.test(line)) { section = 'instructions'; continue; }
    if (line.startsWith('-') && section) {
      if (section === 'steps') { row.steps.push(parseStep(line)); continue; }
      row.instructions.push(parseInstruction(line)); continue;
    }
    const i = line.indexOf(':');
    if (i < 0) continue;
    const key = line.slice(0, i).trim().toLowerCase();
    const val = line.slice(i + 1).trim();
    if (key && val) row[key] = val;
    if (key) section = '';
  }
  row.parent = row.parent || '';
  const w = Number(row.pw);
  row.pw = Number.isFinite(w) ? Math.max(0, w) : 1;
  return row;
}

const tasks = new Map();          // id -> row
const progress = new Map();       // id -> 0..100
const isQuery = row => String(row.kind || '').toLowerCase() === 'query';
const childrenOf = id => [...tasks.values()].filter(r => r.parent === id && !isQuery(r));
const parentsOk = row => row.parent && row.parent !== row.id && tasks.has(row.parent);

function loadAll() {
  if (!fs.existsSync(TASKS_DIR)) {
    log('任务目录不存在：' + TASKS_DIR);
    process.exit(1);
  }
  for (const f of fs.readdirSync(TASKS_DIR)) {
    if (!/\.(md|txt)$/i.test(f)) continue;
    try {
      const row = parseTask(path.join(TASKS_DIR, f));
      if (row.name) tasks.set(row.id, row);
    } catch (err) {
      log('跳过坏文件', f, err.message);
    }
  }
  for (const row of tasks.values()) if (!parentsOk(row)) row.parent = '';
}

// ---- 证据：命令执行记录 + git 提交 ----
const commands = new Map();       // executionId -> { cwd, at }
const commitCache = new Map();    // id|since -> count

function loadCommands() {
  if (!CMD_DIR || !fs.existsSync(CMD_DIR)) return 0;
  let n = 0;
  for (const d of fs.readdirSync(CMD_DIR)) {
    const f = path.join(CMD_DIR, d, 'execution.json');
    try {
      const j = JSON.parse(fs.readFileSync(f, 'utf8'));
      const at = Number(j.finishedAtMs || j.startedAtMs || j.createdAtMs);
      if (j.cwd && at) { commands.set(d, { cwd: normPath(j.cwd), at }); n++; }
    } catch { /* 正在写入 / 坏记录 */ }
  }
  return n;
}

function commitCount(row, since) {
  const repo = String(row.repo || '').trim();
  if (!repo || !fs.existsSync(repo)) return 0;
  const key = row.id + '|' + since;
  if (commitCache.has(key)) return commitCache.get(key);
  let n = 0;
  try {
    const sub = String(row.git_paths || '').split(';').map(s => s.trim()).filter(Boolean);
    const out = execFileSync('git', ['-C', repo, 'log', '--since=' + new Date(since).toISOString(), '--format=%H', ...(sub.length ? ['--', ...sub] : [])],
      { encoding: 'utf8', timeout: 4000, stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    n = out ? out.split('\n').length : 0;
  } catch { /* 不是仓库 / 没装 git → 0 */ }
  commitCache.set(key, n);
  return n;
}

// 某步在「步骤开始 → 现在」之间收到的证据条数：命令记录 + 提交
function evidenceFor(row, step) {
  const since = step.start || Date.parse(row.started_at || '') || Date.now() - 24 * 3600 * 1000;
  const bases = String(row.paths || '').split(';').map(s => s.trim()).filter(Boolean).map(normPath);
  let n = 0;
  if (bases.length) {
    for (const rec of commands.values()) {
      if (rec.at < since) continue;
      if (bases.some(b => rec.cwd === b || rec.cwd.startsWith(b + '/'))) n++;
    }
  }
  return n + commitCount(row, since);
}

function stepValue(row, step) {
  if (step.state === 'done') return 1;
  if (step.state !== 'doing') return 0;
  const n = Math.min(EVIDENCE_MAX, evidenceFor(row, step));
  return Math.min(0.95, DOING_BASE + EVIDENCE_GAIN * n);
}

function fracOf(row, stack = new Set()) {
  if (stack.has(row.id)) {
    const p = progress.get(row.id);
    return p == null ? null : p / 100;
  }
  stack.add(row.id);
  const hasIns = row.instructions.length > 0;
  let ownTotal = 0, ownEarned = 0;
  if (hasIns) {
    for (const ins of row.instructions) {
      if (ins.progress == null) continue;      // 未记录不参与加权，也不拉低
      ownTotal += ins.weight;
      ownEarned += ins.weight * (ins.progress / 100);
    }
  } else {
    ownTotal = row.steps.reduce((s, x) => s + x.weight, 0);
    ownEarned = row.steps.reduce((s, x) => s + x.weight * stepValue(row, x), 0);
  }
  let kidW = 0, kidEarned = 0;
  for (const k of childrenOf(row.id)) {
    const f = fracOf(k, stack);
    if (f == null) continue;                   // 子卡算不出来 → 整张跳过
    kidW += k.pw;
    kidEarned += k.pw * f;
  }
  stack.delete(row.id);
  const total = ownTotal + kidW;
  if (total > 0) return (ownEarned + kidEarned) / total;
  if (hasIns) return null;                     // 指令进度全未记录 → 父卡也写未记录
  const manual = Number(row.progress);
  return Number.isFinite(manual) ? Math.max(0, Math.min(1, manual / 100)) : 0;
}

// ---- 增量重算：只算受影响的任务与它的祖先 ----
function recompute(id, changed, seen) {
  if (seen.has(id)) return;
  seen.add(id);
  const row = tasks.get(id);
  if (!row) return;
  for (const k of childrenOf(id)) recompute(k.id, changed, seen);
  const f = fracOf(row);
  const p = f == null ? null : Math.round(f * 100);
  if (progress.get(id) !== p) {
    progress.set(id, p);
    changed.push({ id, progress: p });
  }
}

function recomputeTree(id) {
  const changed = [];
  const seen = new Set();
  recompute(id, changed, seen);
  let p = tasks.get(id) && tasks.get(id).parent;
  let guard = 0;
  while (p && tasks.has(p) && guard++ < 50) {
    recompute(p, changed, seen);
    p = tasks.get(p).parent;
  }
  return changed;
}

// ---- SSE ----
const clients = new Set();
function push(changed) {
  if (!changed.length || !clients.size) return;
  const frame = 'data: ' + JSON.stringify({ at: Date.now(), items: changed }) + '\n\n';
  for (const res of clients) {
    try { res.write(frame); } catch { clients.delete(res); }
  }
}

// ---- 状态跃迁提醒（完成 / 停滞）----
const CFG_FILE = path.join(ROOT, 'board-config.json');
let stallMs = 60 * 60 * 1000;
try {
  if (fs.existsSync(CFG_FILE)) stallMs = Math.max(0.1, Number(JSON.parse(fs.readFileSync(CFG_FILE, 'utf8')).stallHours) || 1) * 3600000;
} catch { /* 配置坏了用默认 */ }
const alertsOn = !argv.includes('--no-popup');
const OPEN_GAP_MS = 10 * 60 * 1000;      // 服务端打开页面的冷却，避免连着弹
let lastOpenAt = 0;
const armed = new Map();                 // id -> {status, stalled}

function stateOf(row) {
  const ts = Date.parse(row.updated_at || '');
  const open = row.status !== 'done' && row.status !== 'todo' && row.status !== 'confirm';
  const stalled = open && !Number.isNaN(ts) && Date.now() - ts > stallMs;
  return { status: row.status, stalled };
}
function detect(id) {
  const row = tasks.get(id);
  if (!row || isQuery(row)) return null;
  const now = stateOf(row);
  const prev = armed.get(id);
  armed.set(id, now);
  if (!prev) return null;
  if (now.status === 'done' && prev.status !== 'done') {
    return { type: 'done', id, name: row.name, detail: '已完成', at: Date.now() };
  }
  if (now.stalled && !prev.stalled) {
    const ts = Date.parse(row.updated_at || '');
    const h = Number.isNaN(ts) ? '' : '，已 ' + Math.round((Date.now() - ts) / 360000) / 10 + ' 小时没更新';
    return { type: 'stall', id, name: row.name, detail: '可能停滞' + h, at: Date.now() };
  }
  return null;
}
function notify(list) {
  const arr = list.filter(Boolean);
  if (!arr.length) return;
  if (clients.size) {
    const frame = 'data: ' + JSON.stringify({ at: Date.now(), alerts: arr }) + '\n\n';
    for (const res of clients) { try { res.write(frame); } catch { clients.delete(res); } }
  }
  if (alertsOn && !clients.size && Date.now() - lastOpenAt > OPEN_GAP_MS) {
    lastOpenAt = Date.now();
    try {
      openUrl('http://' + HOST + ':' + PORT + '/');
    } catch { /* 打不开浏览器不影响 SSE */ }
  }
  log('提醒：' + arr.map(a => a.name + ' ' + a.detail).join(' / '));
}

// 合并短时间内的重复事件（编辑器保存 / 一次命令收尾常连着触发多次）
const timers = new Map();
function debounce(key, ms, fn) {
  const old = timers.get(key);
  if (old) clearTimeout(old);
  timers.set(key, setTimeout(() => { timers.delete(key); fn(); }, ms));
}

// ---- 监听：任务文件 ----
function watchTasks() {
  fs.watch(TASKS_DIR, { persistent: true }, (evt, filename) => {
    if (filename && !/\.(md|txt)$/i.test(filename)) return;
    debounce('task:' + (filename || '*'), 120, () => {
      try {
        if (!filename) { rescanAll(); return; }
        const id = path.basename(filename, path.extname(filename));
        const full = path.join(TASKS_DIR, filename);
        if (!fs.existsSync(full)) {
          const row = tasks.get(id);
          tasks.delete(id);
          progress.delete(id);
          armed.delete(id);
          if (row) for (const k of [...tasks.values()]) if (k.parent === id) k.parent = '';
          return;   // 已删除的卡片等页面刷新后再消失，当前页保持原样
        }
        const row = parseTask(full);
        if (!row.name) return;
        if (!parentsOk(row)) row.parent = '';
        tasks.set(id, row);
        push(recomputeTree(id));
        notify([detect(id)]);
      } catch (err) {
        log('任务变动处理失败', err.message);
      }
    });
  });
}

function rescanAll() {
  const seen = new Set();
  for (const f of fs.readdirSync(TASKS_DIR)) {
    if (!/\.(md|txt)$/i.test(f)) continue;
    const id = path.basename(f, path.extname(f));
    seen.add(id);
    try { tasks.set(id, parseTask(path.join(TASKS_DIR, f))); } catch { /* 半写入文件跳过 */ }
  }
  for (const id of [...tasks.keys()]) if (!seen.has(id)) tasks.delete(id);
  const changed = [];
  for (const id of tasks.keys()) recompute(id, changed, new Set());
  push(changed);
}

// ---- 监听：命令执行记录 ----
function watchCommands() {
  if (!CMD_DIR || !fs.existsSync(CMD_DIR)) {
    log('未找到命令执行记录目录，命令证据关闭：' + CMD_DIR);
    return;
  }
  const onFile = rel => {
    const id = String(rel).split(/[\\/]/)[0];
    const f = path.join(CMD_DIR, id, 'execution.json');
    if (!fs.existsSync(f)) return;
    try {
      const j = JSON.parse(fs.readFileSync(f, 'utf8'));
      const at = Number(j.finishedAtMs || 0);
      if (!j.cwd || !at) return;                       // 还在跑，等收尾事件
      const prev = commands.get(id);
      if (prev && prev.at === at) return;              // 同一份记录，不重复算
      commands.set(id, { cwd: normPath(j.cwd), at });
      const bases = [];
      for (const row of tasks.values()) {
        const p = String(row.paths || '').split(';').map(s => s.trim()).filter(Boolean).map(normPath);
        if (p.some(b => normPath(j.cwd) === b || normPath(j.cwd).startsWith(b + '/'))) bases.push(row.id);
      }
      if (!bases.length) return;
      const changed = [];
      for (const id2 of bases) for (const c of recomputeTree(id2)) if (!changed.some(x => x.id === c.id)) changed.push(c);
      push(changed);
    } catch { /* 文件正在写，等下一次事件 */ }
  };
  try {
    fs.watch(CMD_DIR, { recursive: true, persistent: true }, (evt, rel) => {
      if (!rel || !/execution\.json$/i.test(rel)) return;
      debounce('cmd:' + rel, 220, () => onFile(rel));
    });
  } catch (err) {
    log('递归监听命令记录失败（' + err.message + '），改为只监听一级目录');
    fs.watch(CMD_DIR, { persistent: true }, (evt, name) => {
      if (name) debounce('cmd:' + name, 300, () => onFile(name));
    });
  }
}

// ---- 监听：git 提交 ----
function watchGit() {
  const repos = new Map();
  for (const row of tasks.values()) {
    const repo = String(row.repo || '').trim();
    if (repo) repos.set(repo, true);
  }
  for (const repo of repos.keys()) {
    const head = path.join(repo, '.git', 'logs', 'HEAD');
    const ref = fs.existsSync(head) ? head : path.join(repo, '.git', 'HEAD');
    if (!fs.existsSync(ref)) continue;
    try {
      fs.watch(ref, { persistent: true }, () => {
        debounce('git:' + repo, 250, () => {
          for (const row of tasks.values()) {
            if (String(row.repo || '').trim() !== repo) continue;
            for (const key of [...commitCache.keys()]) if (key.startsWith(row.id + '|')) commitCache.delete(key);
            push(recomputeTree(row.id));
          }
        });
      });
    } catch { /* 无权限就不监听，不影响其它证据 */ }
  }
}

// ---- HTTP ----
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}
function json(res, obj, code = 200) {
  cors(res);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

// ---- 插图判定回传 ----
// 字段归属：页面只通过 POST 追加提交（imageId/verdict/suggestion/submittedAt，receipt=submitted）；
// 维护者（agent）只回写 receipt=read|handled、readAt/handledAt/note，不改判定本身。
// pass_base = 通过并以该图为基底出新版：baseImageId 记录基底，derivedImageId 由维护者在新版本号确定后回写。
const FEEDBACK_FILE = path.join(ROOT, 'gallery-feedback.json');
const FEEDBACK_DOC = {
  owner: '页面 / 出图 / 站点 各自只写自己的字段；改动一律按记录 id 读改写，禁止整文件覆盖',
  receipt: 'submitted=页面已提交 → read=维护者已读取 → handled=维护者已处理',
  verdicts: {
    pass: '通过',
    pass_base: '通过，并以此为基础出新版本；baseImageId 指向基底图，derivedImageId 等新版本落地后由维护者回写',
    fail: '未通过',
    hold: '待定',
    cannot: '无法生成：出图侧按修改建议出不来图时写入（也接受 nogenerate / unable 等别名，统一存为 cannot）；建议内容原样保留',
    derive: '出新版（派生动作，不是判定；baseImageId=基底，derivedImageId=新版本占位 id）',
    redo: '修改重做（按未通过建议重做，不是判定；baseImageId=原图，derivedImageId=重做图 id，suggestion=对应建议）'
  },
  patch: 'POST 带 id = 按该条记录合并字段（只覆盖请求里出现的键）；不带 id = 追加一条。derive / redo 记录不会被改判，遇到其他判定会另起一条，派生/重做关系保留',
  publishUrl: '站点侧发布后回写的可点击链接；也接受 publishedUrl / siteUrl / url / link / pageUrl，统一存为 publishUrl',
  stage: '派生请求进度：draft=待确定（仅本地）→ submitted=已提交待 agent 读取 → locked=已读取已锁定 → generating=生成中 → done=已出图（真图落地）',
  terms: '本条判定引用到的固化词条 [{id,keyword}]；建议正文里的 #关键词 原样保留，接收方按 id 取解释',
  writableByPage: ['imageId', 'batch', 'group', 'verdict', 'suggestion', 'prompt', 'stage', 'submittedAt', 'baseImageId', 'derivedImageId', 'terms'],
  writableByMaintainer: ['receipt', 'readAt', 'handledAt', 'note', 'stage', 'derivedImageId', 'derivedAt', 'publishUrl']
};

// ---- 固化词条库：关键词 → 完整解释 + 案例图 ----
// 页面可增删改；每次写入同步导出一份给生图 agent 的 JSON（默认放在批次根目录）。
const TERMS_FILE = path.join(ROOT, 'terms.json');
const TERMS_EXPORT_FILE = arg('terms-export', process.env.TASKBOARD_TERMS_EXPORT
  // 只有正式实例（--root 未改，即看板目录本身）才写项目默认导出路径；
  // 测试实例一律导出到自己的 --root，避免把真实 词条库.json 覆盖成空
  || (ROOT === HERE ? 'D:/玄枢号项目/25_插图批量_20261117/词条库.json' : path.join(ROOT, '词条库.json')));
const TERMS_DOC = {
  owner: '页面增删改；服务每次写入后同步导出给生图 agent 的 JSON',
  mark: '正文里的 #关键词 原样保留；账本 terms 回传 [{id,keyword}]，接收方按 id 取解释',
  fields: {
    id: '稳定 id（term-<hash>）',
    keyword: '不含 # 的关键词',
    explain: '完整解释：画面上怎么做',
    cases: '案例图 [{imageId,rootKey,rel,abs}]',
    source: '来源（如 风格基准.md §2.5）',
    updatedAt: 'ISO 时间'
  }
};
function readTerms() {
  try {
    const j = JSON.parse(fs.readFileSync(TERMS_FILE, 'utf8'));
    if (j && Array.isArray(j.terms)) {
      return { schemaVersion: 1, updatedAt: j.updatedAt || null, _doc: j._doc || TERMS_DOC, terms: j.terms };
    }
  } catch { /* 文件还没建 */ }
  return { schemaVersion: 1, updatedAt: null, _doc: TERMS_DOC, terms: [] };
}
function termIdFor(keyword, terms, avoidId) {
  let h = 0;
  for (const ch of String(keyword)) h = (h * 31 + ch.codePointAt(0)) >>> 0;
  let id = 'term-' + h.toString(36);
  let n = 1;
  while (terms.some(t => t.id === id && t.id !== avoidId)) id = 'term-' + h.toString(36) + '-' + (++n);
  return id;
}
function normCases(list) {
  return (Array.isArray(list) ? list : []).slice(0, 12).map(c => {
    const o = typeof c === 'string' ? { imageId: c } : (c || {});
    const imageId = String(o.imageId || '').slice(0, 240);
    const rootKey = String(o.rootKey || '').slice(0, 20);
    const rel = String(o.rel || '').slice(0, 500);
    let abs = String(o.abs || '');
    if (!abs && rootKey && rel && SCAN_ROOTS[rootKey]) abs = path.join(SCAN_ROOTS[rootKey], ...rel.split('/'));
    return { imageId, rootKey, rel, abs };
  }).filter(c => c.imageId || c.abs);
}
// 审阅总结：手动保存 / 本地模型按最近修改意见生成
const SUMMARY_FILE = path.join(ROOT, 'summary.json');
const SUMMARY_URL = process.env.TASKBOARD_AI_URL || 'http://127.0.0.1:1234/v1/chat/completions';
const SUMMARY_MODEL = process.env.TASKBOARD_AI_MODEL || 'qwen/qwen3.5-35b-a3b';
function readSummary() {
  try {
    const j = JSON.parse(fs.readFileSync(SUMMARY_FILE, 'utf8'));
    if (j && typeof j === 'object') {
      return { summary: '', mode: '', basedOn: 0, model: '', updatedAt: null, ...j };
    }
  } catch { /* 还没写过 */ }
  return { summary: '', mode: '', basedOn: 0, model: '', updatedAt: null };
}
function writeSummary(doc) {
  const tmp = SUMMARY_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(doc, null, 2), 'utf8');
  fs.renameSync(tmp, SUMMARY_FILE);
}

// ---- 项目注册表：每个项目一套 workDir / queue / output / library ----
const WORK_PY = 'C:/Users/pamphile/AI/ComfyUI/venv/Scripts/python.exe';
const PROJECTS_FILE = path.join(ROOT, 'projects.json');
const ALS = new AsyncLocalStorage();
const DEFAULT_PROJECT = {
  id: 'xuanshu', name: '玄枢号',
  root: 'D:/玄枢号项目',
  workDir: 'D:/玄枢号项目/_自动执行',
  groupsFile: path.join(ROOT, 'board-projects.json'),
  pipeline: 'character_illustration',
  runner: 'auto_work.py', builder: 'library_build.py',
  defaultAspect: '9:16', style: 'thick_oil_cold'
};
function normalizeProject(p) {
  const workDir = path.resolve(String(p.workDir || '').trim());
  const root = path.resolve(String(p.root || path.dirname(workDir)).trim());
  return {
    id: String(p.id || '').trim(), name: String(p.name || p.id || '').trim(),
    root, workDir,
    queue: path.join(workDir, 'queue.jsonl'),
    state: path.join(workDir, 'work-state.json'),
    lib: path.join(workDir, 'library.json'),
    thumbs: path.join(workDir, 'thumbs'),
    out: path.join(workDir, 'output'),
    groupsFile: p.groupsFile ? path.resolve(String(p.groupsFile)) : path.join(workDir, 'board-projects.json'),
    pipeline: String(p.pipeline || 'character_illustration'),
    runner: String(p.runner || 'auto_work.py'),
    builder: String(p.builder || 'library_build.py'),
    defaultAspect: String(p.defaultAspect || '3:4'),
    style: String(p.style || ''),
    sourceFile: String(p.sourceFile || '')
  };
}
function readProjectsDoc() {
  try {
    const j = JSON.parse(fs.readFileSync(PROJECTS_FILE, 'utf8'));
    const list = (Array.isArray(j) ? j : (j.projects || [])).map(normalizeProject).filter(p => p.id && p.workDir);
    if (!list.length) throw new Error('empty');
    const current = String(j.current || '') || list[0].id;
    return { current: list.some(p => p.id === current) ? current : list[0].id, projects: list };
  } catch {
    const p = [normalizeProject(DEFAULT_PROJECT)];
    return { current: p[0].id, projects: p };
  }
}
function writeProjectsDoc(doc) {
  const tmp = PROJECTS_FILE + '.tmp';
  const payload = {
    current: doc.current,
    projects: (doc.projects || []).map(p => ({
      id: p.id, name: p.name, root: p.root, workDir: p.workDir,
      groupsFile: p.groupsFile, pipeline: p.pipeline, runner: p.runner, builder: p.builder,
      defaultAspect: p.defaultAspect, style: p.style, sourceFile: p.sourceFile
    }))
  };
  fs.writeFileSync(tmp, JSON.stringify(payload, null, 2), 'utf8');
  fs.renameSync(tmp, PROJECTS_FILE);
}
function ensureProjectDirs(p) {
  for (const d of [p.workDir, p.out, p.thumbs]) {
    try { fs.mkdirSync(d, { recursive: true }); } catch { /* ignore */ }
  }
  if (!fs.existsSync(p.queue)) fs.writeFileSync(p.queue, '', 'utf8');
}
function resolveProject(qs) {
  const doc = readProjectsDoc();
  const want = String((qs && (qs.get('project') || qs.get('p'))) || '').trim();
  return doc.projects.find(p => p.id === want) || doc.projects.find(p => p.id === doc.current) || doc.projects[0];
}
function curProj() { return ALS.getStore() || readProjectsDoc().projects[0]; }

function readWorkQueue() {
  try {
    return fs.readFileSync(curProj().queue, 'utf8').split(/\r?\n/).filter(Boolean)
      .map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return []; }
}
function writeWorkQueue(rows) {
  const q = curProj().queue;
  const tmp = q + '.tmp';
  fs.writeFileSync(tmp, rows.map(r => JSON.stringify(r)).join('\n') + '\n', 'utf8');
  fs.renameSync(tmp, q);
}
function readWorkState() {
  try {
    return { running: false, phase: 'idle', message: '', current: '', total: 0, done: 0, ok: 0, fail: 0, ...JSON.parse(fs.readFileSync(curProj().state, 'utf8')) };
  } catch { return { running: false, phase: 'idle', message: '', current: '', total: 0, done: 0, ok: 0, fail: 0 }; }
}
function readProjectList() {
  try {
    const j = JSON.parse(fs.readFileSync(curProj().groupsFile, 'utf8'));
    return Array.isArray(j) ? j.map(String) : [];
  } catch { return []; }
}
function writeProjectList(list) {
  const f = curProj().groupsFile;
  const tmp = f + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify([...new Set(list.filter(Boolean))], null, 2), 'utf8');
  fs.renameSync(tmp, f);
}
// ---- 常用建议：手动收藏 + 最近用过的指令 + 保持项 ----
const PRESET_FILE = path.join(ROOT, 'board-presets.json');
const KEEP_DEFAULT = ['脸', '身材', '装束', '背景'];
function readPresetDoc() {
  let j = null;
  try { j = JSON.parse(fs.readFileSync(PRESET_FILE, 'utf8')); } catch { j = null; }
  const arr = Array.isArray(j) ? j : (j && Array.isArray(j.saved) ? j.saved : []);
  const saved = arr.map(s => String(s || '').trim()).filter(Boolean).slice(0, 40);
  let keeps = (j && !Array.isArray(j) && Array.isArray(j.keeps)) ? j.keeps : KEEP_DEFAULT;
  keeps = keeps.map(s => String(s || '').trim()).filter(Boolean).slice(0, 12);
  return { saved, keeps: keeps.length ? keeps : KEEP_DEFAULT.slice() };
}
function writePresetDoc(doc) {
  fs.writeFileSync(PRESET_FILE, JSON.stringify({
    saved: [...new Set((doc.saved || []).filter(Boolean))].slice(0, 40),
    keeps: [...new Set((doc.keeps || []).filter(Boolean))].slice(0, 12)
  }, null, 2), 'utf8');
}
function presetView(rows) {
  const doc = readPresetDoc();
  const saved = doc.saved;
  const recent = [];
  for (let i = rows.length - 1; i >= 0 && recent.length < 8; i--) {
    const s = String(rows[i].instruction || '').trim();
    if (s && s.length <= 120 && !saved.includes(s) && !recent.includes(s)) recent.push(s);
  }
  return { saved, recent, keeps: doc.keeps };
}
// 图生图底图：只接受项目目录 / 工作目录内的 png/jpg/webp 文件
function safeBaseImage(p) {
  const s = String(p || '').trim();
  if (!s) return '';
  if (!/\.(png|jpe?g|webp)$/i.test(s)) return '';
  const abs = path.resolve(s);
  const ok = [curProj().root, curProj().workDir].some(root => {
    const n = normPath(abs), r = normPath(root);
    return n === r || n.startsWith(r + '/');
  });
  if (!ok) return '';
  try { return fs.statSync(abs).isFile() ? abs : ''; } catch { return ''; }
}
// ---- 风格模板库：一套风格 = 基线 + 禁止项 + 题材模块 + 案例图 ----
const STYLES_FILE = path.join(ROOT, 'styles.json');
const STYLE_DIR = path.join(ROOT, 'styles');
function readStyles() {
  try {
    const j = JSON.parse(fs.readFileSync(STYLES_FILE, 'utf8'));
    const list = Array.isArray(j) ? j : (j.styles || []);
    return list.map(s => ({
      id: String(s.id || ''), name: String(s.name || ''), notes: String(s.notes || ''),
      bible: String(s.bible || ''), negative: String(s.negative || ''),
      modules: Array.isArray(s.modules) ? s.modules.map(String) : [],
      examples: Array.isArray(s.examples) ? s.examples.map(String) : []
    })).filter(s => s.id);
  } catch { return []; }
}
function writeStyles(list) {
  const tmp = STYLES_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify({ styles: list }, null, 2), 'utf8');
  fs.renameSync(tmp, STYLES_FILE);
}
function styleView(s) {
  return Object.assign({}, s, {
    examples: (s.examples || []).map(f => '/style-files/' + encodeURIComponent(s.id) + '/' + encodeURIComponent(path.basename(f)))
  });
}
function styleDirOf(id) { return path.join(STYLE_DIR, String(id).replace(/[^\w-]/g, '_')); }
// ---- 图片库索引：library.json（由 library_build.py 生成，只存索引不复制图片）----
let libCache = { key: '', at: -1, doc: null };
let libBuild = { pid: 0, at: 0 };
function readLibrary() {
  try {
    const file = curProj().lib;
    const st = fs.statSync(file);
    const key = curProj().id;
    if (libCache.doc && libCache.key === key && libCache.at === st.mtimeMs) return libCache.doc;
    const doc = JSON.parse(fs.readFileSync(file, 'utf8'));
    libCache = { key, at: st.mtimeMs, doc };
    return doc;
  } catch {
    return { meta: { total: 0, built_at: '', kinds: {}, statuses: {}, groups: {} }, items: [] };
  }
}
function libSummary(it) {
  return {
    k: it.k, title: it.title || '', code: it.code || '', group: it.group || '',
    kind: it.kind || '', status: it.status || '', at: it.at || '',
    thumb: it.thumb ? '/lib-thumbs/' + it.thumb.split('/').pop() + '?project=' + encodeURIComponent(curProj().id) + '&v=' + encodeURIComponent(it.at || '') : '',
    image: it.image || '', seed: it.seed == null ? null : it.seed,
    model: it.model || '', w: it.w || 0, h: it.h || 0,
    hasPrompt: !!(it.prompt && it.prompt.trim()),
    taskId: it.taskId || '', versions: it.versions || 0
  };
}
function libBuilding() {
  if (!libBuild.pid) return false;
  try { process.kill(libBuild.pid, 0); return true; } catch { libBuild.pid = 0; return false; }
}
// ---- prompt 分类：人物 / 服装 / 动作 / 环境 / 镜头 / 风格 / 安全限制 / 去水印 ----
const PART_LABELS = [
  ['character', '人物'], ['outfit', '服装'], ['action', '动作'], ['scene', '环境'],
  ['camera', '镜头'], ['style', '风格'], ['safety', '安全限制'], ['watermark', '去水印']
];
const PART_RULES = [
  ['watermark', /水印|logo|签名|字幕|文字|标识|watermark|signature|subtitle|caption/i],
  ['safety', /安全|合规|裸露|不得|禁止|避免|限制|审核|分级|遮挡|safety|modest|non-explicit|no nude|avoid|prohibit|censor/i],
  ['outfit', /穿|服装|衣|裙|制服|鞋|袜|甲|外套|裤|紧身|皮革|布料|配饰|wear|outfit|armou?r|jacket|skirt|boots|heels|dress|uniform|suit|leather|fabric|glove|legging|bikini/i],
  ['action', /站|坐|跪|躺|蹲|俯身|趴|抱|拥|搂|抬手|抬起|转身|回身|侧身|起身|倚|依偎|弯腰|弯下|屈膝|伸手|伸臂|行走|奔跑|扑|推|拉|握|扶|低头|抬头|仰头|回首|凝视|对视|相视|微笑|一笑|皱眉|颔首|点头|摇头|手势|双手|单手|负手|叉腰|垂下|垂落|起舞|翩跹|standing|sitting|kneel|lying|holding|leaning|pos(e|ing)|walking|running|grip/i],
  ['camera', /特写|半身|全身|视角|构图|镜头|景深|比例|画幅|景别|仰视|俯视|远景|中景|近景|close-?up|full[- ]body|cowboy shot|portrait|shot|framing|angle|composition|depth of field|aspect ratio|lens/i],
  ['scene', /背景|场景|房间|舱|舰桥|空间|灯|墙|地面|窗外|宇宙|环境|室内|室外|光照|background|interior|room|bridge|cockpit|spacecraft|window|floor|wall|lighting|cabin|hangar/i],
  ['character', /脸|发|眼|皮肤|身形|身高|胸|腿|面容|五官|神态|年龄|女性|男性|人物|表情|face|hair|eyes?|skin|body|physique|features|expression|female|male|woman|man|eyebrow|lip/i],
  ['style', /写实|CG|渲染|风格|质感|分辨率|光影|色调|电影|摄影|3D|style|render|photoreal|cinematic|texture|palette|realistic|film grain|resolution/i]
];
// 画风/笔法类的句子一律归「风格」，避免「靠笔触」「颜色块」这类词被误判成动作或服装
const STYLE_STRONG = /笔触|笔道|厚涂|刮刀|颜料|色块|色阶|勾线|平涂|罩染|噪点|颗粒|涂层|边缘光|高光|暗部|质感|画风|油彩|堆色|brush|stroke|impasto|palette knife/i;
function isAsciiText(s) {
  const cjk = (String(s).match(/[\u4e00-\u9fa5]/g) || []).length;
  const ascii = (String(s).match(/[A-Za-z]/g) || []).length;
  return ascii > cjk * 3;
}
function splitPrompt(text) {
  const out = {};
  const s = String(text || '').trim();
  if (!s) return out;
  const clauses = s.split(/[。；;！!？?\n]|，|,|\.\s+/).map(x => x.trim()).filter(Boolean);
  for (const c of clauses) {
    const rule = PART_RULES.find(([, re]) => re.test(c));
    const key = STYLE_STRONG.test(c) ? 'style' : (rule ? rule[0] : 'style');
    out[key] = out[key] ? out[key] + (isAsciiText(c) ? ', ' : '，') + c : c;
  }
  return out;
}
function joinPromptParts(parts) {
  if (!parts || typeof parts !== 'object') return '';
  const vals = PART_LABELS.map(([k]) => String(parts[k] || '').trim()).filter(Boolean);
  return vals.join(isAsciiText(vals.join(' ')) ? ', ' : '，');
}
function promptPartsOf(t, text) {
  const saved = t.prompt_parts;
  // 任务自带分类时直接信它（拆格任务的「动作」靠这里保证准确），至少 2 个非空值才认
  if (saved && typeof saved === 'object') {
    const out = {};
    let filled = 0;
    for (const [k] of PART_LABELS) {
      const v = String(saved[k] == null ? '' : saved[k]).trim();
      out[k] = v;
      if (v) filled++;
    }
    if (filled >= 2) return out;
  }
  return splitPrompt(text);
}
// 把当前图片归档为一个版本，连同当时的 prompt / 生成信息一起留在 versions 里
function archiveVersion(hit, extra) {
  const out = String(hit.output || '');
  if (!out) return null;
  const src = path.isAbsolute(out) ? out : path.join(curProj().workDir, out);
  try {
    if (!fs.existsSync(src)) return null;
  } catch { return null; }
  const list = Array.isArray(hit.versions) ? hit.versions : (hit.versions = []);
  const n = list.length + 1;
  const name = hit.id + '__v' + n + '.png';
  try {
    fs.copyFileSync(src, path.join(curProj().out, name));
  } catch { return null; }
  const rec = Object.assign({
    n,
    image: 'output/' + name,
    at: new Date().toISOString(),
    prompt: String(hit.refined_prompt || hit.prompt || ''),
    instruction: String(hit.instruction || ''),
    seed: hit.seed == null ? null : hit.seed,
    aspect: String(hit.aspect || ''),
    size: '',
    elapsed: Number(hit.elapsed || 0),
    gen_started_at: String(hit.gen_started_at || ''),
    gen_finished_at: String(hit.gen_finished_at || ''),
    verdict: String(hit.verdict || '')
  }, extra || {});
  list.push(rec);
  hit.prev_output = rec.image;
  hit.output_archived = true;
  return rec;
}
// 出图耗时均值，用于工作预估
function boardStats(rows) {
  const done = rows.filter(t => t.status === 'done' && Number(t.elapsed) > 0).slice(-40);
  const avgGen = done.length ? Math.round(done.reduce((s, t) => s + Number(t.elapsed), 0) / done.length) : 35;
  const todo = rows.filter(t => ['pending', 'failed'].includes(String(t.status)) && (t.instruction || t.refined_prompt || t.prompt)).length;
  return { avgGen, avgCompile: 30, boot: 60, todo, estPerTask: avgGen + 30 };
}
let cpuSnap = null;
function cpuPercent() {
  const cpus = os.cpus();
  let idle = 0, total = 0;
  for (const c of cpus) {
    const t = c.times;
    idle += t.idle;
    total += t.user + t.nice + t.sys + t.idle + t.irq;
  }
  const prev = cpuSnap;
  cpuSnap = { idle, total };
  if (!prev) return null;
  const di = idle - prev.idle, dt = total - prev.total;
  return dt > 0 ? Math.max(0, Math.min(100, Math.round((1 - di / dt) * 100))) : null;
}
// ---- 资源快照：显存 / 工作流相关进程 / 模型文件位置 ----
const COMFY_DIR = process.env.COMFY_DIR || 'C:\\Users\\pamphile\\AI\\ComfyUI';
let SYS_EXTRA = { at: 0, gpu: null, procs: [], models: [], modelsAt: 0 };
let LM_INFO = { at: 0, online: false, total: 0, loaded: [], fetching: 0 };

// LM Studio 已载入模型：懒刷新，不阻塞请求
function refreshLm() {
  if (Date.now() - LM_INFO.fetching < 6000) return;
  LM_INFO.fetching = Date.now();
  fetch('http://127.0.0.1:1234/api/v0/models', { signal: AbortSignal.timeout(12000) })
    .then(r => r.json())
    .then(j => {
      const list = Array.isArray(j.data) ? j.data : [];
      LM_INFO = {
        at: Date.now(), online: true, total: list.length,
        loaded: list.filter(m => m.state === 'loaded').map(m => m.id),
        fetching: 0
      };
    })
    .catch(err => {
      log('LM Studio 探测失败：' + (err && err.message));
      LM_INFO = { at: Date.now(), online: false, total: 0, loaded: [], fetching: 0 };
    });
}

// 显存统一走 Windows GPU 性能计数器（NVIDIA / AMD / Intel 都适用），和进程扫描合并成一次 PowerShell
function sysProbeScript() {
  const filter = "Name='node.exe' OR Name='python.exe' OR Name='pythonw.exe' OR Name='llama-server.exe' OR Name='lms.exe' OR Name='LM Studio.exe'";
  return [
    "$name=(Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch 'Virtual|Basic' } | Select-Object -First 1).Name;",
    "$total=0;",
    "Get-ChildItem 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}' -ErrorAction SilentlyContinue | ForEach-Object {",
    "  $v=(Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue).'HardwareInformation.qwMemorySize';",
    "  if($v -and ($total -eq 0 -or $v -lt $total)){ $total=[double]$v }",
    "};",
    "$used=0;",
    "try { $used=((Get-Counter '\\GPU Adapter Memory(*)\\Dedicated Usage' -ErrorAction Stop).CounterSamples | Sort-Object CookedValue -Descending | Select-Object -First 1).CookedValue } catch {}",
    "$gpuProcs=@();",
    "try { $gpuProcs=(Get-Counter '\\GPU Process Memory(*)\\Dedicated Usage' -ErrorAction Stop).CounterSamples | Where-Object { $_.CookedValue -gt 104857600 } | ForEach-Object { $m=[regex]::Match($_.InstanceName,'pid_(\\d+)'); if($m.Success){ [pscustomobject]@{ pid=[int]$m.Groups[1].Value; mem=[double]$_.CookedValue } } } } catch {}",
    `$procs=Get-CimInstance Win32_Process -Filter "${filter}" | Select-Object ProcessId,Name,WorkingSetSize,CommandLine;`,
    "[pscustomobject]@{ name=$name; total=[double]$total; used=[double]$used; gpuProcs=$gpuProcs; procs=$procs } | ConvertTo-Json -Compress -Depth 4"
  ].join(' ');
}

function classifyProc(p) {
  const cmd = p.cmd;
  if (/live\.mjs/i.test(cmd)) return { role: '看板服务', where: path.resolve(HERE) };
  if (/novel_work\.py/i.test(cmd)) {
    const doc = readProjectsDoc();
    const proj = doc.projects.find(x => x.id === doc.current) || doc.projects[0];
    return { role: '小说工作流', where: proj ? proj.workDir : '' };
  }
  if (/llama-server/i.test(p.name) || /llama-server/i.test(cmd)) {
    const m = cmd.match(/(?:^|\s)(?:-m|--model)(?:\s+|=)("?)([^"]+)\1/) || cmd.match(/--model[=\s]+("?)([^"]+)\1/);
    return { role: 'LM Studio 文本模型', where: m ? m[2] : 'LM Studio' };
  }
  if (/lms\.exe|LM Studio/i.test(p.name)) return { role: 'LM Studio', where: 'C:\\Users\\pamphile\\.lmstudio' };
  if (/python/i.test(p.name) && (/ComfyUI|main\.py/i.test(cmd))) return { role: 'ComfyUI', where: COMFY_DIR };
  return null;
}

function listModels() {
  const out = [];
  const lmRoots = [
    path.join(os.homedir(), '.lmstudio', 'models'),
    path.join(os.homedir(), '.cache', 'lm-studio', 'models')
  ].filter(d => { try { return fs.existsSync(d); } catch { return false; } });
  const lmFiles = [];
  for (const root of lmRoots.slice(0, 1)) {
    const walk = (dir, depth) => {
      if (depth > 4 || lmFiles.length > 400) return;
      let names = [];
      try { names = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const ent of names) {
        const abs = path.join(dir, ent.name);
        if (ent.isDirectory()) { walk(abs, depth + 1); continue; }
        if (!/\.(gguf|safetensors)$/i.test(ent.name)) continue;
        try {
          const st = fs.statSync(abs);
          if (st.size < 1024 * 1024 * 1024) continue;
          lmFiles.push({ name: ent.name, dir: path.relative(root, abs).replace(/\\/g, '/'), size: st.size });
        } catch { /* 跳过坏文件 */ }
      }
    };
    walk(root, 0);
  }
  // 工作流实际用的 27B 排前面，其余按体积
  lmFiles.sort((a, b) => {
    const pa = /27b/i.test(a.name) ? 0 : 1;
    const pb = /27b/i.test(b.name) ? 0 : 1;
    return pa - pb || b.size - a.size;
  });
  out.push({ kind: 'LM Studio', where: lmRoots[0] || '(未找到模型目录)', files: lmFiles.slice(0, 4) });
  const files = [];
  for (const d of ['checkpoints', 'diffusion_models', 'unet', 'vae', 'text_encoders']) {
    const dir = path.join(COMFY_DIR, 'models', d);
    if (!fs.existsSync(dir)) continue;
    try {
      for (const f of fs.readdirSync(dir)) {
        if (!/\.(safetensors|ckpt|gguf|pt|pth|bin)$/i.test(f)) continue;
        const st = fs.statSync(path.join(dir, f));
        if (st.size < 50 * 1024 * 1024) continue;
        files.push({ name: f, dir: 'models/' + d, size: st.size });
      }
    } catch { /* 目录读不了跳过 */ }
  }
  files.sort((a, b) => b.size - a.size);
  out.push({ kind: 'ComfyUI', where: path.join(COMFY_DIR, 'models'), files: files.slice(0, 6) });
  return out;
}

// 后台异步探测，接口只返回缓存，避免阻塞请求
function refreshSys() {
  if (SYS_EXTRA.busy || Date.now() - SYS_EXTRA.at < 4000) return;
  SYS_EXTRA.busy = Date.now();
  execFile('powershell', ['-NoProfile', '-NonInteractive', '-Command', sysProbeScript()],
    { encoding: 'utf8', timeout: 20000, windowsHide: true, maxBuffer: 8 * 1024 * 1024 }, (err, stdout) => {
      SYS_EXTRA.busy = 0;
      if (err || !stdout) { log('资源探测失败：' + (err && err.message)); return; }
      let j = null;
      try { j = JSON.parse(String(stdout).trim()); } catch { return; }
      const gpuProcs = (Array.isArray(j.gpuProcs) ? j.gpuProcs : (j.gpuProcs ? [j.gpuProcs] : []))
        .map(p => ({ pid: +p.pid, mem: +p.mem }));
      const used = +j.used || gpuProcs.reduce((s, p) => s + p.mem, 0);
      const total = +j.total || 0;
      const gpu = total
        ? { name: j.name || 'GPU', total, used, free: Math.max(0, total - used), shared: true, procs: gpuProcs }
        : null;
      const raw = (Array.isArray(j.procs) ? j.procs : (j.procs ? [j.procs] : [])).map(p => {
        const pid = +p.ProcessId || 0;
        const c = classifyProc({ pid, name: String(p.Name || ''), mem: +p.WorkingSetSize || 0, cmd: String(p.CommandLine || '') });
        if (!c) return null;
        const gp = gpuProcs.find(x => x.pid === pid);
        return { pid, name: String(p.Name || ''), mem: +p.WorkingSetSize || 0, gpu: gp ? gp.mem : 0, role: c.role, where: c.where };
      }).filter(Boolean);
      // 同类进程合并（LM Studio 常有多个辅助进程），PID 取内存最大的那个
      const byRole = new Map();
      for (const p of raw) {
        const g = byRole.get(p.role);
        if (!g) { byRole.set(p.role, { ...p, count: 1, top: p.mem }); continue; }
        g.mem += p.mem; g.gpu += p.gpu; g.count += 1;
        if (p.mem > g.top) { g.pid = p.pid; g.top = p.mem; }
      }
      const procs = [...byRole.values()].map(({ top, ...p }) => p);
      const now = Date.now();
      const models = (now - SYS_EXTRA.modelsAt < 60000 && SYS_EXTRA.models.length) ? SYS_EXTRA.models : listModels();
      SYS_EXTRA = { at: now, gpu, procs, models, modelsAt: models === SYS_EXTRA.models ? SYS_EXTRA.modelsAt : now, busy: 0 };
    });
}

function sysExtra() {
  refreshSys();
  return SYS_EXTRA;
}

function sysView() {
  const total = os.totalmem();
  const free = os.freemem();
  const extra = sysExtra();
  refreshLm();
  const pdoc = readProjectsDoc();
  const nproj = pdoc.projects.find(x => x.id === pdoc.current) || pdoc.projects[0];
  return {
    ok: true,
    ready: !!extra.at,
    cpu: cpuPercent(),
    memTotal: total,
    memFree: free,
    memUsed: total - free,
    memPct: Math.round((total - free) / total * 100),
    load: os.loadavg()[0],
    uptime: Math.round(os.uptime()),
    gpu: extra.gpu,
    procs: extra.procs,
    models: extra.models,
    paths: { novel: nproj ? nproj.workDir : '', comfyui: COMFY_DIR, taskboard: ROOT },
    lm: { online: LM_INFO.online, total: LM_INFO.total, loaded: LM_INFO.loaded, at: LM_INFO.at || null }
  };
}

function workFileUrl(file) {
  return '/work-files/' + encodeURIComponent(path.basename(String(file || ''))) + '?project=' + encodeURIComponent(curProj().id);
}
// 卡片一律用小缩略图（thumbs/n-<sha1(id)>.jpg），没有缩略图时才回退到原图
function taskThumb(t, fallback) {
  const id = String((t && t.id) || '');
  const name = path.basename(String((t && t.thumb) || '')) ||
    (id ? 'n-' + crypto.createHash('sha1').update(id).digest('hex').slice(0, 14) + '.jpg' : '');
  if (name) {
    try {
      const full = path.join(curProj().thumbs, name);
      if (fs.existsSync(full)) {
        // 带文件修改时间做版本号：重画后缩略图文件名不变，靠 v 让浏览器重新取
        const v = Math.floor(fs.statSync(full).mtimeMs / 1000);
        return '/lib-thumbs/' + encodeURIComponent(name) + '?project=' + encodeURIComponent(curProj().id) + '&v=' + v;
      }
    } catch { /* 项目没 thumbs 目录就走回退 */ }
  }
  return fallback || '';
}
// 时间字段统一成 ISO 字符串；旧任务没有显式时间时，用 ts / elapsed 回推开图与完成
function boardTaskView(t) {
  const out = String(t.output || '');
  const elapsed = Number(t.elapsed) || 0;
  const tsNum = Number(t.ts) || 0;
  const tsMs = tsNum > 1e12 ? tsNum : tsNum > 1e9 ? tsNum * 1000 : 0;
  const genEnd = String(t.gen_finished_at || (t.status === 'done' && tsMs ? new Date(tsMs).toISOString() : ''));
  const genStart = String(t.gen_started_at || (genEnd && elapsed ? new Date(Date.parse(genEnd) - elapsed * 1000).toISOString() : ''));
  const prev = String(t.prev_output || '');
  const promptText = String(t.refined_prompt || t.prompt || '');
  return {
    id: t.id,
    project: String(t.group || '未分组'),
    title: String(t.title || t.id || ''),
    desc: String(t.desc || t.description || ''),
    origin: String(t.origin || t.source_text || ''),
    status: String(t.status || 'pending'),
    instruction: String(t.instruction || ''),
    promptText,
    promptSource: String(t.refined_prompt || '').trim() ? 'refined' : (String(t.prompt || '').trim() ? 'orig' : ''),
    refined: !!String(t.refined_prompt || '').trim(),
    mode: String(t.mode || '') === 'img2img' ? 'img2img' : 'txt2img',
    base: String(t.image || ''),
    kind: String(t.kind || ''),
    sceneId: String(t.sceneId || ''),
    parts: promptPartsOf(t, promptText),
    verdict: String(t.verdict || ''),
    error: String(t.error || ''),
    output: out,
    thumb: taskThumb(t, out ? workFileUrl(out) : ''),
    candidates: (Array.isArray(t.candidates) ? t.candidates : []).map((c, i) => {
      let url = '';
      const nm = String(c.thumb || '');
      if (nm) {
        try {
          const full = path.join(curProj().thumbs, nm);
          const v = fs.existsSync(full) ? Math.floor(fs.statSync(full).mtimeMs / 1000) : '';
          url = '/lib-thumbs/' + encodeURIComponent(nm) + '?project=' + encodeURIComponent(curProj().id) + (v ? '&v=' + v : '');
        } catch { url = ''; }
      }
      return { n: i + 1, thumb: url, image: c.image ? workFileUrl(String(c.image)) : '', seed: c.seed == null ? null : c.seed };
    }),
    prevThumb: prev ? workFileUrl(prev) : '',
    versions: (Array.isArray(t.versions) ? t.versions : []).map(v => ({
      n: Number(v.n) || 0,
      thumb: v.image ? workFileUrl(String(v.image)) : '',
      at: String(v.at || ''),
      elapsed: Number(v.elapsed) || 0,
      seed: v.seed == null ? null : v.seed,
      size: String(v.size || ''),
      aspect: String(v.aspect || ''),
      verdict: String(v.verdict || ''),
      prompt: String(v.prompt || ''),
      instruction: String(v.instruction || ''),
      genStart: String(v.gen_started_at || ''),
      genEnd: String(v.gen_finished_at || '')
    })),
    elapsed,
    time: {
      instruction: String(t.instruction_at || ''),
      prompt: String(t.prompt_at || ''),
      genStart,
      genEnd,
      review: String(t.review_at || '')
    }
  };
}
function boardProjectsOf(rows) {
  const map = new Map();
  for (const name of readProjectList()) map.set(name, { name, total: 0, todo: 0, running: 0, done: 0, pass: 0, fail: 0, failed: 0 });
  for (const t of rows) {
    const name = String(t.group || '未分组');
    if (!map.has(name)) map.set(name, { name, total: 0, todo: 0, running: 0, done: 0, pass: 0, fail: 0, failed: 0 });
    const p = map.get(name);
    p.total++;
    if (t.status === 'pending') p.todo++;
    else if (t.status === 'running') p.running++;
    else if (t.status === 'failed') p.failed++;
    else if (t.status === 'done') p.done++;
    if (t.verdict === 'pass') p.pass++;
    if (t.verdict === 'fail') p.fail++;
  }
  return [...map.values()].sort((a, b) => a.name.localeCompare(b.name, 'zh'));
}

function writeTerms(doc) {
  doc.schemaVersion = 1;
  doc.updatedAt = new Date().toISOString();
  doc._doc = TERMS_DOC;
  const tmp = TERMS_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(doc, null, 2), 'utf8');
  fs.renameSync(tmp, TERMS_FILE);
  exportTerms(doc);
}
// 给生图 agent 的可程序读取文件：关键词、解释、可直接拼进提示词的文本、案例图绝对路径
function exportTerms(doc) {
  const out = {
    schemaVersion: 1,
    kind: 'xuan-shu-hao/prompt-terms',
    updatedAt: doc.updatedAt || new Date().toISOString(),
    usage: {
      mark: '在修改意见或 prompt 里用 #关键词 引用；下面的 explain 与案例图就是补充材料',
      prompt: '把 terms[].promptText 直接拼进正向提示词；cases[].path 作为参考图',
      rules: '只在 terms 里出现过的 #词 才当专有词；未命中的 #词按普通文字处理'
    },
    terms: (doc.terms || []).map(t => ({
      id: t.id,
      keyword: t.keyword,
      tag: '#' + t.keyword,
      explain: t.explain,
      promptText: '#' + t.keyword + '：' + t.explain,
      cases: (t.cases || []).map(c => ({ imageId: c.imageId || '', path: c.abs || '' })).filter(c => c.imageId || c.path),
      updatedAt: t.updatedAt || doc.updatedAt || null,
      source: t.source || ''
    }))
  };
  try {
    fs.mkdirSync(path.dirname(TERMS_EXPORT_FILE), { recursive: true });
    const tmp = TERMS_EXPORT_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(out, null, 2), 'utf8');
    fs.renameSync(tmp, TERMS_EXPORT_FILE);
  } catch (e) {
    log('词条导出失败（不影响页面）：' + ((e && e.message) || e));
  }
}
function readFeedback() {
  try {
    const j = JSON.parse(fs.readFileSync(FEEDBACK_FILE, 'utf8'));
    if (j && Array.isArray(j.items)) return { ...j, _doc: FEEDBACK_DOC };
  } catch { /* 文件还没建 */ }
  return { _doc: FEEDBACK_DOC, updatedAt: null, items: [] };
}
function writeFeedback(obj) {
  obj.updatedAt = new Date().toISOString();
  const tmp = FEEDBACK_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), 'utf8');
  fs.renameSync(tmp, FEEDBACK_FILE);
}
function readBody(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
function readBodyBuffer(req, limit = 24 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

// ---- 小说插图工作流：状态 / 分章 / 人物卡 / 场景表 / 出图队列 ----
function novelPaths() {
  const p = curProj();
  return {
    p, w: p.workDir,
    script: path.join(p.workDir, p.runner || 'novel_work.py'),
    state: path.join(p.workDir, 'novel-state.json'),
    log: path.join(p.workDir, 'novel-work.log'),
    chapters: path.join(p.root, '00_原文', 'chapters.json'),
    chars: path.join(p.root, '01_角色', '角色卡.json'),
    scenes: path.join(p.root, '02_场景', '场景表.jsonl')
  };
}
function readNovelState() {
  const def = {
    running: false, phase: 'idle', step: '', message: '', current: '', total: 0, done: 0,
    ok: 0, fail: 0, pid: 0, startedAt: '', updatedAt: '', finishedAt: '', error: ''
  };
  try { return Object.assign(def, JSON.parse(fs.readFileSync(novelPaths().state, 'utf8'))); } catch { return def; }
}
function writeNovelState(partial) {
  const f = novelPaths().state;
  const doc = Object.assign(readNovelState(), partial, { updatedAt: new Date().toISOString() });
  const tmp = f + '.' + process.pid + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(doc, null, 1), 'utf8');
    fs.renameSync(tmp, f);
  } catch { /* 写不了就等 python 自己写 */ }
}
function pidAlive(pid) {
  if (!pid) return false;
  try { process.kill(pid, 0); return true; } catch (e) { return e && e.code === 'EPERM'; }
}
function novelRunning() {
  const s = readNovelState();
  if (!s.running) return false;
  if (s.pid && pidAlive(s.pid)) return true;
  const at = Date.parse(s.updatedAt || '') || 0;
  return Date.now() - at < 20 * 60 * 1000;
}
function readJsonLoose(f, def) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return def; }
}
function readJsonlFile(f) {
  try {
    return fs.readFileSync(f, 'utf8').split(/\r?\n/).filter(Boolean)
      .map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return []; }
}
function writeJsonlFile(f, rows) {
  const tmp = f + '.tmp';
  fs.writeFileSync(tmp, rows.map(r => JSON.stringify(r)).join('\n') + '\n', 'utf8');
  fs.renameSync(tmp, f);
}
function writeJsonFile(f, obj) {
  const tmp = f + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 1), 'utf8');
  fs.renameSync(tmp, f);
}
function novelLogTail(lines = 90) {
  try {
    const buf = fs.readFileSync(novelPaths().log);
    const txt = buf.slice(Math.max(0, buf.length - 24000)).toString('utf8');
    return txt.split(/\r?\n/).filter(Boolean).slice(-lines).join('\n');
  } catch { return ''; }
}
const chapterDocCache = new Map();
function chapterDoc(root, chapters, no, chapterId) {
  // 番外与正篇章号会重复（番外05 的 no 也是 5），优先按 chapterId 定位
  const row = (chapterId && chapters.find(r => r.id === chapterId)) || chapters.find(r => Number(r.no) === Number(no));
  if (!row || !row.file) return { text: '', compact: '', pos: [] };
  const f = path.resolve(root, String(row.file));
  let st;
  try { st = fs.statSync(f); } catch { return { text: '', compact: '', pos: [] }; }
  const key = f + '|' + st.mtimeMs;
  if (chapterDocCache.has(key)) return chapterDocCache.get(key);
  let text = '';
  try { text = fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, ''); } catch { /* 读不到就空 */ }
  text = text.replace(/^#\s+.*$/m, '').trim();
  const chars = [], pos = [];
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (!/\s/.test(ch)) { chars.push(ch); pos.push(i); }
  }
  const doc = { text, compact: chars.join(''), pos };
  chapterDocCache.set(key, doc);
  if (chapterDocCache.size > 80) chapterDocCache.delete(chapterDocCache.keys().next().value);
  return doc;
}
// 粘贴原文 → 反查属于哪一章（按去掉空白后的片段匹配，首/中/尾各取一段）
function locateChapter(root, chapters, text) {
  const probe = String(text || '').replace(/\s+/g, '');
  if (probe.length < 8) return null;
  const n = probe.length;
  const picks = n >= 30
    ? [probe.slice(0, 30), probe.slice(Math.max(0, Math.floor(n / 2) - 15), Math.floor(n / 2) + 15), probe.slice(-30)]
    : [probe];
  for (const row of chapters) {
    const doc = chapterDoc(root, chapters, row.no, row.id);
    if (!doc.compact) continue;
    if (picks.some(k => k && doc.compact.includes(k))) return row;
  }
  return null;
}
// 原文摘录的前后文：抽中的句子原样返回，外面补上下文
function originCtx(scene, root, chapters, before = 160, after = 160) {
  const q = String(scene.origin || '').replace(/\s+/g, ' ').trim();
  if (!q) return null;
  const doc = chapterDoc(root, chapters, scene.chapter, scene.chapterId);
  if (!doc.text) return { pre: '', quote: q, post: '' };
  let start = doc.text.indexOf(q);
  let end = start >= 0 ? start + q.length : -1;
  let quote = q;
  if (start < 0) {
    const cq = q.replace(/\s+/g, '');
    const at = cq.length >= 18 ? doc.compact.indexOf(cq.slice(0, 18)) : -1;
    if (at < 0) return { pre: '', quote: q, post: '' };
    const endAt = Math.min(doc.pos.length, at + cq.length);
    start = doc.pos[at];
    end = doc.pos[endAt - 1] + 1;
    quote = doc.text.slice(start, end);
  }
  return {
    pre: doc.text.slice(Math.max(0, start - before), start).trim(),
    quote: quote.trim(),
    post: doc.text.slice(end, end + after).trim()
  };
}
function novelView() {
  const P = novelPaths();
  const state = readNovelState();
  // 以真实情况为准：状态文件可能残留（进程已退），暂停看标记文件
  state.running = novelRunning();
  state.paused = fs.existsSync(path.join(P.w, 'pause.flag'));
  const chapters = (readJsonLoose(P.chapters, {}) || {}).chapters || [];
  const charDoc = readJsonLoose(P.chars, {}) || {};
  const characters = Array.isArray(charDoc.characters) ? charDoc.characters : [];
  const scenes = readJsonlFile(P.scenes);
  const queue = readWorkQueue();
  const taskByScene = new Map();
  const taskByChar = new Map();
  for (const t of queue) {
    // 拆格任务也有 sceneId，跳过它们，避免场景卡被最后一格覆盖
    if (t.sceneId && !t.frameOf) taskByScene.set(t.sceneId, t);
    if (t.charId && t.sheetType) taskByChar.set(t.charId + '|' + t.sheetType, t);
  }
  const lite = t => t ? {
    id: t.id, status: t.status || 'pending', error: t.error || '',
    thumb: taskThumb(t, t.output ? workFileUrl(t.output) : ''), aspect: t.aspect || '', mode: t.mode || ''
  } : null;
  const scenesOut = scenes.map(s => Object.assign({}, s, {
    task: lite(taskByScene.get(s.id)),
    ctx: originCtx(s, P.p.root, chapters)
  }));
  const charactersOut = characters.map(c => {
    const outs = {};
    for (const k of ['head', 'bust', 'full', 'expr']) outs[k] = lite(taskByChar.get(c.id + '|' + k));
    return Object.assign({}, c, { outputs: outs });
  });
  const tasks = queue.slice().sort((a, b) => {
    const rank = x => (x.status === 'running' ? 0 : x.status === 'pending' ? 1 : x.status === 'failed' ? 2 : 3);
    return rank(a) - rank(b) || Number(b.ts || 0) - Number(a.ts || 0);
  }).slice(0, 400).map(t => ({
    id: t.id, title: t.title || t.id, group: t.group || '', kind: t.kind || '',
    status: t.status || 'pending', aspect: t.aspect || '', chapter: t.chapter || 0,
    charId: t.charId || '', sheetType: t.sheetType || '', sceneId: t.sceneId || '',
    error: t.error || '', elapsed: t.elapsed || 0, mode: t.mode || '',
    thumb: taskThumb(t, t.output ? workFileUrl(t.output) : '')
  }));
  const counts = {
    chapters: chapters.length, characters: characters.length,
    sheets: characters.reduce((n, c) => n + ['head', 'bust', 'full', 'expr'].filter(k => (c.sheet || {})[k]).length, 0),
    scenes: scenes.length, selectedScenes: scenes.filter(s => s.selected).length,
    queue: queue.length, queuePending: queue.filter(t => t.status === 'pending' || t.status === 'failed').length,
    queueDone: queue.filter(t => t.status === 'done').length,
    images: queue.filter(t => t.status === 'done' && t.output).length,
    charRefs: characters.reduce((n, c) => n + ['head', 'bust', 'full', 'expr'].filter(k => (c.refs || {})[k]).length, 0)
  };
  return {
    ok: true, project: P.p.id, source: P.p.sourceFile, style: P.p.style,
    state, counts, chapters, characters: charactersOut, scenes: scenesOut, tasks,
    log: novelLogTail(90), updatedAt: new Date().toISOString()
  };
}
function novelPython() {
  const py = process.env.NOVEL_PY || path.join('C:\\Users\\pamphile\\AI\\ComfyUI', 'venv', 'Scripts', 'python.exe');
  return fs.existsSync(py) ? py : 'python';
}
function novelEnv() {
  return Object.assign({}, process.env, {
    NOVEL_PROJECT: novelPaths().p.id, PYTHONIOENCODING: 'utf-8'
  });
}
function runNovelCmd(args, timeoutMs = 900000) {
  const P = novelPaths();
  return new Promise((resolve, reject) => {
    execFile(novelPython(), [P.script].concat(args), {
      cwd: P.w, timeout: timeoutMs, maxBuffer: 16 * 1024 * 1024, env: novelEnv()
    }, (err, stdout, stderr) => {
      if (err) reject(new Error(String(stderr || err.message || err)));
      else resolve(String(stdout || ''));
    });
  });
}
function spawnNovel(step, extra, message) {
  const P = novelPaths();
  const exe = novelPython();
  const args = [P.script, step].concat(extra || []);
  let fd;
  try { fd = fs.openSync(P.log, 'a'); } catch { fd = 'ignore'; }
  const child = spawn(exe, args, {
    cwd: P.w, detached: true, windowsHide: true,
    stdio: ['ignore', fd, fd], env: novelEnv()
  });
  child.on('error', e => writeNovelState({
    running: false, phase: 'error', step, error: String(e.message || e),
    message: '启动失败：' + String(e.message || e), finishedAt: new Date().toISOString()
  }));
  child.unref();
  if (typeof fd === 'number') { try { fs.closeSync(fd); } catch { /* ignore */ } }
  writeNovelState({
    running: true, phase: step, step, message: message || ('已启动 ' + step),
    pid: child.pid || 0, startedAt: new Date().toISOString(), finishedAt: '',
    error: '', done: 0, total: 0, current: '', ok: 0, fail: 0
  });
  return child.pid || 0;
}

function handleRequest(req, res) {
  const rawUrl = req.url || '/';
  const url = decodeURIComponent(rawUrl.split('?')[0]);
  const qs = new URLSearchParams(rawUrl.split('?')[1] || '');
  if (req.method === 'OPTIONS') { cors(res); res.writeHead(204); res.end(); return; }

  // 插图判定回传：GET 读全部提交与回执；POST 只追加一条提交
  if (url === '/api/gallery-feedback') {
    if (req.method === 'GET') { json(res, readFeedback()); return; }
    if (req.method === 'POST') {
      readBody(req).then(body => {
        let p;
        try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
        const imageId = String(p.imageId || '').trim().slice(0, 240);
        const aliases = { nogenerate: 'cannot', no_gen: 'cannot', ungeneratable: 'cannot', unable: 'cannot', failed: 'cannot' };
        const rawVerdict = String(p.verdict || '').trim();
        const verdict = aliases[rawVerdict] || rawVerdict;
        const VERDICTS = ['pass', 'pass_base', 'fail', 'hold', 'derive', 'cannot', 'redo'];
        const linkPick = () => String(p.publishUrl || p.publishedUrl || p.siteUrl || p.url || p.link || p.pageUrl || '').slice(0, 2000);
        const doc = readFeedback();

        // 按 id 读改写：只合并请求里出现的字段，建议内容不允许被空值清掉
        const patchId = String(p.id || '').trim().slice(0, 120);
        const hit = patchId ? doc.items.find(x => x.id === patchId) : null;
        if (patchId && !hit) { json(res, { ok: false, error: '找不到这条记录：' + patchId }, 404); return; }
        const canPatchVerdict = hit && verdict && !((hit.verdict === 'derive' || hit.verdict === 'redo') && verdict !== hit.verdict);
        if (hit && (!verdict || canPatchVerdict)) {
          if (verdict) hit.verdict = verdict;
          if (p.suggestion !== undefined) {
            const s = String(p.suggestion || '').slice(0, 4000);
            if (s.trim() || !hit.suggestion) hit.suggestion = s;
          }
          if (p.prompt !== undefined) hit.prompt = String(p.prompt || '').slice(0, 8000);
          if (p.stage !== undefined) hit.stage = String(p.stage || '').slice(0, 20);
          if (p.receipt !== undefined) {
            hit.receipt = String(p.receipt || '').slice(0, 20);
            const now = new Date().toISOString();
            if (hit.receipt === 'read' || hit.receipt === 'handled') hit.readAt = hit.readAt || now;
            if (hit.receipt === 'handled') hit.handledAt = hit.handledAt || now;
          }
          if (p.note !== undefined) hit.note = String(p.note || '').slice(0, 2000);
          if (p.batch !== undefined) hit.batch = String(p.batch || '').slice(0, 200);
          if (p.group !== undefined) hit.group = String(p.group || '').slice(0, 200);
          if (p.derivedImageId !== undefined && p.derivedImageId) hit.derivedImageId = String(p.derivedImageId).slice(0, 240);
          if (p.baseImageId !== undefined && p.baseImageId) hit.baseImageId = String(p.baseImageId).slice(0, 240);
          const link = linkPick();
          if (link) hit.publishUrl = link;
          hit.updatedAt = new Date().toISOString();
          doc._doc = FEEDBACK_DOC;
          writeFeedback(doc);
          json(res, { ok: true, record: hit, patched: true, total: doc.items.length });
          return;
        }

        const createImageId = imageId || (hit && String(hit.imageId || hit.derivedImageId || '').trim());
        if (!createImageId || VERDICTS.indexOf(verdict) < 0) {
          json(res, { ok: false, error: 'imageId 或 verdict 不合法（可用：' + VERDICTS.join(' / ') + '）' }, 400);
          return;
        }
        // 派生/重做是独立动作，不是判定：不清判定，只追加一条带关系的记录
        const isRedo = verdict === 'redo';
        const derivedImageId = (verdict === 'derive' || isRedo)
          ? String(p.derivedImageId || (isRedo ? createImageId : '')).slice(0, 240)
          : null;
        const rec = {
          id: 'fb-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6),
          imageId: createImageId,
          batch: String(p.batch || (hit && hit.batch) || '').slice(0, 200),
          group: String(p.group || (hit && hit.group) || '').slice(0, 200),
          verdict,
          suggestion: String(p.suggestion || (hit && hit.suggestion) || '').slice(0, 4000),
          submittedAt: new Date().toISOString(),
          receipt: 'submitted',
          readAt: null,
          handledAt: null,
          note: '',
          baseImageId: (verdict === 'pass_base' || verdict === 'derive' || verdict === 'cannot' || isRedo) ? (String(p.baseImageId || (hit && hit.baseImageId) || createImageId).slice(0, 240)) : null,
          derivedImageId,
          derivedAt: derivedImageId ? new Date().toISOString() : null,
          // 派生/重做请求：锁定前的建议/prompt 原样落盘；stage 由页面写 submitted，agent 往后推进
          prompt: (verdict === 'derive' || isRedo) ? String(p.prompt || '').slice(0, 8000) : null,
          stage: verdict === 'derive' ? String(p.stage || 'submitted').slice(0, 20) : null,
          publishUrl: linkPick() || null,
          terms: Array.isArray(p.terms)
            ? p.terms.slice(0, 20).map(t => ({ id: String((t && t.id) || '').slice(0, 80), keyword: String((t && t.keyword) || '').replace(/^#+/, '').slice(0, 60) })).filter(t => t.keyword)
            : []
        };
        doc.items.push(rec);
        doc._doc = FEEDBACK_DOC;
        writeFeedback(doc);
        json(res, { ok: true, record: rec, total: doc.items.length });
      }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
      return;
    }
    json(res, { ok: false, error: '只支持 GET / POST' }, 405);
    return;
  }

  // 固化词条库：GET 读全部；POST upsert / delete，每次写入同步导出给生图 agent
  if (url === '/api/terms') {
    if (req.method === 'GET') { json(res, { ...readTerms(), exportFile: TERMS_EXPORT_FILE }); return; }
    if (req.method === 'POST') {
      readBody(req).then(body => {
        let p;
        try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
        const doc = readTerms();
        const op = String(p.op || 'upsert');
        if (op === 'delete') {
          const id = String(p.id || '');
          const before = doc.terms.length;
          doc.terms = doc.terms.filter(t => t.id !== id);
          if (doc.terms.length === before) { json(res, { ok: false, error: '找不到这个词条' }, 404); return; }
          writeTerms(doc);
          json(res, { ok: true, deleted: id, total: doc.terms.length });
          return;
        }
        const keyword = String(p.keyword || '').replace(/^#+/, '').trim().slice(0, 60);
        const explain = String(p.explain || '').trim().slice(0, 4000);
        if (!keyword) { json(res, { ok: false, error: 'keyword 不能为空' }, 400); return; }
        if (!explain) { json(res, { ok: false, error: 'explain 不能为空' }, 400); return; }
        const prev = p.id ? doc.terms.find(t => t.id === p.id) : null;
        const dup = doc.terms.find(t => t.keyword === keyword && (!prev || t.id !== prev.id));
        if (dup) { json(res, { ok: false, error: '关键词已存在：' + dup.id }, 409); return; }
        const rec = {
          id: prev ? prev.id : termIdFor(keyword, doc.terms),
          keyword,
          explain,
          cases: p.cases !== undefined ? normCases(p.cases) : (prev ? prev.cases : []),
          source: String(p.source !== undefined ? p.source : (prev ? prev.source : '')).slice(0, 200),
          updatedAt: new Date().toISOString()
        };
        if (prev) doc.terms = doc.terms.map(t => (t.id === prev.id ? rec : t));
        else doc.terms.push(rec);
        writeTerms(doc);
        json(res, { ok: true, term: rec, total: doc.terms.length });
      }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
      return;
    }
    json(res, { ok: false, error: '只支持 GET / POST' }, 405);
    return;
  }

  // 审阅总结：GET 读；POST 保存手动总结
  if (url === '/api/summary') {
    if (req.method === 'GET') { json(res, readSummary()); return; }
    if (req.method === 'POST') {
      readBody(req).then(body => {
        let p;
        try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
        const doc = readSummary();
        doc.summary = String(p.summary || '').slice(0, 20000);
        doc.mode = p.mode === 'ai' ? 'ai' : 'manual';
        doc.updatedAt = new Date().toISOString();
        writeSummary(doc);
        json(res, { ok: true, ...doc });
      }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
      return;
    }
    json(res, { ok: false, error: '只支持 GET / POST' }, 405);
    return;
  }

  // 本机 CPU / 内存实时占用
  if (url === '/api/sys') {
    json(res, sysView());
    return;
  }

  // 项目注册表：列表 / 切换 / 新建 / 改配置 / 删除
  if (url === '/api/projects') {
    const doc = readProjectsDoc();
    if (req.method === 'GET') {
      json(res, {
        ok: true, current: doc.current,
        projects: doc.projects.map(p => ({
          id: p.id, name: p.name, pipeline: p.pipeline, root: p.root, workDir: p.workDir,
          style: p.style, defaultAspect: p.defaultAspect, sourceFile: p.sourceFile
        }))
      });
      return;
    }
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 GET/POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const act = String(p.action || '');
      if (act === 'switch') {
        const id = String(p.id || '').trim();
        if (!doc.projects.some(x => x.id === id)) { json(res, { ok: false, error: '没有这个项目' }, 404); return; }
        doc.current = id;
        writeProjectsDoc(doc);
      } else if (act === 'create') {
        const id = String(p.id || '').trim().replace(/[^\w-]/g, '');
        if (!id) { json(res, { ok: false, error: '项目 id 只能用字母数字下划线' }, 400); return; }
        if (doc.projects.some(x => x.id === id)) { json(res, { ok: false, error: '项目 id 已存在' }, 409); return; }
        const np = normalizeProject(Object.assign({
          workDir: path.join(ROOT, 'projects', id, '_自动执行')
        }, p, { id }));
        if (np.pipeline === 'novel_illustration') {
          np.runner = 'novel_work.py';
          np.builder = 'library_build.py';
        }
        ensureProjectDirs(np);
        if (np.pipeline === 'novel_illustration') {
          const tpl = path.join(ROOT, 'projects', 'qmsnl', '_自动执行', 'novel_work.py');
          const dst = path.join(np.workDir, 'novel_work.py');
          try {
            if (fs.existsSync(tpl) && !fs.existsSync(dst)) fs.copyFileSync(tpl, dst);
          } catch { /* 复制失败则提示用户手动放脚本 */ }
        }
        doc.projects.push(np);
        doc.current = id;
        writeProjectsDoc(doc);
      } else if (act === 'update') {
        const hit = doc.projects.find(x => x.id === String(p.id || ''));
        if (!hit) { json(res, { ok: false, error: '没有这个项目' }, 404); return; }
        for (const k of ['name', 'style', 'defaultAspect', 'pipeline', 'sourceFile', 'runner', 'builder']) {
          if (p[k] !== undefined) hit[k] = String(p[k]);
        }
        writeProjectsDoc(doc);
      } else if (act === 'delete') {
        const id = String(p.id || '');
        if (id === doc.current) { json(res, { ok: false, error: '不能删除当前项目，先切到别的项目' }, 409); return; }
        doc.projects = doc.projects.filter(x => x.id !== id);
        writeProjectsDoc(doc);
      } else {
        json(res, { ok: false, error: '未知操作：' + act }, 400);
        return;
      }
      json(res, {
        ok: true, current: doc.current,
        projects: doc.projects.map(x => ({ id: x.id, name: x.name, pipeline: x.pipeline, style: x.style }))
      });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }

  // 小说插图工作流：整包状态（章节 / 人物 / 场景 / 队列 / 日志）
  if (url === '/api/novel/state') {
    if (req.method !== 'GET') { json(res, { ok: false, error: '只支持 GET' }, 405); return; }
    try { json(res, novelView()); } catch (e) { json(res, { ok: false, error: String((e && e.message) || e) }, 500); }
    return;
  }
  // 章节正文（面板里看 / 改原文）
  if (url === '/api/novel/chapter') {
    const id = String(qs.get('id') || '').trim();
    const doc = readJsonLoose(novelPaths().chapters, {}) || {};
    const row = (doc.chapters || []).find(c => c.id === id);
    if (!row) { json(res, { ok: false, error: '没有这一章' }, 404); return; }
    if (req.method === 'POST') {
      readBody(req).then(body => {
        let p;
        try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
        const text = String(p.text || '');
        if (!text.trim()) { json(res, { ok: false, error: '正文不能为空' }, 400); return; }
        const f = path.resolve(novelPaths().p.root, String(row.file || ''));
        const backup = path.join(path.dirname(f), '_备份');
        try {
          fs.mkdirSync(backup, { recursive: true });
          if (fs.existsSync(f)) fs.copyFileSync(f, path.join(backup, id + '.' + Date.now() + '.md'));
        } catch { /* 备份失败不阻塞保存 */ }
        fs.writeFileSync(f, text, 'utf8');
        row.chars = text.length;
        fs.writeFileSync(novelPaths().chapters, JSON.stringify(doc, null, 1), 'utf8');
        json(res, { ok: true, id, chars: text.length });
      }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
      return;
    }
    let text = '';
    try {
      const f = path.resolve(novelPaths().p.root, String(row.file || ''));
      text = fs.readFileSync(f, 'utf8');
    } catch { /* 读不到就空 */ }
    json(res, { ok: true, id: row.id, title: row.title || '', text: text.slice(0, 200000) });
    return;
  }
  // 导入原文：把本地 txt 复制进项目 00_原文，并写回 sourceFile
  if (url === '/api/novel/import') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const src = String(p.path || '').trim().replace(/^"|"$/g, '');
      if (!src || !fs.existsSync(src) || !fs.statSync(src).isFile()) {
        json(res, { ok: false, error: '找不到这个文件：' + src }, 400); return;
      }
      if (!/\.(txt|md)$/i.test(src)) { json(res, { ok: false, error: '只支持 txt / md' }, 400); return; }
      if (fs.statSync(src).size > 120 * 1024 * 1024) { json(res, { ok: false, error: '文件超过 120MB' }, 400); return; }
      const dir = path.join(novelPaths().p.root, '00_原文');
      fs.mkdirSync(dir, { recursive: true });
      const dest = path.join(dir, '原文.txt');
      try { if (path.resolve(src) !== path.resolve(dest)) fs.copyFileSync(src, dest); } catch (e) {
        json(res, { ok: false, error: '复制失败：' + String(e.message || e) }, 500); return;
      }
      const doc = readProjectsDoc();
      const hit = doc.projects.find(x => x.id === novelPaths().p.id);
      if (hit) { hit.sourceFile = dest; writeProjectsDoc(doc); }
      json(res, { ok: true, sourceFile: dest, bytes: fs.statSync(dest).size });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // LM Studio 模型列表（文字加工默认选 35B）
  if (url === '/api/novel/models') {
    fetch('http://127.0.0.1:1234/api/v0/models', { signal: AbortSignal.timeout(6000) })
      .then(r => r.json())
      .then(j => {
        const models = (Array.isArray(j.data) ? j.data : []).map(m => ({ id: m.id, state: m.state || '' }));
        const pick = models.find(m => /35b/i.test(m.id)) || models[0];
        json(res, { ok: true, models, default: pick ? pick.id : '' });
      })
      .catch(e => json(res, { ok: false, error: 'LM Studio 不可用：' + String(e.message || e), models: [] }));
    return;
  }
  // 35B 润色本章（返回文本，由面板确认后再保存）
  if (url === '/api/novel/polish') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(async body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const id = String(p.id || '').trim();
      if (!id) { json(res, { ok: false, error: '缺少章节 id' }, 400); return; }
      if (novelRunning()) { json(res, { ok: false, error: '小说工作流在跑，请等它结束' }, 409); return; }
      const out = path.join(novelPaths().w, 'output', `polish-${process.pid}-${Date.now()}.json`);
      try {
        const args = ['polish', '--chapter', id, '--out', out];
        if (p.model) args.push('--model', String(p.model).slice(0, 120));
        if (Number(p.chunk) > 0) args.push('--chunk', String(Math.floor(Number(p.chunk))));
        await runNovelCmd(args, 900000);
        const r = JSON.parse(fs.readFileSync(out, 'utf8'));
        try { fs.unlinkSync(out); } catch { /* ignore */ }
        json(res, r);
      } catch (e) {
        json(res, { ok: false, error: String((e && e.message) || e) }, 500);
      }
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // 长选段按时间拆成多格，分别建队列任务
  if (url === '/api/novel/shots') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(async body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const id = String(p.id || '').trim();
      if (!id) { json(res, { ok: false, error: '缺少场景 id' }, 400); return; }
      if (novelRunning()) { json(res, { ok: false, error: '小说工作流在跑，请等它结束' }, 409); return; }
      const n = Math.max(0, Math.min(8, Math.floor(Number(p.count) || 0)));
      const out = path.join(novelPaths().w, 'output', `shots-${process.pid}-${Date.now()}.json`);
      try {
        const args = ['shots', '--scene', id, '--count', String(n), '--out', out];
        if (p.model) args.push('--model', String(p.model).slice(0, 120));
        await runNovelCmd(args, 900000);
        const r = JSON.parse(fs.readFileSync(out, 'utf8'));
        try { fs.unlinkSync(out); } catch { /* ignore */ }
        json(res, r);
      } catch (e) {
        // 脚本会把中文失败原因写进 --out 文件，优先用它回给页面
        let msg = String((e && e.message) || e);
        try {
          const j = JSON.parse(fs.readFileSync(out, 'utf8'));
          if (j && j.error) msg = String(j.error);
        } catch { /* 用进程错误兜底 */ }
        try { fs.unlinkSync(out); } catch { /* ignore */ }
        json(res, { ok: false, error: msg }, 500);
      }
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // 35B 优化场景画面描述 → 生成新 prompt
  if (url === '/api/novel/optimize') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(async body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const scene = String(p.sceneId || '').trim();
      if (!scene) { json(res, { ok: false, error: '缺少场景 id' }, 400); return; }
      if (novelRunning()) { json(res, { ok: false, error: '小说工作流在跑，请等它结束' }, 409); return; }
      const out = path.join(novelPaths().w, 'output', `optimize-${process.pid}-${Date.now()}.json`);
      try {
        const args = ['optimize', '--scene', scene, '--out', out];
        if (p.model) args.push('--model', String(p.model).slice(0, 120));
        await runNovelCmd(args, 300000);
        const r = JSON.parse(fs.readFileSync(out, 'utf8'));
        try { fs.unlinkSync(out); } catch { /* ignore */ }
        json(res, r);
      } catch (e) {
        json(res, { ok: false, error: String((e && e.message) || e) }, 500);
      }
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // 粘贴原文 → 只定位章节（不调 AI，秒回）
  if (url === '/api/novel/locate') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const text = String(p.text || '').trim();
      if (text.length < 10) { json(res, { ok: false, error: '原文太短，至少 10 个字' }, 400); return; }
      const paths = novelPaths();
      const doc = readJsonLoose(paths.chapters, {}) || {};
      const chapters = doc.chapters || [];
      const row = locateChapter(paths.p.root, chapters, text);
      if (!row) {
        json(res, { ok: false, error: '这段文字在本项目原文里找不到，确认是原样粘贴的吗？' }, 404);
        return;
      }
      json(res, { ok: true, chapter: { id: row.id, no: row.no, seq: row.seq, title: row.title } });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // 用户选中原文 → AI 参考档案与前后章节，生成 1 个场景 + prompt
  if (url === '/api/novel/extract') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(async body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const text = String(p.text || '').trim();
      let chapter = Number(p.chapter || 0);
      let chapterId = String(p.chapterId || '').trim();
      if (text.length < 10) { json(res, { ok: false, error: '原文太短，至少 10 个字' }, 400); return; }
      if (!chapter && !chapterId) {
        const doc = readJsonLoose(novelPaths().chapters, {}) || {};
        const row = locateChapter(novelPaths().p.root, doc.chapters || [], text);
        if (!row) { json(res, { ok: false, error: '这段文字在本项目原文里找不到，确认是原样粘贴的吗？' }, 404); return; }
        chapterId = String(row.id || '');
        chapter = Number(row.no || 0);
      }
      if (novelRunning()) { json(res, { ok: false, error: '小说工作流在跑，请等它结束' }, 409); return; }
      const stamp = `${process.pid}-${Date.now()}`;
      const txt = path.join(novelPaths().w, 'output', `extract-in-${stamp}.txt`);
      const out = path.join(novelPaths().w, 'output', `extract-out-${stamp}.json`);
      try {
        fs.mkdirSync(path.dirname(txt), { recursive: true });
        fs.writeFileSync(txt, text.slice(0, 8000), 'utf8');
        const args = ['extract', '--chapter', String(chapter), '--text-file', txt, '--out', out];
        if (chapterId) args.push('--chapter-id', chapterId);
        if (p.model) args.push('--model', String(p.model).slice(0, 120));
        await runNovelCmd(args, 600000);
        const r = JSON.parse(fs.readFileSync(out, 'utf8'));
        json(res, r);
      } catch (e) {
        json(res, { ok: false, error: String((e && e.message) || e) }, 500);
      } finally {
        try { fs.unlinkSync(txt); } catch { /* ignore */ }
        try { fs.unlinkSync(out); } catch { /* ignore */ }
      }
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // prompt 批量预览：现场重算（不调 AI，秒级）
  if (url === '/api/novel/prompts') {
    const out = path.join(novelPaths().p.root, '03_prompt', 'preview.json');
    runNovelCmd(['preview'], 30000)
      .then(() => json(res, Object.assign({ ok: true }, readJsonLoose(out, { items: [] }))))
      .catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 500));
    return;
  }
  // 工作流日志尾部
  if (url === '/api/novel/log') {
    const n = Math.max(10, Math.min(500, Number(qs.get('tail') || 90) || 90));
    json(res, { ok: true, log: novelLogTail(n) });
    return;
  }
  // 场景表：勾选 / 编辑
  if (url === '/api/novel/scenes') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const f = novelPaths().scenes;
      const rows = readJsonlFile(f);
      const act = String(p.action || '');
      if (act === 'select') {
        const ids = new Set((Array.isArray(p.ids) ? p.ids : []).map(String));
        const on = !!p.selected;
        let n = 0;
        for (const r of rows) {
          if (!ids.has(r.id)) continue;
          if (!!r.selected !== on) { r.selected = on; n++; }
        }
        writeJsonlFile(f, rows);
        json(res, { ok: true, changed: n, selected: rows.filter(r => r.selected).length });
        return;
      }
      if (act === 'update') {
        const r = rows.find(x => x.id === String(p.id || ''));
        if (!r) { json(res, { ok: false, error: '没有这个场景' }, 404); return; }
        const fld = p.fields || {};
        const put = (k, max) => { if (fld[k] !== undefined) r[k] = String(fld[k] || '').slice(0, max); };
        put('title', 80); put('summary', 600); put('shot', 20); put('emotion', 60); put('prompt', 6000);
        put('origin', 900); put('ai_summary', 1200);
        put('place', 80);
        if (fld.outfits !== undefined) {
          const src = (fld.outfits && typeof fld.outfits === 'object') ? fld.outfits : {};
          const out = {};
          for (const [k, v] of Object.entries(src)) {
            const name = String(k || '').trim().slice(0, 24);
            const val = String(v || '').trim().slice(0, 160);
            if (name && val) out[name] = val;
          }
          r.outfits = out;
        }
        if (fld.cast !== undefined) {
          const arr = Array.isArray(fld.cast) ? fld.cast : String(fld.cast || '').split(/[,，、\s]+/);
          r.cast = arr.map(x => String(x || '').trim()).filter(Boolean).slice(0, 10);
        }
        if (fld.aspect !== undefined) {
          const a = String(fld.aspect || '');
          r.aspect = ['3:4', '9:16', '16:9', '1:1', '4:3'].includes(a) ? a : '3:4';
        }
        if (fld.priority !== undefined) r.priority = Math.max(1, Math.min(3, Number(fld.priority) || 1));
        if (fld.selected !== undefined) r.selected = !!fld.selected;
        r.updatedAt = new Date().toISOString();
        writeJsonlFile(f, rows);
        json(res, { ok: true, scene: r });
        return;
      }
      json(res, { ok: false, error: '未知操作：' + act }, 400);
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // 角色卡：编辑 / 立绘类型勾选
  if (url === '/api/novel/characters') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const f = novelPaths().chars;
      const doc = readJsonLoose(f, { characters: [] }) || {};
      if (!Array.isArray(doc.characters)) doc.characters = [];
      const c = doc.characters.find(x => x.id === String(p.id || ''));
      if (!c) { json(res, { ok: false, error: '没有这个角色' }, 404); return; }
      const fld = p.fields || {};
      for (const k of ['alias', 'role', 'appearance', 'outfit', 'personality', 'notes']) {
        if (fld[k] !== undefined) c[k] = String(fld[k] || '').slice(0, 400);
      }
      if (fld.name !== undefined) c.name = String(fld.name || '').slice(0, 40);
      if (fld.firstChapter !== undefined) c.firstChapter = Number(fld.firstChapter) || null;
      if (fld.prompts && typeof fld.prompts === 'object') {
        c.prompts = c.prompts || {};
        for (const k of ['head', 'bust', 'full', 'expr']) {
          if (fld.prompts[k] !== undefined) c.prompts[k] = String(fld.prompts[k] || '').slice(0, 6000);
        }
      }
      if (fld.sheet && typeof fld.sheet === 'object') {
        c.sheet = Object.assign({ head: false, bust: false, full: false, expr: false }, c.sheet || {});
        for (const k of ['head', 'bust', 'full', 'expr']) {
          if (fld.sheet[k] !== undefined) c.sheet[k] = !!fld.sheet[k];
        }
      }
      doc.updatedAt = new Date().toISOString();
      writeJsonFile(f, doc);
      json(res, { ok: true, character: c });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // 启动某个步骤：ingest / characters / scenes / build / library / run
  if (url === '/api/novel/run') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const step = String(p.step || '');
      if (!['ingest', 'characters', 'scenes', 'build', 'library', 'run'].includes(step)) {
        json(res, { ok: false, error: '未知步骤：' + step }, 400);
        return;
      }
      if (novelRunning()) { json(res, { ok: false, error: '已有任务在跑，请等它结束或先解除占用' }, 409); return; }
      const extra = [];
      if (step === 'characters' && p.force) extra.push('--force');
      if (step === 'scenes') {
        if (Number(p.limit) > 0) extra.push('--limit', String(Math.floor(Number(p.limit))));
        if (p.force) extra.push('--force');
        if (p.more) extra.push('--more');
        if (Number(p.count) > 0) extra.push('--count', String(Math.floor(Number(p.count))));
        if (p.chapters) extra.push('--chapters', String(p.chapters).slice(0, 80));
      }
      if (step === 'run') {
        if (Number(p.limit) > 0) extra.push('--limit', String(Math.floor(Number(p.limit))));
        if (p.keepComfy) extra.push('--keep-comfy');
      }
      if ((step === 'characters' || step === 'scenes') && p.model) extra.push('--model', String(p.model).slice(0, 120));
      if (step === 'ingest' && p.source) extra.push('--source', String(p.source));
      const pid = spawnNovel(step, extra, '已启动：' + step);
      json(res, { ok: true, pid, step });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // 生成所选：勾选场景 + 勾选立绘类型 → 建队列 → 出图
  if (url === '/api/novel/generate') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      if (novelRunning()) { json(res, { ok: false, error: '已有任务在跑，请等它结束或先解除占用' }, 409); return; }
      const join = v => (Array.isArray(v) ? v : String(v || '').split(',')).map(x => String(x || '').trim()).filter(Boolean).join(',');
      const extra = [];
      const sceneIds = join(p.sceneIds);
      const charIds = join(p.charIds);
      const sheets = join(p.sheets);
      if (sceneIds) extra.push('--scene-ids', sceneIds.slice(0, 6000));
      if (charIds) extra.push('--char-ids', charIds.slice(0, 2000));
      if (sheets) extra.push('--sheets', sheets.slice(0, 100));
      if (Number(p.limit) > 0) extra.push('--limit', String(Math.floor(Number(p.limit))));
      if (p.keepComfy) extra.push('--keep-comfy');
      if (p.resume) extra.push('--resume');
      if (!sceneIds && !charIds && !sheets) {
        // 不传选择 = 跑当前勾选场景 + 所有角色已勾选的立绘类型
      }
      const pid = spawnNovel('generate', extra, '正在建队列并出图');
      json(res, { ok: true, pid });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  // 手动解除占用（python 异常退出后 running 卡住时用）
  if (url === '/api/novel/reset') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    try { fs.unlinkSync(path.join(novelPaths().w, 'pause.flag')); } catch { /* 没暂停就算了 */ }
    writeNovelState({ running: false, phase: 'idle', message: '已手动解除占用', pid: 0, paused: false, finishedAt: new Date().toISOString() });
    json(res, { ok: true });
    return;
  }
  // 队列控制：暂停/继续、清空未完成、插队
  if (url === '/api/novel/queue') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const paths = novelPaths();
      const qfile = path.join(paths.w, 'queue.jsonl');
      const flag = path.join(paths.w, 'pause.flag');
      const readRows = () => {
        if (!fs.existsSync(qfile)) return [];
        return fs.readFileSync(qfile, 'utf8').split(/\r?\n/).filter(Boolean)
          .map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
      };
      const writeRows = rows => {
        const tmp = qfile + '.tmp';
        fs.writeFileSync(tmp, rows.map(r => JSON.stringify(r)).join('\n') + (rows.length ? '\n' : ''), 'utf8');
        fs.renameSync(tmp, qfile);
      };
      const act = String(p.action || '');
      if (act === 'status') {
        json(res, { ok: true, paused: fs.existsSync(flag), running: novelRunning() });
        return;
      }
      if (act === 'pause') {
        fs.mkdirSync(paths.w, { recursive: true });
        fs.writeFileSync(flag, new Date().toISOString(), 'utf8');
        writeNovelState({ paused: true, message: '已暂停：当前这张画完就停' });
        json(res, { ok: true, paused: true });
        return;
      }
      if (act === 'resume') {
        try { fs.unlinkSync(flag); } catch { /* 没暂停就算了 */ }
        writeNovelState({ paused: false, message: '继续出图' });
        json(res, { ok: true, paused: false });
        return;
      }
      if (act === 'front') {
        const id = String(p.id || '').trim();
        if (!id) { json(res, { ok: false, error: '缺少任务 id' }, 400); return; }
        const rows = readRows();
        const i = rows.findIndex(r => String(r.id) === id);
        if (i < 0) { json(res, { ok: false, error: '任务不存在：' + id }, 404); return; }
        if (!['pending', 'failed'].includes(String(rows[i].status || ''))) {
          json(res, { ok: false, error: '只有待出图/失败的任务能插队' }, 400);
          return;
        }
        const [row] = rows.splice(i, 1);
        rows.unshift(row);
        writeRows(rows);
        json(res, { ok: true, id });
        return;
      }
      if (act === 'pick') {
        const id = String(p.id || '').trim();
        const k = Math.max(0, Number(p.k) || 0);
        const rows = readRows();
        const row = rows.find(r => String(r.id) === id);
        if (!row) { json(res, { ok: false, error: '任务不存在：' + id }, 404); return; }
        const cands = Array.isArray(row.candidates) ? row.candidates : [];
        if (!cands[k]) { json(res, { ok: false, error: '没有第 ' + (k + 1) + ' 张候选' }, 400); return; }
        row.output = cands[k].image;
        row.seed = cands[k].seed;
        row.thumb = cands[k].thumb || row.thumb;
        writeRows(rows);
        json(res, { ok: true, id, k, output: row.output });
        return;
      }
      if (act === 'clear') {
        if (novelRunning()) {
          json(res, { ok: false, error: '正在出图，等这张画完并解除占用后再清空' }, 409);
          return;
        }
        const rows = readRows();
        const keep = rows.filter(r => !['pending', 'failed', 'running'].includes(String(r.status || '')));
        const removed = rows.length - keep.length;
        writeRows(keep);
        writeNovelState({ message: '已清空未完成任务 ' + removed + ' 条' });
        json(res, { ok: true, removed, kept: keep.length });
        return;
      }
      json(res, { ok: false, error: '未知操作：' + act }, 400);
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }

  // 风格模板库：列表 / 新建 / 编辑 / 复制 / 删除 / 案例图
  if (url === '/api/styles') {
    if (req.method === 'GET') { json(res, { ok: true, styles: readStyles().map(styleView) }); return; }
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 GET/POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const list = readStyles();
      const act = String(p.action || '');
      const fields = () => ({
        name: String(p.name || '').trim().slice(0, 80),
        notes: String(p.notes || '').slice(0, 500),
        bible: String(p.bible || '').slice(0, 12000),
        negative: String(p.negative || '').slice(0, 6000),
        modules: Array.isArray(p.modules) ? p.modules.map(x => String(x).slice(0, 4000)).filter(Boolean) : []
      });
      if (act === 'add') {
        const f = fields();
        if (!f.name) { json(res, { ok: false, error: '风格名不能为空' }, 400); return; }
        let id = String(p.id || '').trim().replace(/[^\w-]/g, '');
        if (!id) id = 's' + Date.now().toString(36);
        if (list.some(x => x.id === id)) { json(res, { ok: false, error: '风格 id 已存在' }, 409); return; }
        list.unshift(Object.assign({ id }, f, { examples: [] }));
        writeStyles(list);
      } else if (act === 'edit') {
        const hit = list.find(x => x.id === String(p.id || ''));
        if (!hit) { json(res, { ok: false, error: '没有这个风格' }, 404); return; }
        Object.assign(hit, fields());
        writeStyles(list);
      } else if (act === 'copy') {
        const src = list.find(x => x.id === String(p.id || ''));
        if (!src) { json(res, { ok: false, error: '没有这个风格' }, 404); return; }
        const id = 's' + Date.now().toString(36);
        list.unshift(Object.assign({}, src, { id, name: src.name + '（副本）', examples: [] }));
        writeStyles(list);
      } else if (act === 'delete') {
        const id = String(p.id || '');
        if (list.length <= 1) { json(res, { ok: false, error: '至少保留一个风格' }, 409); return; }
        writeStyles(list.filter(x => x.id !== id));
        try { fs.rmSync(styleDirOf(id), { recursive: true, force: true }); } catch { /* ignore */ }
      } else if (act === 'exampleDelete') {
        const hit = list.find(x => x.id === String(p.id || ''));
        if (!hit) { json(res, { ok: false, error: '没有这个风格' }, 404); return; }
        const f = path.basename(String(p.file || ''));
        hit.examples = hit.examples.filter(x => path.basename(x) !== f);
        writeStyles(list);
        try { fs.rmSync(path.join(styleDirOf(hit.id), f), { force: true }); } catch { /* ignore */ }
      } else {
        json(res, { ok: false, error: '未知操作：' + act }, 400);
        return;
      }
      json(res, { ok: true, styles: readStyles().map(styleView) });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }

  // 风格案例图上传：原始二进制 body，?style=<id>&name=<文件名>
  if (url === '/api/styles/example') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    const sid = String(qs.get('style') || '').trim();
    const list = readStyles();
    const hit = list.find(x => x.id === sid);
    if (!hit) { json(res, { ok: false, error: '没有这个风格' }, 404); return; }
    readBodyBuffer(req, 24 * 1024 * 1024).then(buf => {
      const ext = (path.extname(String(qs.get('name') || '')).toLowerCase() || '.jpg');
      if (!/^\.(png|jpe?g|webp)$/.test(ext)) { json(res, { ok: false, error: '只支持 png/jpg/webp' }, 400); return; }
      const dir = styleDirOf(sid);
      fs.mkdirSync(dir, { recursive: true });
      const name = Date.now().toString(36) + ext;
      fs.writeFileSync(path.join(dir, name), buf);
      hit.examples = (hit.examples || []).concat(name).slice(-12);
      writeStyles(list);
      json(res, { ok: true, styles: readStyles().map(styleView) });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }

  if (url.startsWith('/style-files/')) {
    const rest = url.slice('/style-files/'.length);
    const cut = rest.indexOf('/');
    const sid = decodeURIComponent(cut > 0 ? rest.slice(0, cut) : '');
    const name = path.basename(decodeURIComponent(cut > 0 ? rest.slice(cut + 1) : ''));
    if (!sid || !name) { res.writeHead(403); res.end('forbidden'); return; }
    const full = path.join(styleDirOf(sid), name);
    fs.readFile(full, (err, buf) => {
      if (err) { res.writeHead(404); res.end('not found'); return; }
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'public, max-age=86400'
      });
      res.end(buf);
    });
    return;
  }

  // 任务看板：全量任务 + 项目统计 + 当前工作流状态 + 常用建议
  if (url === '/api/board') {
    const rows = readWorkQueue();
    const proj = curProj();
    json(res, {
      ok: true,
      project: {
        id: proj.id, name: proj.name, pipeline: proj.pipeline,
        defaultAspect: proj.defaultAspect, style: proj.style, sourceFile: proj.sourceFile
      },
      tasks: rows.map(boardTaskView),
      projects: boardProjectsOf(rows),
      work: readWorkState(),
      stat: boardStats(rows),
      presets: presetView(rows)
    });
    return;
  }

  // 常用建议：保存 / 删除
  if (url === '/api/board/presets') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const doc = readPresetDoc();
      const list = doc.saved;
      const keeps = doc.keeps;
      const text = String(p.text || '').trim().slice(0, 300);
      const from = String(p.from || '').trim();
      const act = String(p.action || '');
      if (act === 'add') {
        if (!text) { json(res, { ok: false, error: '内容为空' }, 400); return; }
        if (!list.includes(text)) list.unshift(text);
      } else if (act === 'delete') {
        const i = list.indexOf(text);
        if (i >= 0) list.splice(i, 1);
      } else if (act === 'edit') {
        const i = list.indexOf(from);
        if (i < 0) { json(res, { ok: false, error: '找不到这条建议' }, 404); return; }
        if (!text) list.splice(i, 1);
        else if (text !== from) {
          if (list.includes(text)) list.splice(i, 1);
          else list[i] = text;
        }
      } else if (act === 'keepAdd') {
        if (!text) { json(res, { ok: false, error: '内容为空' }, 400); return; }
        if (!keeps.includes(text)) keeps.push(text);
      } else if (act === 'keepDelete') {
        const i = keeps.indexOf(text);
        if (i >= 0) keeps.splice(i, 1);
      } else if (act === 'keepEdit') {
        const i = keeps.indexOf(from);
        if (i < 0) { json(res, { ok: false, error: '找不到这个保持项' }, 404); return; }
        if (!text) keeps.splice(i, 1);
        else if (text !== from) {
          if (keeps.includes(text)) keeps.splice(i, 1);
          else keeps[i] = text;
        }
      } else {
        json(res, { ok: false, error: '未知操作' }, 400);
        return;
      }
      writePresetDoc({ saved: list, keeps });
      json(res, Object.assign({ ok: true }, presetView(readWorkQueue())));
    });
    return;
  }

  // 单条任务详情：原始 prompt / 原始分类（列表接口不下发，避免每 3 秒传几 MB）
  if (url === '/api/board/task' && req.method === 'GET') {
    const rows = readWorkQueue();
    const hit = rows.find(x => x.id === (qs.get('id') || ''));
    if (!hit) { json(res, { ok: false, error: '找不到任务' }, 404); return; }
    const orig = String(hit.prompt || '');
    json(res, {
      ok: true,
      origPrompt: orig,
      origParts: orig.trim() ? splitPrompt(orig) : {}
    });
    return;
  }

  // 看板任务增删改：add / update / delete
  if (url === '/api/board/task') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const rows = readWorkQueue();
      const act = String(p.action || '');
      if (act === 'add') {
        const title = String(p.title || '').trim().slice(0, 200);
        const instruction = String(p.instruction || '').trim().slice(0, 4000);
        if (!title) { json(res, { ok: false, error: '标题不能为空' }, 400); return; }
        if (!instruction) { json(res, { ok: false, error: '建议不能为空' }, 400); return; }
        const now = new Date().toISOString();
        const mode = String(p.mode || '') === 'img2img' ? 'img2img' : '';
        const base = mode === 'img2img' ? safeBaseImage(p.image) : '';
        if (mode === 'img2img' && !base) { json(res, { ok: false, error: '图生图需要先选一张底图' }, 400); return; }
        const id = 'T' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase();
        const row = {
          id, group: String(p.project || '未分组').slice(0, 120), title,
          prompt: '', source: '看板新增', crew: '', series: '',
          aspect: String(p.aspect || '9:16'), seed: null, image: base,
          status: 'pending', output: '', error: '', elapsed: 0, ts: 0,
          mode, compiled: '', refined_prompt: '',
          instruction, instruction_at: now, prompt_at: '',
          gen_started_at: '', gen_finished_at: '', verdict: '', review_at: ''
        };
        rows.push(row);
        writeWorkQueue(rows);
        json(res, { ok: true, task: boardTaskView(row), total: rows.length });
        return;
      }
      const id = String(p.id || '');
      const hit = rows.find(x => x.id === id);
      if (!hit) { json(res, { ok: false, error: '找不到任务：' + id }, 404); return; }
      if (act === 'delete') {
        writeWorkQueue(rows.filter(x => x.id !== id));
        json(res, { ok: true, deleted: id });
        return;
      }
      if (act === 'fork') {
        // 待生图任务点「修改」：复制出一条新任务，原任务完全不动
        const now = new Date().toISOString();
        const row = Object.assign({}, hit);
        row.id = 'T' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase();
        row.status = 'pending';
        row.output = '';
        row.error = '';
        row.elapsed = 0;
        row.ts = 0;
        row.verdict = '';
        row.review_at = '';
        row.gen_started_at = '';
        row.gen_finished_at = '';
        row.prev_output = '';
        row.output_archived = false;
        row.seed = null;
        delete row.versions;
        if (p.title !== undefined) row.title = String(p.title).slice(0, 200);
        if (p.project !== undefined) row.group = String(p.project || '未分组').slice(0, 120);
        if (p.instruction !== undefined) { row.instruction = String(p.instruction).slice(0, 4000); row.instruction_at = now; }
        if (p.mode !== undefined) {
          row.mode = String(p.mode) === 'img2img' ? 'img2img' : '';
          const base = row.mode === 'img2img' ? safeBaseImage(p.image) : '';
          if (row.mode === 'img2img' && !base) { json(res, { ok: false, error: '图生图需要先选一张底图' }, 400); return; }
          row.image = base;
        }
        if (p.parts && typeof p.parts === 'object') {
          const clean = {};
          for (const [k] of PART_LABELS) {
            const v = String(p.parts[k] || '').trim();
            if (v) clean[k] = v.slice(0, 2000);
          }
          row.prompt_parts = clean;
          row.refined_prompt = joinPromptParts(clean);
          row.prompt_at = now;
        }
        rows.push(row);
        writeWorkQueue(rows);
        json(res, { ok: true, task: boardTaskView(row), forkedFrom: id, total: rows.length });
        return;
      }
      if (act === 'update') {
        const now = new Date().toISOString();
        if (p.title !== undefined) hit.title = String(p.title).slice(0, 200);
        if (p.project !== undefined) hit.group = String(p.project || '未分组').slice(0, 120);
        let dirty = false;
        let modeDirty = false;
        if (p.instruction !== undefined) {
          const s = String(p.instruction).slice(0, 4000);
          if (s !== String(hit.instruction || '')) { hit.instruction = s; hit.instruction_at = now; dirty = true; }
        }
        // 出图模式（文生图 / 图生图）与底图
        if (p.mode !== undefined) {
          const m = String(p.mode) === 'img2img' ? 'img2img' : '';
          if (m !== String(hit.mode || '')) { hit.mode = m; modeDirty = true; }
        }
        if (p.image !== undefined) {
          if (String(hit.mode || '') === 'img2img') {
            const base = safeBaseImage(p.image);
            if (p.image && !base) { json(res, { ok: false, error: '底图不在项目目录内，或文件不存在' }, 400); return; }
            if (base !== String(hit.image || '')) { hit.image = base; modeDirty = true; }
          } else {
            hit.image = '';
          }
        }
        // 分类编辑：保存后用分类重新拼出 prompt
        if (p.parts && typeof p.parts === 'object') {
          const clean = {};
          for (const [k] of PART_LABELS) {
            const v = String(p.parts[k] || '').trim();
            if (v) clean[k] = v.slice(0, 2000);
          }
          hit.prompt_parts = clean;
          hit.refined_prompt = joinPromptParts(clean);
          hit.prompt_at = now;
        }
        if ((dirty && hit.instruction) || modeDirty || (p.requeue && (String(hit.instruction || '').trim() || String(hit.prompt || '').trim()))) {
          // 建议变了（或改模式 / 用户点重跑）就重新排队：先把旧图连同当时的 prompt/信息存成一个版本
          if (!hit.output_archived) archiveVersion(hit);
          hit.status = 'pending';
          // 手动改过分类 prompt、或只是换出图模式时保留 prompt，直接进「待生图」，不再让 27B 重编译
          const manualPrompt = p.parts && typeof p.parts === 'object' && String(hit.refined_prompt || '').trim();
          if (!manualPrompt && !modeDirty) {
            hit.refined_prompt = '';
            hit.prompt_at = '';
          }
          hit.verdict = '';
          hit.review_at = '';
          hit.error = '';
          hit.gen_started_at = '';
          hit.gen_finished_at = '';
        }
        if (p.verdict !== undefined) {
          const v = String(p.verdict);
          hit.verdict = (v === 'pass' || v === 'fail') ? v : '';
          hit.review_at = hit.verdict ? now : '';
        }
        writeWorkQueue(rows);
        json(res, { ok: true, task: boardTaskView(hit) });
        return;
      }
      json(res, { ok: false, error: '未知操作：' + act }, 400);
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }

  // 项目管理：create / rename / delete（空项目才允许删）
  if (url === '/api/board/project') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { json(res, { ok: false, error: 'JSON 解析失败' }, 400); return; }
      const act = String(p.action || '');
      const rows = readWorkQueue();
      const list = readProjectList();
      if (act === 'create') {
        const name = String(p.name || '').trim().slice(0, 120);
        if (!name) { json(res, { ok: false, error: '项目名不能为空' }, 400); return; }
        if (!list.includes(name)) list.push(name);
        writeProjectList(list);
      } else if (act === 'rename') {
        const from = String(p.from || '').trim();
        const to = String(p.to || '').trim().slice(0, 120);
        if (!from || !to) { json(res, { ok: false, error: '改名需要 from 和 to' }, 400); return; }
        for (const t of rows) if (String(t.group || '未分组') === from) t.group = to;
        const i = list.indexOf(from);
        if (i >= 0) list[i] = to;
        writeWorkQueue(rows);
        writeProjectList(list);
      } else if (act === 'delete') {
        const name = String(p.name || '').trim();
        if (rows.some(t => String(t.group || '未分组') === name)) {
          json(res, { ok: false, error: '项目下还有任务，先移走或删掉任务' }, 409);
          return;
        }
        writeProjectList(list.filter(x => x !== name));
      } else {
        json(res, { ok: false, error: '未知操作：' + act }, 400);
        return;
      }
      json(res, { ok: true, projects: boardProjectsOf(readWorkQueue()) });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }

  // 一键工作流：启动（建议 → 27B prompt → 关 27B → Z-Image 出图 → 关 ComfyUI）
  if (url === '/api/work/start') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    if (readWorkState().running) { json(res, { ok: false, error: '已经有一轮在工作，等它结束' }, 409); return; }
    readBody(req).then(body => {
      let p;
      try { p = JSON.parse(body || '{}'); } catch { p = {}; }
      const proj = curProj();
      const runner = path.join(proj.workDir, proj.runner);
      if (!fs.existsSync(runner)) { json(res, { ok: false, error: '这个项目还没有执行器：' + runner }, 400); return; }
      const args = [runner];
      const limit = Number(p.limit) || 0;
      if (limit > 0) args.push('--limit', String(Math.min(999, limit)));
      if (p.group) args.push('--project', String(p.group));
      if (p.ids) args.push('--ids', String(p.ids));
      try {
        fs.writeFileSync(proj.state, JSON.stringify({
          running: true, phase: 'starting', message: '正在启动执行器',
          current: '', total: 0, done: 0, ok: 0, fail: 0,
          startedAt: new Date().toISOString(), finishedAt: '', updatedAt: new Date().toISOString()
        }), 'utf8');
        spawn(WORK_PY, args, {
          cwd: proj.workDir,
          detached: true,
          stdio: 'ignore',
          windowsHide: true,
          env: { ...process.env, PYTHONIOENCODING: 'utf-8' }
        }).unref();
        json(res, { ok: true, started: true });
      } catch (e) {
        json(res, { ok: false, error: String((e && e.message) || e) }, 500);
      }
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 400));
    return;
  }
  if (url === '/api/work/status') { json(res, readWorkState()); return; }

  // 图片库：分页 + 过滤（不返回 prompt 正文，点开单条再取）
  if (url === '/api/library') {
    const doc = readLibrary();
    const q = (qs.get('q') || '').trim().toLowerCase();
    const kind = qs.get('kind') || '';
    const status = qs.get('status') || '';
    const group = qs.get('group') || '';
    const offset = Math.max(0, Number(qs.get('offset') || 0));
    const limit = Math.min(120, Math.max(1, Number(qs.get('limit') || 48)));
    let list = doc.items || [];
    if (kind) list = list.filter(x => x.kind === kind);
    if (status) list = list.filter(x => x.status === status);
    if (group) list = list.filter(x => x.group === group);
    if (q) list = list.filter(x => ((x.title || '') + ' ' + (x.code || '') + ' ' + (x.group || '') + ' ' + (x.desc || '') + ' ' + (x.prompt || '')).toLowerCase().includes(q));
    json(res, {
      ok: true,
      meta: Object.assign({}, doc.meta, { building: libBuilding() }),
      total: list.length,
      items: list.slice(offset, offset + limit).map(libSummary)
    });
    return;
  }

  if (url === '/api/library/item') {
    const doc = readLibrary();
    const k = qs.get('k') || '';
    const it = (doc.items || []).find(x => x.k === k);
    if (!it) { json(res, { ok: false, error: '找不到条目' }, 404); return; }
    json(res, { ok: true, item: Object.assign({}, libSummary(it), {
      image: it.image || '', prompt: it.prompt || '', desc: it.desc || '', origin: it.origin || '',
      elapsed: it.elapsed || 0, bytes: it.bytes || 0, source: it.source || ''
    }) });
    return;
  }

  // 重建索引：后台跑 library_build.py（扫描 + 缩略图）
  if (url === '/api/library/rebuild') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    if (libBuilding()) { json(res, { ok: false, error: '正在重建中' }, 409); return; }
    try {
      const builder = path.join(curProj().workDir, curProj().builder);
      if (!fs.existsSync(builder)) { json(res, { ok: false, error: '这个项目还没有索引脚本：' + builder }, 400); return; }
      const logf = fs.openSync(path.join(curProj().workDir, 'library-build.log'), 'a');
      const p = spawn(WORK_PY, [builder], {
        cwd: curProj().workDir, detached: true, windowsHide: true,
        stdio: ['ignore', logf, logf],
        env: { ...process.env, PYTHONIOENCODING: 'utf-8' }
      });
      p.unref();
      libBuild = { pid: p.pid, at: Date.now() };
      json(res, { ok: true, pid: p.pid });
    } catch (e) {
      json(res, { ok: false, error: String((e && e.message) || e) }, 500);
    }
    return;
  }

  // 图片库缩略图
  if (url.startsWith('/lib-thumbs/')) {
    const name = path.basename(url.slice('/lib-thumbs/'.length));
    const full = path.join(curProj().thumbs, name);
    fs.stat(full, (e, st) => {
      if (e) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('not found'); return; }
      const etag = 'W/"' + st.size.toString(16) + '-' + Math.floor(st.mtimeMs).toString(16) + '"';
      if (req.headers['if-none-match'] === etag) { res.writeHead(304); res.end(); return; }
      fs.readFile(full, (err, buf) => {
        if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('not found'); return; }
        res.writeHead(200, {
          'Content-Type': 'image/jpeg', 'Cache-Control': 'no-cache',
          'ETag': etag, 'Last-Modified': new Date(st.mtimeMs).toUTCString()
        });
        res.end(buf);
      });
    });
    return;
  }

  // 项目内原图（只读、只允许图片、禁止目录穿越）
  if (url.startsWith('/project-files/')) {
    const rel = url.slice('/project-files/'.length).replace(/\\/g, '/');
    const base = path.resolve(curProj().root);
    const full = path.resolve(base, rel);
    if (!full.startsWith(base + path.sep) || !/\.(png|jpe?g|webp)$/i.test(full)) {
      res.writeHead(403); res.end('forbidden'); return;
    }
    fs.readFile(full, (err, buf) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('not found'); return; }
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'public, max-age=86400'
      });
      res.end(buf);
    });
    return;
  }

  // 看板缩略图：只允许读 _自动执行/output 内的文件
  if (url.startsWith('/work-files/')) {
    const name = path.basename(url.slice('/work-files/'.length));
    const base = path.resolve(curProj().out);
    const full = path.resolve(base, name);
    if (!full.startsWith(base + path.sep)) { res.writeHead(403); res.end('forbidden'); return; }
    fs.readFile(full, (err, buf) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('not found'); return; }
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'no-store'
      });
      res.end(buf);
    });
    return;
  }

  if (url === '/api/ai-summary') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).catch(() => '{}').then(async body => {
      let p = {};
      try { p = JSON.parse(body || '{}'); } catch { /* 用默认值 */ }
      const limit = Math.max(5, Math.min(60, Number(p.limit) || 20));
      const items = (readFeedback().items || [])
        .filter(x => x && String(x.suggestion || '').trim() &&
          ['fail', 'hold', 'derive', 'redo', 'cannot'].includes(x.verdict))
        .sort((a, b) => Date.parse(b.submittedAt || b.createdAt || 0) - Date.parse(a.submittedAt || a.createdAt || 0))
        .slice(0, limit);
      if (!items.length) { json(res, { ok: false, error: '最近没有可总结的修改意见' }, 409); return; }
      // 本地 35B 上下文只有 8192：建议正文按 300 字截断，总预算控制在 5k 字符内
      const lines = [];
      let budget = 5000;
      for (const x of items) {
        const s = String(x.suggestion).slice(0, 300);
        if (s.length + 40 > budget) break;
        budget -= s.length + 40;
        lines.push(`${lines.length + 1}. [${x.verdict}] ${x.imageId}${x.group ? ' · ' + x.group : ''}：${s}`);
      }
      if (!lines.length) { json(res, { ok: false, error: '最近没有可总结的修改意见' }, 409); return; }
      const used = lines.length;
      const prompt = '以下是插图审阅看板最近的修改意见，请归纳成一份可直接执行的改图总结。\n\n' + lines.join('\n') +
        '\n\n输出要求：\n1) 先列 3–6 条高频问题（人物一致性、服装材质、构图、光线、色彩等）。\n' +
        '2) 再给一份「下次出图必须遵守」的正向写法清单。\n' +
        '3) 最后列出仍然存在分歧或待定的点。\n' +
        '用中文分点，不要复述每条原话，不要 markdown 标题符号。';
      const r = await fetch(SUMMARY_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(180000),
        body: JSON.stringify({
          model: SUMMARY_MODEL,
          messages: [
            { role: 'system', content: '你是玄枢号插图项目的审阅助理，只输出中文总结，不输出思考过程。' },
            { role: 'user', content: prompt }
          ],
          reasoning_effort: 'none',
          temperature: 0.3,
          max_tokens: 1600
        })
      });
      const j = await r.json().catch(() => ({}));
      const text = String((j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '').trim();
      if (!text) throw new Error('本地模型没有返回内容（确认 LM Studio 1234 已加载模型）');
      const doc = {
        summary: text, mode: 'ai', basedOn: used,
        model: SUMMARY_MODEL, updatedAt: new Date().toISOString()
      };
      writeSummary(doc);
      json(res, { ok: true, ...doc });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 500));
    return;
  }

  // 给 agent 的机器可读快照：待办派生请求 + 判定账本 + 词条表 + 输出目录
  if (url === '/api/snapshot') {
    try { json(res, buildSnapshot()); } catch (e) { json(res, { ok: false, error: String((e && e.message) || e) }, 500); }
    return;
  }
  // 一键导出任务包：清单 + 每条 prompt 文本 + 参考图路径，照着做就能跑
  if (url === '/api/export-tasks') {
    try { json(res, exportTaskPackage()); } catch (e) { json(res, { ok: false, error: String((e && e.message) || e) }, 500); }
    return;
  }
  // ai 是否联通：本机 OpenClaw Gateway 在监听就算在线（页面据此置灰按钮）
  if (url === '/api/ai-status') {
    aiOnline()
      .then(online => json(res, { ok: true, online, port: AI_PORT, at: Date.now() }))
      .catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 500));
    return;
  }
  // 让 ai 做一下：复用 OpenClaw Gateway 通道，把导出的任务包交给同一个助理
  if (url === '/api/ai-do') {
    if (req.method !== 'POST') { json(res, { ok: false, error: '只支持 POST' }, 405); return; }
    readBody(req).catch(() => '').then(() => aiOnline()).then(online => {
      if (!online) { json(res, { ok: false, error: 'ai 未联通' }, 409); return; }
      const pack = exportTaskPackage();
      if (!pack.count) { json(res, { ok: true, count: 0, dir: pack.dir }); return; }
      const msg = '看板插图任务已导出到 ' + pack.dir + '，待出图 ' + pack.count + ' 条；请按该目录 README.md 执行，完成后 POST http://127.0.0.1:7788/api/gallery-feedback 回执。快照 http://127.0.0.1:7788/api/snapshot';
      const child = spawn(aiNode(), [AI_ENTRY, 'agent', '--agent', 'main', '--message', msg], {
        env: { ...process.env, OPENCLAW_EMBEDDED_IN: 'FlowyAIPC' },
        detached: true,
        stdio: 'ignore',
        windowsHide: true
      });
      child.on('error', e => log('ai 派活启动失败：' + ((e && e.message) || e)));
      child.unref();
      log('ai 派活 ' + pack.count + ' 条 → ' + pack.dir);
      json(res, { ok: true, count: pack.count, dir: pack.dir });
    }).catch(e => json(res, { ok: false, error: String((e && e.message) || e) }, 500));
    return;
  }

  if (url === '/api/gallery') {
    try {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify(scanGallery()));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ ok: false, error: String((e && e.message) || e) }));
    }
    return;
  }

  // 插图原图：URL 形如 /gallery-files/<rootKey>/<相对路径>，只允许读各扫描根目录内
  if (url.startsWith('/gallery-files/')) {
    const rest = url.slice('/gallery-files/'.length);
    const cut = rest.indexOf('/');
    const key = cut > 0 ? rest.slice(0, cut) : '';
    const rel = cut > 0 ? rest.slice(cut + 1) : '';
    const base = SCAN_ROOTS[key];
    if (!base || !rel) { res.writeHead(403); res.end('forbidden'); return; }
    const gRoot = path.resolve(base);
    const full = path.resolve(gRoot, rel);
    if (full !== gRoot && !full.startsWith(gRoot + path.sep)) { res.writeHead(403); res.end('forbidden'); return; }
    fs.readFile(full, (err, buf) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('not found'); return; }
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'no-store'
      });
      res.end(buf);
    });
    return;
  }

  // 打开图片所在文件夹（资源管理器），只允许扫描根目录内的路径
  if (url === '/api/open-folder') {
    const p = qs.get('path') || '';
    const abs = p ? path.resolve(p) : '';
    const allowed = Object.values(SCAN_ROOTS).map(r => path.resolve(r));
    const ok = abs && allowed.some(r => abs === r || abs.startsWith(r + path.sep));
    if (!ok) { json(res, { ok: false, error: '路径不在允许范围' }, 403); return; }
    try {
      spawn('explorer.exe', [abs], { detached: true, stdio: 'ignore' }).unref();
      json(res, { ok: true, path: abs });
    } catch (e) {
      json(res, { ok: false, error: String((e && e.message) || e) }, 500);
    }
    return;
  }

  if (url === '/api/progress') {
    json(res, {
      ok: true,
      at: Date.now(),
      tasks: [...progress].map(([id, p]) => ({ id, progress: p })),
      evidence: { commands: commands.size, clients: clients.size }
    });
    return;
  }

  if (url === '/api/events') {
    cors(res);
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no'
    });
    res.write('retry: 2000\n\n');
    res.write('data: ' + JSON.stringify({ at: Date.now(), items: [...progress].map(([id, p]) => ({ id, progress: p })) }) + '\n\n');
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }

  if (url === '/favicon.ico') { res.writeHead(204); res.end(); return; }

  // 静态文件：只允许看板目录内
  let rel = url === '/' ? '/index.html' : url;
  const full = path.resolve(ROOT, '.' + rel);
  if (full !== ROOT && !full.startsWith(ROOT + path.sep)) { res.writeHead(403); res.end('forbidden'); return; }
  fs.readFile(full, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('not found'); return; }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-store'
    });
    res.end(buf);
  });
}

const server = http.createServer((req, res) => {
  const qs = new URLSearchParams((req.url || '/').split('?')[1] || '');
  ALS.run(resolveProject(qs), () => handleRequest(req, res));
});

// ---- 给 agent 的出口：机器可读快照 + 一键导出任务包 ----
const AGENT_BATCH_ROOT = 'D:/玄枢号项目/25_插图批量_20261117';
const AGENT_PACK_BASE = path.join(AGENT_BATCH_ROOT, '_任务包');
const GEN_CFG = {
  engine: 'ComfyUI（http://127.0.0.1:8188）',
  model: 'zimage turbo',
  size: '1024x1024',
  steps: 8,
  cfg: 2.0,
  imagesPerRequest: 1,
  seed: 'seed = 1000 + (fnv1a(requestId) % 900000000)；失败重试 seed+1，最多 3 次',
  negativePrompt: 'rivet, bolt, screw, nut, fastener, exposed hinge, shoulder strap, shoe, boots, text, letters, watermark',
  notes: 'cfg 必须 2.0：cfg=1.0 时负面提示整段不生效（见 风格基准.md §3）'
};
function fnv1a(s) {
  let h = 0x811c9dc5;
  for (const ch of String(s)) { h ^= ch.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; }
  return h >>> 0;
}
function seedFor(id) { return 1000 + (fnv1a(id) % 900000000); }
function absOf(hit) {
  const base = SCAN_ROOTS[hit.b.rootKey] || SCAN_ROOTS.batch;
  return path.join(base, ...hit.img.rel.split('/'));
}
function findImageIndex(scan) {
  const idx = new Map();
  for (const b of scan.batches || []) {
    for (const g of b.groups || []) {
      for (const img of g.images || []) idx.set(img.id, { b, g, img });
    }
  }
  return idx;
}
function termsInText(text, terms) {
  const out = [];
  const re = /#([^\s#，。；：、,.;:!?()（）\[\]【】"'“”]+)/g;
  let m;
  while ((m = re.exec(String(text || '')))) {
    const t = terms.find(x => x.keyword === m[1]);
    if (t && !out.some(o => o.id === t.id)) out.push({ id: t.id, keyword: t.keyword });
  }
  return out;
}
// 版本 = 基底的派生深度 + 占位后缀里的 dN；同基底多次派生（A-d1/A-d2）得到 1/2，派生链（A-d1-d1）得到 2
function versionOfDerive(requestId, baseId, parentOf) {
  let depth = 0, cur = baseId, guard = 0;
  while (parentOf.has(cur) && guard++ < 20) { depth++; cur = parentOf.get(cur); }
  const m = /-d(\d+)$/.exec(String(requestId || ''));
  return depth + (m ? Number(m[1]) : 1);
}
function statusOfDerive(r, realHit) {
  if (realHit) return { key: 'done', label: '已出图' };
  if (r.stage === 'generating') return { key: 'generating', label: '生成中' };
  if (r.stage === 'locked' || r.receipt === 'read' || r.receipt === 'handled') return { key: 'locked', label: '已读取 · 已锁定' };
  return { key: 'submitted', label: '已提交 · 待 agent 读取' };
}
function buildSnapshot() {
  const scan = scanGallery();
  const idx = findImageIndex(scan);
  const fb = readFeedback();
  const terms = readTerms().terms || [];
  const derives = (fb.items || []).filter(r => r.verdict === 'derive' && r.derivedImageId);
  const byBase = new Map();
  const parentOf = new Map();
  const latest = new Map();
  for (const r of derives) {
    const b = r.baseImageId || r.imageId;
    if (!byBase.has(b)) byBase.set(b, []);
    byBase.get(b).push(r);
    parentOf.set(r.derivedImageId, b);
    latest.set(r.derivedImageId, r);   // 同一占位多次提交，取最后一条
  }
  const requests = [];
  for (const r of latest.values()) {
    const baseId = r.baseImageId || r.imageId;
    const baseHit = idx.get(baseId) || null;
    const realHit = idx.get(r.derivedImageId) || null;
    const st = statusOfDerive(r, realHit);
    const baseAbs = baseHit ? absOf(baseHit) : '';
    const outDir = baseAbs ? path.dirname(baseAbs) : '';
    const basePrompt = (baseHit && baseHit.g && baseHit.g.prompt) || '';
    const prompt = String(r.prompt || basePrompt || '');
    const used = (Array.isArray(r.terms) && r.terms.length ? r.terms : termsInText(r.suggestion, terms))
      .map(t => ({ id: t.id || '', keyword: t.keyword || '' }));
    const refs = [];
    if (baseAbs) refs.push(baseAbs);
    for (const t of used) {
      const td = terms.find(x => x.id === t.id || x.keyword === t.keyword);
      for (const c of (td && td.cases) || []) {
        const a = c.abs || (c.rootKey && c.rel && SCAN_ROOTS[c.rootKey] ? path.join(SCAN_ROOTS[c.rootKey], ...c.rel.split('/')) : '');
        if (a) refs.push(a);
      }
    }
    requests.push({
      requestId: r.derivedImageId,
      status: st.key,
      statusLabel: st.label,
      version: versionOfDerive(r.derivedImageId, baseId, parentOf),
      baseImageId: baseId,
      basePath: baseAbs,
      batch: r.batch || (baseHit && baseHit.b.name) || '',
      group: r.group || (baseHit && baseHit.g.id) || '',
      originalPrompt: basePrompt,
      editedPrompt: prompt,
      suggestion: r.suggestion || '',
      terms: used,
      promptForAgent: prompt + (r.suggestion ? '\n\n修改意见：' + r.suggestion : ''),
      submittedAt: r.submittedAt || '',
      readAt: r.readAt || '',
      output: {
        dir: outDir,
        filename: r.derivedImageId + '.png',
        abs: outDir ? path.join(outDir, r.derivedImageId + '.png') : '',
        note: '放到 dir 下、文件名保持 filename 不变；扫描器靠这个文件名把真图认成同一占位'
      },
      referenceImages: [...new Set(refs)]
    });
  }
  requests.sort((a, b) => String(a.submittedAt).localeCompare(String(b.submittedAt)));
  return {
    ok: true,
    generatedAt: new Date().toISOString(),
    snapshotUrl: 'http://127.0.0.1:7788/api/snapshot',
    page: 'http://127.0.0.1:7788/app.html#gallery',
    counts: {
      requests: requests.length,
      pending: requests.filter(x => x.status !== 'done').length,
      done: requests.filter(x => x.status === 'done').length,
      verdicts: (fb.items || []).length,
      terms: terms.length
    },
    model: GEN_CFG,
    requests,
    verdicts: (fb.items || []).map(r => ({
      imageId: r.imageId || '',
      verdict: r.verdict || '',
      suggestion: r.suggestion || '',
      prompt: r.prompt || '',
      terms: r.terms || [],
      receipt: r.receipt || '',
      stage: r.stage || '',
      baseImageId: r.baseImageId || '',
      derivedImageId: r.derivedImageId || '',
      submittedAt: r.submittedAt || '',
      readAt: r.readAt || '',
      handledAt: r.handledAt || ''
    })),
    terms: terms.map(t => ({
      id: t.id,
      keyword: t.keyword,
      tag: '#' + t.keyword,
      explain: t.explain,
      cases: (t.cases || []).map(c => ({ imageId: c.imageId || '', path: c.abs || '' })),
      updatedAt: t.updatedAt || '',
      source: t.source || ''
    }))
  };
}
function agentReadme(pending, dir) {
  const L = [];
  L.push('# 派生出图任务包');
  L.push('');
  L.push('生成时间：' + new Date().toISOString());
  L.push('任务数：' + pending.length);
  L.push('');
  L.push('## 怎么跑');
  L.push('1. 读 `manifest.json`（或本目录 `prompts/<requestId>.txt`）。只做 `status != "done"` 的条目，不要自己判断要不要。');
  L.push('2. 引擎：' + GEN_CFG.engine + '；模型：' + GEN_CFG.model + '；尺寸 ' + GEN_CFG.size + '；步数 ' + GEN_CFG.steps + '；cfg ' + GEN_CFG.cfg + '；每条约 ' + GEN_CFG.imagesPerRequest + " 张。");
  L.push('3. 正向提示词 = `prompts/<requestId>.txt` 全文。负面提示词固定：`' + GEN_CFG.negativePrompt + '`。');
  L.push('4. seed：' + GEN_CFG.seed + '（每条 requestId 已列在 manifest.json 的 seedHint 里）。');
  L.push('5. 输出：写到 `output.dir`，文件名必须是 `output.filename`（= `<requestId>.png`），不要改名、不要加后缀。');
  L.push('6. 参考图：`refs/<requestId>.txt` 里是绝对路径列表，按顺序当 reference image 用。');
  L.push('7. 失败重试：同一个文件名覆盖重跑，seed+1，最多 3 次；3 次都失败就跳过，并回报 verdict=cannot（看板显示「无法生成」）。');
  L.push('8. 跑完回报：POST http://127.0.0.1:7788/api/gallery-feedback，body 示例：');
  L.push('```json');
  L.push('{ "id": "<已有记录 id>", "stage": "done", "receipt": "handled", "note": "已出图到 output.abs" }');
  L.push('{ "imageId": "<baseImageId>", "verdict": "derive", "derivedImageId": "<requestId>", "stage": "done" }');
  L.push('{ "imageId": "<出不来图的条目 id>", "verdict": "cannot", "suggestion": "<原有建议原样带回>", "note": "按建议出不来图" }');
  L.push('```');
  L.push('账本由页面 / 出图 / 站点多处写入：能带 `id` 就按 id 合并（只覆盖 body 里出现的字段），不要整文件覆盖；`verdict` 支持 pass / pass_base / fail / hold / cannot / derive；站点发布后回写链接用 `publishUrl`（也接受 publishedUrl / siteUrl / url / link）。');
  L.push('');
  L.push('## 目录');
  L.push('- `manifest.json`：全部任务（含原图 id/绝对路径、原 prompt、建议、#词条、状态、输出目录、seedHint）');
  L.push('- `prompts/<requestId>.txt`：可直接拼进提示词的全文');
  L.push('- `refs/<requestId>.txt`：参考图绝对路径，一行一个');
  L.push('');
  L.push('说明：真图落盘后不需要重启服务，页面「重新扫描」即可把占位换成真图；文件名就是识别依据。');
  return L.join('\n');
}
function exportTaskPackage() {
  const snap = buildSnapshot();
  const pending = snap.requests.filter(r => r.status !== 'done');
  const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
  const dir = path.join(AGENT_PACK_BASE, stamp);
  fs.mkdirSync(path.join(dir, 'prompts'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'refs'), { recursive: true });
  const rules = {
    engine: GEN_CFG.engine,
    model: GEN_CFG.model,
    size: GEN_CFG.size,
    steps: GEN_CFG.steps,
    cfg: GEN_CFG.cfg,
    negativePrompt: GEN_CFG.negativePrompt,
    seedStrategy: GEN_CFG.seed,
    imagesPerRequest: GEN_CFG.imagesPerRequest,
    outputRule: '写入 output.dir，文件名保持 output.filename（<requestId>.png）',
    retry: '同名覆盖重跑，seed+1，最多 3 次',
    report: 'POST /api/gallery-feedback：{imageId: baseImageId, verdict:"derive", derivedImageId: requestId, stage:"done", receipt:"handled", note:"..."}'
  };
  const tasks = pending.map(r => ({ ...r, seedHint: seedFor(r.requestId) }));
  const manifest = {
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    sourceSnapshot: 'http://127.0.0.1:7788/api/snapshot',
    rules,
    tasks,
    terms: snap.terms,
    verdicts: snap.verdicts
  };
  fs.writeFileSync(path.join(dir, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
  for (const r of tasks) {
    fs.writeFileSync(path.join(dir, 'prompts', r.requestId + '.txt'), r.promptForAgent, 'utf8');
    fs.writeFileSync(path.join(dir, 'refs', r.requestId + '.txt'), r.referenceImages.join('\r\n'), 'utf8');
  }
  fs.writeFileSync(path.join(dir, 'README.md'), agentReadme(tasks, dir), 'utf8');
  return { ok: true, dir, count: tasks.length, snapshot: snap.counts, files: ['manifest.json', 'README.md', 'prompts/', 'refs/'] };
}

// ---- 启动 ----
loadAll();
exportTerms(readTerms());                 // 启动时把词条同步给生图 agent 一份，保证文件存在
const cmdCount = loadCommands();          // 先加载证据，再出首次快照
for (const id of tasks.keys()) recompute(id, [], new Set());
for (const id of tasks.keys()) armed.set(id, stateOf(tasks.get(id)));   // 启动时先记基线，不补弹历史
// 停滞是时间推移产生的，没有文件事件：只在有页面连着时每分钟扫一次，空闲不跑
setInterval(() => {
  if (!clients.size) return;
  notify([...tasks.keys()].map(detect));
}, 60000).unref();

server.on('error', e => {
  if (e && e.code === 'EADDRINUSE') {
    log('端口 ' + PORT + ' 已被占用：可能已经有一个看板在跑，先访问 http://' + HOST + ':' + PORT + '/ ；或换端口 node live.mjs --port 7789');
    process.exit(2);
  }
  log('服务错误：' + ((e && e.stack) || e));
});

for (const p of readProjectsDoc().projects) ensureProjectDirs(p);

server.listen(PORT, HOST, () => {
  log('看板目录 ' + ROOT);
  log('项目 ' + readProjectsDoc().projects.map(p => p.id + ':' + p.name).join(' / '));
  log('日志文件 ' + LOG_FILE);
  log('服务已启动 http://' + HOST + ':' + PORT + '/');
  log('任务 ' + tasks.size + ' 条 · 命令记录 ' + cmdCount + ' 条 · 静态直开回退地址 http://' + HOST + ':' + PORT);
  watchTasks();
  watchCommands();
  watchGit();
});

process.on('uncaughtException', e => log('未捕获异常：' + ((e && e.stack) || e)));
process.on('unhandledRejection', e => log('未处理的 Promise 拒绝：' + ((e && e.stack) || e)));
process.on('exit', code => logLine(new Date().toISOString() + ' [live] 进程退出 code=' + code));

function shutdown() {
  log('停止服务');
  for (const t of timers.values()) clearTimeout(t);
  for (const res of clients) { try { res.end(); } catch { /* ignore */ } }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 500).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
