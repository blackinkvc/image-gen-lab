// 共享运行环境：配置读取、家目录、命令/记忆目录、端口、跨平台打开浏览器、记忆目录 slug 还原。
// 目的：换机器（不同盘符 / 用户名 / 没有 Trae 目录 / 没有本地服务）时不改代码，只改配置。
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const ROOT = path.dirname(fileURLToPath(import.meta.url));
export const HOME = (process.env.USERPROFILE || process.env.HOME || os.homedir() || '').replace(/[\\/]+$/, '');
export const IS_WIN = process.platform === 'win32';

export function loadJson(file, fallback) {
  try {
    if (fs.existsSync(file)) {
      // 兼容 Windows 记事本 / PowerShell 写出的 UTF-8 BOM
      const txt = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
      return JSON.parse(txt);
    }
  } catch (e) {
    console.error(path.basename(file) + ' 读取失败：' + e.message);
  }
  return fallback;
}

// 看板配置：缺项一律回落到内置默认值，保证别人机器上不写配置也能跑
const DEFAULT_PROJECTS = [
  { id: 'xuanshu', label: '玄枢号', pattern: '玄枢号|舰务|舰员|舰体|crew|立绘|装备|器物|图鉴|站点|首页|读数|房间|材质|船员|三维|武器|服装|审讯|木星|事件图' },
  { id: 'board', label: '任务看板自身', ids: ['taskboard', 'draft-auto-11', 'draft-temp2026111308-13'], pattern: '看板' },
  { id: 'misc', label: '存图与其他零散任务' }
];
const DEFAULT_COMMIT_MATCH = { minScore: 0.34, insMinScore: 0.5, windowDays: 14, maxPerCard: 1 };

export function readBoardConfig() {
  const raw = loadJson(path.join(ROOT, 'board-config.json'), {});
  const cfg = {
    stallHours: 1,
    archiveDays: 7,
    defaultWeight: 1,
    livePort: 7788,
    ...raw
  };
  cfg.paths = Object.assign({ commandDir: '', memoryDir: '' }, raw.paths || {});
  cfg.commitMatch = Object.assign({}, DEFAULT_COMMIT_MATCH, raw.commitMatch || {});
  cfg.projects = Array.isArray(raw.projects) && raw.projects.length ? raw.projects : DEFAULT_PROJECTS;
  return cfg;
}

// 支持 ~ 与相对路径（相对看板目录）；空值返回空串
export function expandPath(p) {
  const s = String(p || '').trim();
  if (!s) return '';
  if (s === '~') return HOME;
  if (s.startsWith('~/') || s.startsWith('~\\')) return path.join(HOME, s.slice(2));
  return path.resolve(ROOT, s);
}

// 命令执行记录目录：配置优先，其次本机 Trae 默认位置；读不到就自动关闭
export function commandDir(cfg) {
  if (cfg.paths.commandDir) return expandPath(cfg.paths.commandDir);
  const appData = process.env.APPDATA || '';
  if (!appData) return '';
  return path.join(appData, 'Trae CN', 'ModularData', 'ai-agent', 'command-execution');
}

// 记忆摘要目录：配置优先，其次 ~/.trae-cn/memory/projects
export function memoryDir(cfg) {
  if (cfg.paths.memoryDir) return expandPath(cfg.paths.memoryDir);
  if (!HOME) return '';
  return path.join(HOME, '.trae-cn', 'memory', 'projects');
}

// 打开浏览器（提醒弹窗用）。非 Windows 不再依赖 cmd /c start
export function openUrl(url) {
  const [cmd, args] = IS_WIN
    ? ['cmd', ['/c', 'start', '', url]]
    : process.platform === 'darwin'
      ? ['open', [url]]
      : ['xdg-open', [url]];
  try {
    execFile(cmd, args, { windowsHide: true }, () => {});
  } catch { /* 打不开浏览器不影响其它功能 */ }
}

// Trae 记忆目录的项目 slug（-c-Users-name-Documents-...）还原成本机路径。
// 只做本地字符串 + 真实目录校验，不猜不存在的路径；还原失败返回空串。
export function decodeWorkspaceSlug(slug) {
  const s = String(slug || '').replace(/--p2-[0-9a-f]+$/i, '');
  if (!s.startsWith('-') || !HOME) return '';
  const homeSlug = '-' + HOME.replace(/[:\\/]+/g, '-');
  if (s.toLowerCase().indexOf(homeSlug.toLowerCase()) !== 0) return '';
  let rest = s.slice(homeSlug.length).replace(/^-/, '');
  if (!rest) return HOME;
  const parts = rest.split('-');
  const variants = seg => [seg, seg.replace(/-/g, '_')];
  let cur = HOME;
  let i = 0;
  while (i < parts.length) {
    let matched = '';
    for (let j = parts.length; j > i && !matched; j--) {
      const seg = parts.slice(i, j).join('-');
      for (const v of variants(seg)) {
        try {
          if (v && fs.existsSync(path.join(cur, v))) { matched = v; i = j; break; }
        } catch { /* 权限问题按不存在处理 */ }
      }
    }
    if (!matched) return '';
    cur = path.join(cur, matched);
  }
  return cur;
}
