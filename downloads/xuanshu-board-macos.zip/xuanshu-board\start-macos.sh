#!/usr/bin/env bash
# 玄枢号看板 · macOS 启动脚本
cd "$(dirname "$0")" || exit 1
PORT=7790

if ! command -v node >/dev/null 2>&1; then
  echo "[看板] 没有找到 Node.js，请先安装 Node.js 18 或以上版本：https://nodejs.org/"
  read -r -p "按回车退出..."
  exit 1
fi

if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then
  echo "[看板] 服务已在运行，直接打开页面。"
  open "http://127.0.0.1:$PORT/board.html"
  exit 0
fi

echo "[看板] 正在后台启动本地服务，日志写入 live.log ..."
nohup node live.mjs --port $PORT > live.log 2>&1 &
sleep 2
open "http://127.0.0.1:$PORT/board.html"
echo "[看板] 已启动。关闭服务：pkill -f \"live.mjs --port $PORT\""
