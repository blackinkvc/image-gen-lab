@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PORT=7790"
set "URL=http://127.0.0.1:%PORT%/board.html"

where node >nul 2>nul
if errorlevel 1 (
  echo [看板] 没有找到 Node.js，请先安装 Node.js 18 或以上版本：https://nodejs.org/
  pause
  exit /b 1
)

netstat -ano | findstr /R /C:":%PORT% " | findstr LISTENING >nul
if not errorlevel 1 (
  echo [看板] 服务已在运行，直接打开页面。
  start "" "%URL%"
  exit /b 0
)

echo [看板] 正在后台启动本地服务，日志写入 live.log ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$q=[char]34; $cmd=$q+'node'+$q+' live.mjs --port %PORT%'; $r=Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{CommandLine=$cmd; CurrentDirectory='%~dp0'}; if($r.ReturnValue -ne 0){ Write-Host ('启动失败 code='+$r.ReturnValue); exit 1 }"
if errorlevel 1 (
  echo [看板] 启动失败，请查看 live.log。
  pause
  exit /b 1
)
ping -n 3 127.0.0.1 >nul
start "" "%URL%"
exit /b 0
